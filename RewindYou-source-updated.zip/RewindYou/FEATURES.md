# RewindYou — product requirements and implementation plan

This document records the agreed requirements for the next stages. It is a specification, not proof that every feature is implemented in the current prototype.

## Music capture
- Track playback from the selected players: Samsung Music, YouTube Music, and Musicolet.
- Store statistics locally on the device. No account or cloud service is required for core functionality.
- Record title, artist, source player, listening duration, and counted plays, subject to the metadata/events Android exposes.
- Count a play after at least 30 seconds. Pauses do not add listening time. A resume after pause should continue the same play; a player-reported restart should be treated as a new play.

## Recap generation
- Provide manual recap generation from inside the app for a user-selected week, month, or year.
- Allow selecting past periods as well as the current period where appropriate.
- Automatically prepare a monthly recap after the month ends and an annual recap after the year ends.
- Notify the user when an automatic recap is ready.
- The notification opens the app/recap. It must not automatically save, post, or share an image. The user previews the recap and explicitly saves the image.
- Schedule work using Android-compatible background scheduling and account for battery optimization / delayed execution. Do not promise exact-time execution when Android defers background work.
- Avoid duplicate recaps/notifications for the same period; keep generated recap history available inside the app.

## Recap image editor
- Offer both editable starter templates and a blank canvas to create a design from scratch.
- Advanced editing: move and resize elements on the canvas.
- Let users add, remove, and rearrange recap elements such as title, date range, listening time, top songs/artists, rankings, and optional artwork.
- Allow adjusting text, fonts, sizes, colors, backgrounds, and layout; allow selecting an image from the device as a background where Android permissions/pickers permit.
- Show a preview before export and let the user manually save the finished image to the device.
- Keep template/layout settings local and allow reusing saved designs.
- Generate shareable image files locally; do not share automatically.

## Suggested implementation stages
1. Validate media-session capture on the actual Samsung phone and selected player apps.
2. Add recap-period queries and manual weekly/monthly/yearly recap screens.
3. Add recap history and scheduled monthly/yearly generation with notifications.
4. Implement a canvas/editor with movable and resizable elements, editable templates, and blank-canvas creation.
5. Render and export the recap image, then test on the target phone.

## Known technical caveats
- Android media-session events and metadata vary by player version; exact restart/seek detection may not always be exposed.
- Android battery management can delay scheduled background work.
- The existing project is an early source prototype and has not been compiled or tested in this environment. The features above are requirements/planned work, not claims of completed functionality.
