# RewindYou — Android starter project

**Version:** 0.1.0 (first technical prototype)  
**Language:** Kotlin  
**Minimum Android:** 8.0 (API 26)  
**Storage:** local SQLite database; no account or cloud service

## What this prototype includes

- An Android app named **RewindYou** with a first-pass icon based on the selected colorful rewind/music-note design.
- Selection toggles for Samsung Music, YouTube Music, and Musicolet.
- A `NotificationListenerService` that asks Android for active media sessions and filters by the selected package names.
- Local storage for track title, artist, listening duration, and counted playback segments.
- A 30-second threshold for counting a play. Listening time is accumulated separately, including shorter segments.
- A simple top-five and total-stats screen.
- Setup links for notification-listener access and app battery settings.

## Agreed next-stage requirements

See [`FEATURES.md`](FEATURES.md) for the full feature specification. The agreed design includes manual weekly/monthly/yearly recaps, automatic month-end and year-end recaps with notifications, and an advanced image editor with editable templates plus a blank canvas. Users must save recap images manually after previewing them.

## Important limitations of this prototype

This is **not yet a finished or fully verified app**. The recap scheduling, notifications, recap history, share-image rendering, and advanced editor described in `FEATURES.md` are not implemented in this prototype yet. They are planned next steps, beginning with validating capture reliability.

Android media players expose different metadata and playback-state behavior. RewindYou can only count restarts/seeks that the player reports through its media session. Some player versions may not expose every event, and OEM battery management may interrupt callbacks. The prototype must be tested on the target Samsung phone with each player, screen locked, after pauses, after seeking/restarting, and after reboot.

The initial implementation estimates segment duration from the elapsed time between PLAYING and the next pause/stop/track change/session removal callback. If Android kills the service without delivering a final callback, an in-progress segment may not be finalized. A later reliability pass should add durable checkpoints and recovery handling before relying on long-term stats.

## Build in Android Studio

1. Install Android Studio on a computer.
2. Open the `RewindYou` folder as an existing Gradle project.
3. Allow Gradle to download the Android Gradle Plugin/Kotlin plugin and Android SDK components.
4. Build with **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your phone.

This environment did not have Gradle or the Android SDK installed, so an APK could not be compiled here. The deliverable is the editable source project.

## First-run setup on the phone

1. Open RewindYou.
2. Tap **Habilitar acceso multimedia** and enable RewindYou in Android's notification-access settings. This is a special system permission; the app intentionally does not read notification text.
3. Return to RewindYou and open app battery settings. On Samsung, choose **Unrestricted / Sin restricciones** if offered.
4. Keep the three desired player toggles enabled.
5. Play music in one selected player, lock the screen, then pause or change tracks to finalize a listening segment. Reopen RewindYou and refresh the stats.

## Package names currently configured

- Samsung Music: `com.sec.android.app.music`
- YouTube Music: `com.google.android.apps.youtube.music`
- Musicolet: `in.krosbits.musicolet`

If an installed version uses a different package name or does not publish useful media-session data, it will need adjustment.
