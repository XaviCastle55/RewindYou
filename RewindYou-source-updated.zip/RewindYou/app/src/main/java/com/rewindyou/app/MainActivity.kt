package com.rewindyou.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var top: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refresh() }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(247, 245, 252)) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(28)) }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "⏪  RewindYou"
            textSize = 30f; setTextColor(Color.rgb(43, 32, 83)); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Tu música. Tu historia. Tu propio resumen."
            textSize = 14f; setTextColor(Color.rgb(89, 82, 112)); setPadding(0, dp(5), 0, dp(20))
        })
        root.addView(section("REGISTRAR MÚSICA"))
        root.addView(TextView(this).apply {
            text = "Elegí los reproductores que querés incluir. RewindYou solo procesa las sesiones multimedia de los seleccionados."
            textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(4), 0, dp(8))
        })
        addPlayerCheck(root, "Samsung Music", KEY_SAMSUNG_MUSIC, true)
        addPlayerCheck(root, "YouTube Music", KEY_YOUTUBE_MUSIC, true)
        addPlayerCheck(root, "Musicolet", KEY_MUSICOLET, true)

        val permission = Button(this).apply {
            text = "1 · Habilitar acceso multimedia"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        root.addView(permission, matchWrap())
        root.addView(TextView(this).apply {
            text = "En esa pantalla, activá RewindYou. Es un permiso especial de Android necesario para detectar las sesiones de reproducción."
            textSize = 13f; setTextColor(Color.rgb(89, 82, 112)); setPadding(0, dp(5), 0, dp(14))
        })
        root.addView(Button(this).apply {
            text = "2 · Abrir ajustes de batería"
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:$packageName"))) }
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Para mejorar la continuidad en Samsung, abrí Batería y elegí Sin restricciones si está disponible. No podemos garantizar que Android nunca suspenda el registro."
            textSize = 13f; setTextColor(Color.rgb(89, 82, 112)); setPadding(0, dp(5), 0, dp(14))
        })

        root.addView(section("ESTADO"))
        status = cardText(root)
        root.addView(Button(this).apply { text = "Actualizar estado y estadísticas"; setOnClickListener { refresh() } }, matchWrap())
        root.addView(section("TUS ESTADÍSTICAS"))
        stats = cardText(root)
        root.addView(section("TOP 5 CANCIONES"))
        top = cardText(root)
        root.addView(TextView(this).apply {
            text = "Versión inicial: las estadísticas se guardan solo en este teléfono. Los resúmenes gráficos y los períodos semanales/mensuales/anuales se añadirán en la siguiente etapa."
            textSize = 12f; setTextColor(Color.GRAY); setPadding(0, dp(20), 0, 0)
        })
    }

    private fun addPlayerCheck(root: LinearLayout, label: String, key: String, default: Boolean) {
        root.addView(CheckBox(this).apply {
            text = label; textSize = 16f; isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }, matchWrap())
    }

    private fun refresh() {
        val enabled = isListenerEnabled()
        status.text = if (enabled) "Acceso multimedia: habilitado\nEl sistema puede entregar sesiones de los reproductores seleccionados." else "Acceso multimedia: falta habilitarlo\nUsá el botón de arriba y activá RewindYou en los ajustes de Android."
        val t = db.totals()
        stats.text = "Canciones distintas: ${t.uniqueTracks}\nReproducciones contabilizadas: ${t.plays}\nTiempo registrado: ${formatDuration(t.listenedMs)}"
        val rows = db.topTracks(5)
        top.text = if (rows.isEmpty()) "Todavía no hay canciones registradas. Habilitá el acceso y reproducí música en una de las apps seleccionadas." else rows.mapIndexed { i, s -> "${i + 1}. ${s.title}\n   ${s.artist} · ${s.plays} reproducciones · ${formatDuration(s.listenedMs)}" }.joinToString("\n\n")
    }

    private fun isListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(10, 139, 121)); setPadding(0, dp(16), 0, dp(8))
    }
    private fun cardText(root: LinearLayout) = TextView(this).apply {
        textSize = 15f; setTextColor(Color.rgb(42, 38, 55)); setPadding(dp(14), dp(14), dp(14), dp(14))
        setBackgroundColor(Color.WHITE)
        root.addView(this, matchWrap())
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatDuration(ms: Long): String = DateUtils.formatElapsedTime(ms / 1000L)

    companion object {
        const val PREFS = "rewindyou_preferences"
        const val KEY_SAMSUNG_MUSIC = "samsung_music"
        const val KEY_YOUTUBE_MUSIC = "youtube_music"
        const val KEY_MUSICOLET = "musicolet"
    }
}
