package com.rewindyou.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only store. Each finalized listening segment contributes time; segments >=30 s count as plays. */
class ListeningDatabase(context: Context) : SQLiteOpenHelper(context, "rewindyou.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            source_package TEXT NOT NULL,
            plays INTEGER NOT NULL DEFAULT 0,
            listened_ms INTEGER NOT NULL DEFAULT 0,
            last_played_ms INTEGER NOT NULL,
            UNIQUE(title, artist)
        )""")
        db.execSQL("CREATE TABLE segments (id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, started_ms INTEGER NOT NULL, listened_ms INTEGER NOT NULL, counted_as_play INTEGER NOT NULL, FOREIGN KEY(track_id) REFERENCES tracks(id))")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized
    fun recordSegment(title: String, artist: String, sourcePackage: String, startedMs: Long, listenedMs: Long) {
        if (title.isBlank() || listenedMs <= 0L) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val values = ContentValues().apply {
                put("title", title.trim())
                put("artist", artist.ifBlank { "Artista desconocido" }.trim())
                put("source_package", sourcePackage)
                put("last_played_ms", System.currentTimeMillis())
            }
            db.insertWithOnConflict("tracks", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            val trackId = db.rawQuery(
                "SELECT id FROM tracks WHERE title=? AND artist=?",
                arrayOf(title.trim(), artist.ifBlank { "Artista desconocido" }.trim())
            ).use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            if (trackId > 0) {
                val counted = if (listenedMs >= MIN_PLAY_MS) 1 else 0
                db.execSQL("UPDATE tracks SET plays=plays+?, listened_ms=listened_ms+?, last_played_ms=? WHERE id=?", arrayOf(counted, listenedMs, System.currentTimeMillis(), trackId))
                db.execSQL("INSERT INTO segments(track_id, started_ms, listened_ms, counted_as_play) VALUES(?,?,?,?)", arrayOf(trackId, startedMs, listenedMs, counted))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun totals(): Totals {
        readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(SUM(plays),0), COALESCE(SUM(listened_ms),0) FROM tracks", null).use { c ->
            if (c.moveToFirst()) return Totals(c.getInt(0), c.getInt(1), c.getLong(2))
        }
        return Totals(0, 0, 0L)
    }

    fun topTracks(limit: Int = 5): List<TrackStat> {
        val out = mutableListOf<TrackStat>()
        readableDatabase.rawQuery("SELECT title, artist, source_package, plays, listened_ms FROM tracks ORDER BY plays DESC, listened_ms DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4))
        }
        return out
    }

    companion object { const val MIN_PLAY_MS = 30_000L }
}

data class Totals(val uniqueTracks: Int, val plays: Int, val listenedMs: Long)
data class TrackStat(val title: String, val artist: String, val sourcePackage: String, val plays: Int, val listenedMs: Long)
