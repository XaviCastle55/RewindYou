package com.rewindyou.app

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.concurrent.ConcurrentHashMap

/**
 * Receives media-session metadata/state through Android's notification-listener authorization.
 * It does not read notification text or media audio; it only tracks the three opted-in players.
 */
class MusicListenerService : NotificationListenerService() {
    private val controllers = ConcurrentHashMap<String, MediaController>()
    private val callbacks = ConcurrentHashMap<String, MediaController.Callback>()
    private val recorder by lazy { SessionRecorder(ListeningDatabase(this)) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // Notification contents are intentionally not read. Session events are our source of metadata.
        refreshSessions()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refreshSessions() }

    private fun refreshSessions() {
        try {
            val allowed = selectedPackages()
            val active = getSystemService(android.media.session.MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MusicListenerService::class.java))
                .filter { it.packageName in allowed }
            val activeKeys = active.map { key(it) }.toSet()
            controllers.keys.toList().filter { it !in activeKeys }.forEach { removeController(it) }
            active.forEach { controller ->
                val k = key(controller)
                if (controllers.putIfAbsent(k, controller) == null) {
                    val callback = object : MediaController.Callback() {
                        override fun onMetadataChanged(metadata: MediaMetadata?) { recorder.onMetadata(k, controller.packageName, metadata, controller.playbackState) }
                        override fun onPlaybackStateChanged(state: PlaybackState?) { recorder.onState(k, controller.packageName, controller.metadata, state) }
                        override fun onSessionDestroyed() { recorder.finish(k); removeController(k) }
                    }
                    callbacks[k] = callback
                    controller.registerCallback(callback)
                }
                recorder.onMetadata(k, controller.packageName, controller.metadata, controller.playbackState)
                recorder.onState(k, controller.packageName, controller.metadata, controller.playbackState)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Media-session access is not available yet", e)
        } catch (e: Exception) { Log.e(TAG, "Could not refresh media sessions", e) }
    }

    private fun removeController(k: String) {
        callbacks.remove(k)?.let { cb -> controllers[k]?.unregisterCallback(cb) }
        controllers.remove(k)
        recorder.finish(k)
    }

    override fun onListenerDisconnected() {
        controllers.keys.toList().forEach(::removeController)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        controllers.keys.toList().forEach(::removeController)
        super.onDestroy()
    }

    private fun key(controller: MediaController) = controller.packageName + ":" + controller.sessionToken.hashCode()

    private fun selectedPackages(): Set<String> {
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val saved = prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, null)
        if (saved != null) return saved.toSet()
        // Compatibility with installations created before selectable players were added.
        return buildSet {
            if (prefs.getBoolean(MainActivity.KEY_SAMSUNG_MUSIC, true)) add(MainActivity.PKG_SAMSUNG_MUSIC)
            if (prefs.getBoolean(MainActivity.KEY_YOUTUBE_MUSIC, true)) add(MainActivity.PKG_YOUTUBE_MUSIC)
            if (prefs.getBoolean(MainActivity.KEY_MUSICOLET, true)) add(MainActivity.PKG_MUSICOLET)
        }
    }

    companion object { private const val TAG = "RewindYou" }
}

private class SessionRecorder(private val db: ListeningDatabase) {
    private data class Segment(
        val title: String, val artist: String, val pkg: String,
        var startedElapsed: Long, var startedWall: Long,
        var lastPosition: Long, var lastStateUpdateElapsed: Long
    )
    private val active = ConcurrentHashMap<String, Segment>()

    @Synchronized fun onMetadata(key: String, pkg: String, metadata: MediaMetadata?, state: PlaybackState?) {
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)?.trim().orEmpty()
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.trim().orEmpty()
        val old = active[key]
        if (old != null && title.isNotBlank() && (old.title != title || (artist.isNotBlank() && old.artist != artist))) finish(key)
        if (state?.state == PlaybackState.STATE_PLAYING && title.isNotBlank()) startIfNeeded(key, pkg, title, artist, state.position)
    }

    @Synchronized fun onState(key: String, pkg: String, metadata: MediaMetadata?, state: PlaybackState?) {
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)?.trim().orEmpty()
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.trim().orEmpty()
        val position = state?.position ?: 0L
        val current = active[key]
        if (current != null && title.isNotBlank() && (current.title != title || (artist.isNotBlank() && current.artist != artist))) finish(key)
        val segment = active[key]
        if (state?.state == PlaybackState.STATE_PLAYING && title.isNotBlank()) {
            if (segment != null) {
                val elapsed = android.os.SystemClock.elapsedRealtime()
                val expected = segment.lastPosition + (elapsed - segment.lastStateUpdateElapsed).coerceAtLeast(0L)
                // A substantial backward seek/restart starts a separate attempt, including mid-song restarts.
                if (position >= 0 && segment.lastPosition > 3_000 && position + 5_000 < expected) {
                    finish(key)
                    startIfNeeded(key, pkg, title, artist, position)
                } else {
                    segment.lastPosition = position
                    segment.lastStateUpdateElapsed = elapsed
                }
            } else startIfNeeded(key, pkg, title, artist, position)
        } else if (segment != null) finish(key)
    }

    private fun startIfNeeded(key: String, pkg: String, title: String, artist: String, position: Long) {
        if (title.isBlank() || active.containsKey(key)) return
        val now = android.os.SystemClock.elapsedRealtime()
        active[key] = Segment(title, artist, pkg, now, System.currentTimeMillis(), position.coerceAtLeast(0L), now)
    }

    @Synchronized fun finish(key: String) {
        val segment = active.remove(key) ?: return
        val elapsed = (android.os.SystemClock.elapsedRealtime() - segment.startedElapsed).coerceAtLeast(0L)
        // Count actual elapsed time only while Android reports PLAYING; callbacks close segments on pause/stop.
        db.recordSegment(segment.title, segment.artist, segment.pkg, segment.startedWall, elapsed)
    }
}
