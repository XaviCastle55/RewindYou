plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rewindyou.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rewindyou.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.2.2"
    }
}
