package com.rewindyou.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateUtils
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var top: TextView
    private lateinit var playersSummary: TextView
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var summaryCard: TextView
    private var summaryPeriod: Period? = null
    private var summaryOffset = 0   // 0 = período en curso, -1 = el anterior, etc.
    private var summaryText: String? = null

    private enum class Period(val title: String) { WEEK("Resumen semanal"), MONTH("Resumen mensual"), YEAR("Resumen anual") }

    private data class Palette(val name: String, val primary: Int, val secondary: Int, val lightBg: Int, val darkBg: Int)
    private data class InstalledApp(val packageName: String, val label: String)

    private val palettes = listOf(
        Palette("Violeta + turquesa", Color.rgb(105, 64, 190), Color.rgb(0, 157, 150), Color.rgb(247, 245, 252), Color.rgb(23, 20, 37)),
        Palette("Rojo + bordó", Color.rgb(183, 40, 69), Color.rgb(111, 23, 52), Color.rgb(255, 246, 248), Color.rgb(38, 17, 25)),
        Palette("Azul eléctrico", Color.rgb(40, 105, 220), Color.rgb(91, 190, 239), Color.rgb(243, 248, 255), Color.rgb(14, 24, 42)),
        Palette("Verde", Color.rgb(32, 139, 87), Color.rgb(105, 190, 115), Color.rgb(244, 251, 246), Color.rgb(15, 32, 24)),
        Palette("Naranja", Color.rgb(216, 105, 35), Color.rgb(246, 169, 66), Color.rgb(255, 249, 241), Color.rgb(39, 25, 15)),
        Palette("Amarillo", Color.rgb(173, 130, 0), Color.rgb(235, 190, 35), Color.rgb(255, 252, 235), Color.rgb(35, 31, 14))
    )

    private val dark: Boolean
        get() = when (prefs.getString(KEY_THEME_MODE, THEME_SYSTEM)) {
            THEME_DARK -> true
            THEME_LIGHT -> false
            else -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        }
    private val palette: Palette
        get() = palettes.firstOrNull { it.name == prefs.getString(KEY_PALETTE, palettes[0].name) } ?: palettes[0]
    private val backgroundColor: Int get() = if (dark) palette.darkBg else palette.lightBg
    private val surfaceColor: Int get() = if (dark) Color.rgb(39, 36, 53) else Color.WHITE
    private val textColor: Int get() = if (dark) Color.rgb(246, 243, 252) else Color.rgb(42, 38, 55)
    private val mutedColor: Int get() = if (dark) Color.rgb(190, 183, 207) else Color.rgb(89, 82, 112)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.contains(KEY_SELECTED_PACKAGES)) {
            prefs.edit().putStringSet(KEY_SELECTED_PACKAGES, defaultPackages()).apply()
        }
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            // Follow-system mode can change while RewindYou is in the background.
            val currentDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
            if (prefs.getString(KEY_THEME_MODE, THEME_SYSTEM) == THEME_SYSTEM && currentDark != appliedSystemDark) {
                buildUi(); refresh()
            } else refresh()
        }
    }

    private var appliedSystemDark = false

    private fun buildUi() {
        appliedSystemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        // Keep system-bar icons readable in both modes by matching the bars to the page background.
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (!dark) android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0

        scroll = ScrollView(this).apply { setBackgroundColor(backgroundColor) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "⏪  RewindYou"
            textSize = 30f; setTextColor(if (dark) textColor else palette.primary); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Your music. Your history. Your rewind."
            textSize = 14f; setTextColor(mutedColor); setPadding(0, dp(5), 0, dp(12))
        })

        root.addView(section("PERSONALIZAR APARIENCIA"))
        root.addView(label("Modo de apariencia"))
        val modeSpinner = Spinner(this)
        val modes = listOf("Seguir el teléfono", "Claro", "Oscuro")
        modeSpinner.adapter = spinnerAdapter(modes)
        modeSpinner.setSelection(when (prefs.getString(KEY_THEME_MODE, THEME_SYSTEM)) { THEME_LIGHT -> 1; THEME_DARK -> 2; else -> 0 })
        root.addView(modeSpinner, matchWrap())
        modeSpinner.setOnItemSelectedListener(simpleSelection { index ->
            val value = listOf(THEME_SYSTEM, THEME_LIGHT, THEME_DARK)[index]
            if (prefs.getString(KEY_THEME_MODE, THEME_SYSTEM) != value) { prefs.edit().putString(KEY_THEME_MODE, value).apply(); buildUi(); refresh() }
        })

        root.addView(label("Paleta de colores"))
        val paletteSpinner = Spinner(this)
        paletteSpinner.adapter = spinnerAdapter(palettes.map { it.name })
        paletteSpinner.setSelection(palettes.indexOf(palette).coerceAtLeast(0))
        root.addView(paletteSpinner, matchWrap())
        paletteSpinner.setOnItemSelectedListener(simpleSelection { index ->
            val value = palettes[index].name
            if (prefs.getString(KEY_PALETTE, palettes[0].name) != value) { prefs.edit().putString(KEY_PALETTE, value).apply(); buildUi(); refresh() }
        })

        root.addView(section("REPRODUCTORES DE MÚSICA"))
        root.addView(TextView(this).apply {
            text = "Elegí las aplicaciones que querés incluir. RewindYou registrará los datos que cada reproductor comparta con las sesiones multimedia de Android."
            textSize = 14f; setTextColor(mutedColor); setPadding(0, dp(4), 0, dp(8))
        })
        playersSummary = cardText(root)
        root.addView(button("Elegir reproductores instalados") { choosePlayers() }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Samsung Music y Musicolet están seleccionados inicialmente. Algunas aplicaciones podrían no exponer sus datos multimedia, aunque estén seleccionadas."
            textSize = 13f; setTextColor(mutedColor); setPadding(0, dp(4), 0, dp(12))
        })

        root.addView(section("PERMISOS Y FUNCIONAMIENTO"))
        root.addView(button("1 · Habilitar acceso multimedia") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "En esa pantalla, activá RewindYou. Es un permiso especial de Android necesario para detectar las sesiones de reproducción."
            textSize = 13f; setTextColor(mutedColor); setPadding(0, dp(5), 0, dp(14))
        })
        root.addView(button("2 · Abrir ajustes de batería") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:$packageName")))
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Para mejorar la continuidad en Samsung, podés revisar los ajustes de batería. Android todavía puede suspender el registro en algunas situaciones."
            textSize = 13f; setTextColor(mutedColor); setPadding(0, dp(5), 0, dp(14))
        })

        root.addView(section("ESTADO"))
        status = cardText(root)
        root.addView(button("Actualizar estado y estadísticas") { refresh() }, matchWrap())
        root.addView(section("TUS ESTADÍSTICAS"))
        stats = cardText(root)
        root.addView(section("TOP 5 CANCIONES"))
        top = cardText(root)

        root.addView(section("RESÚMENES"))
        root.addView(TextView(this).apply {
            text = "Generá a mano un resumen de tu escucha por semana, mes o año. Las semanas empiezan el lunes."
            textSize = 14f; setTextColor(mutedColor); setPadding(0, dp(4), 0, dp(8))
        })
        root.addView(buttonRow(
            button("Semana") { showSummary(Period.WEEK, 0) },
            button("Mes") { showSummary(Period.MONTH, 0) },
            button("Año") { showSummary(Period.YEAR, 0) }
        ), matchWrap())
        summaryCard = cardText(root)
        root.addView(buttonRow(
            button("◀ Anterior") { stepSummary(-1) },
            button("Siguiente ▶") { stepSummary(1) }
        ), matchWrap())
        root.addView(button("Compartir resumen") { shareSummary() }, matchWrap())

        root.addView(TextView(this).apply {
            text = "Los resúmenes gráficos y las carátulas se añadirán en próximas etapas."
            textSize = 12f; setTextColor(mutedColor); setPadding(0, dp(20), 0, 0)
        })
    }

    private fun choosePlayers() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)
        val apps = resolved.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            InstalledApp(pkg, info.loadLabel(packageManager).toString())
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        val selected = prefs.getStringSet(KEY_SELECTED_PACKAGES, defaultPackages())?.toMutableSet() ?: defaultPackages().toMutableSet()
        val labels = apps.map { "${it.label}\n${it.packageName}" }.toTypedArray()
        val checked = apps.map { it.packageName in selected }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Elegir reproductores")
            // Se omite setMessage para que la lista de aplicaciones se muestre correctamente.
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) selected.add(apps[which].packageName) else selected.remove(apps[which].packageName)
            }
            .setNeutralButton("Restablecer sugeridos") { _, _ ->
                prefs.edit().putStringSet(KEY_SELECTED_PACKAGES, defaultPackages()).apply(); refresh()
            }
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putStringSet(KEY_SELECTED_PACKAGES, selected.toSet()).apply()
                refresh()
            }
            .show()
    }

    private fun refresh() {
        val enabled = isListenerEnabled()
        status.text = if (enabled) "Acceso multimedia: habilitado\nAndroid puede entregar sesiones de los reproductores seleccionados." else "Acceso multimedia: falta habilitarlo\nUsá el botón de arriba y activá RewindYou en los ajustes de Android."
        val selected = prefs.getStringSet(KEY_SELECTED_PACKAGES, defaultPackages()).orEmpty()
        val names = installedApps().filter { it.packageName in selected }.map { it.label }.sorted()
        playersSummary.text = if (names.isEmpty()) "No seleccionaste reproductores." else "Reproductores seleccionados (${names.size}):\n" + names.joinToString("\n") { "• $it" }
        val t = db.totals()
        stats.text = "Canciones distintas: ${t.uniqueTracks}\nReproducciones contabilizadas: ${t.plays}\nTiempo registrado: ${formatDuration(t.listenedMs)}"
        val rows = db.topTracks(5)
        top.text = if (rows.isEmpty()) "Todavía no hay canciones registradas. Habilitá el acceso y reproducí música en una de las apps seleccionadas." else rows.mapIndexed { i, s -> "${i + 1}. ${s.title}\n   ${s.artist} · ${s.plays} ${if (s.plays == 1) "reproducción" else "reproducciones"}" }.joinToString("\n\n")
        val period = summaryPeriod
        if (period == null) summaryCard.text = "Elegí un período para generar tu resumen." else showSummary(period, summaryOffset)
    }

    private fun stepSummary(delta: Int) {
        val period = summaryPeriod ?: return
        val next = summaryOffset + delta
        if (next > 0) return // no hay resúmenes del futuro
        showSummary(period, next)
    }

    private fun showSummary(period: Period, offset: Int) {
        summaryPeriod = period
        summaryOffset = offset
        val (from, to) = periodRange(period, offset)
        val s = db.summary(from, to, 5)
        val es = Locale.forLanguageTag("es")
        val header = "${period.title} · ${periodLabel(period, from, to)}" + (if (offset == 0) " (en curso)" else "")
        val body = if (s.plays == 0 && s.listenedMs == 0L) "No hay escucha registrada en este período." else buildString {
            append("Tiempo escuchado: ${formatDuration(s.listenedMs)}\n")
            append("Reproducciones: ${s.plays}\n")
            append("Canciones distintas: ${s.uniqueTracks}")
            s.busiestDayMs?.let { append("\nDía más activo: ${SimpleDateFormat("EEEE d 'de' MMMM", es).format(Date(it))}") }
            if (s.topTracks.isNotEmpty()) {
                append("\n\nTop canciones")
                s.topTracks.forEachIndexed { i, t -> append("\n${i + 1}. ${t.title}\n   ${t.artist} · ${playsLabel(t.plays)}") }
            }
            if (s.topArtists.isNotEmpty()) {
                append("\n\nTop artistas")
                s.topArtists.forEachIndexed { i, a -> append("\n${i + 1}. ${a.artist} · ${playsLabel(a.plays)}") }
            }
        }
        summaryText = "$header\n\n$body"
        summaryCard.text = summaryText
    }

    private fun shareSummary() {
        val text = summaryText
        if (text == null) {
            android.widget.Toast.makeText(this, "Primero generá un resumen.", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartir resumen"))
    }

    /** Start (inclusive) and end (exclusive) of the period, in milliseconds. [offset] 0 = current, -1 = previous... */
    private fun periodRange(period: Period, offset: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        when (period) {
            Period.WEEK -> {
                cal.add(Calendar.DAY_OF_YEAR, -((cal.get(Calendar.DAY_OF_WEEK) + 5) % 7)) // vuelve al lunes
                cal.add(Calendar.DAY_OF_YEAR, 7 * offset)
            }
            Period.MONTH -> { cal.set(Calendar.DAY_OF_MONTH, 1); cal.add(Calendar.MONTH, offset) }
            Period.YEAR -> { cal.set(Calendar.MONTH, Calendar.JANUARY); cal.set(Calendar.DAY_OF_MONTH, 1); cal.add(Calendar.YEAR, offset) }
        }
        val start = cal.timeInMillis
        when (period) {
            Period.WEEK -> cal.add(Calendar.DAY_OF_YEAR, 7)
            Period.MONTH -> cal.add(Calendar.MONTH, 1)
            Period.YEAR -> cal.add(Calendar.YEAR, 1)
        }
        return start to cal.timeInMillis
    }

    private fun periodLabel(period: Period, startMs: Long, endMs: Long): String {
        val es = Locale.forLanguageTag("es")
        return when (period) {
            Period.WEEK -> "${SimpleDateFormat("d MMM", es).format(Date(startMs))} – ${SimpleDateFormat("d MMM yyyy", es).format(Date(endMs - 1))}"
            Period.MONTH -> SimpleDateFormat("MMMM yyyy", es).format(Date(startMs)).replaceFirstChar { it.uppercase() }
            Period.YEAR -> SimpleDateFormat("yyyy", es).format(Date(startMs))
        }
    }

    private fun playsLabel(n: Int) = "$n ${if (n == 1) "reproducción" else "reproducciones"}"

    private fun installedApps(): List<InstalledApp> = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .mapNotNull { info -> val pkg = info.activityInfo?.packageName ?: return@mapNotNull null; if (pkg == packageName) null else InstalledApp(pkg, info.loadLabel(packageManager).toString()) }
        .distinctBy { it.packageName }

    private fun isListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(palette.secondary); setPadding(0, dp(16), 0, dp(8))
    }
    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 14f; setTextColor(textColor); setPadding(0, dp(3), 0, dp(4)) }
    private fun cardText(parent: LinearLayout) = TextView(this).apply {
        textSize = 15f; setTextColor(textColor); setPadding(dp(14), dp(14), dp(14), dp(14)); setBackgroundColor(surfaceColor)
        root.addView(this, matchWrap())
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        backgroundTintList = ColorStateList.valueOf(palette.primary)
        setTextColor(Color.WHITE)
        setOnClickListener { action() }
    }
    private fun buttonRow(vararg buttons: Button) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        buttons.forEachIndexed { i, b ->
            addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i < buttons.size - 1) marginEnd = dp(8) })
        }
    }
    private fun spinnerAdapter(items: List<String>) = ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
    private fun simpleSelection(action: (Int) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        private var first = true
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
            if (first) { first = false; return }; action(position)
        }
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatDuration(ms: Long): String = DateUtils.formatElapsedTime(ms / 1000L)

    private fun defaultPackages() = setOf(PKG_SAMSUNG_MUSIC, PKG_MUSICOLET)

    companion object {
        const val PREFS = "rewindyou_preferences"
        const val KEY_SAMSUNG_MUSIC = "samsung_music"
        const val KEY_YOUTUBE_MUSIC = "youtube_music"
        const val KEY_MUSICOLET = "musicolet"
        const val KEY_SELECTED_PACKAGES = "selected_music_packages"
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_PALETTE = "color_palette"
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        const val PKG_SAMSUNG_MUSIC = "com.sec.android.app.music"
        const val PKG_YOUTUBE_MUSIC = "com.google.android.apps.youtube.music"
        const val PKG_MUSICOLET = "in.krosbits.musicolet"
    }
}
