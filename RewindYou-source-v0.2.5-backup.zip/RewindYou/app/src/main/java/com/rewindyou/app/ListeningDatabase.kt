package com.rewindyou.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only store. Each listening attempt is one row in `segments`; an attempt counts as a play after 30 s of listening. */
class ListeningDatabase(context: Context) : SQLiteOpenHelper(context, "rewindyou.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            source_package TEXT NOT NULL,
            plays INTEGER NOT NULL DEFAULT 0,
            listened_ms INTEGER NOT NULL DEFAULT 0,
            last_played_ms INTEGER NOT NULL,
            UNIQUE(title, artist)
        )""")
        db.execSQL("CREATE TABLE segments (id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, started_ms INTEGER NOT NULL, listened_ms INTEGER NOT NULL, counted_as_play INTEGER NOT NULL, FOREIGN KEY(track_id) REFERENCES tracks(id))")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    /**
     * Adds listening progress for one attempt (one pass at a song, pauses included).
     * [segmentId] <= 0 creates the attempt's row in `segments`; otherwise that row is extended.
     * [countPlay] adds one play to the track and flags the segment as a play. Returns the segment id.
     */
    @Synchronized
    fun recordProgress(segmentId: Long, title: String, artist: String, sourcePackage: String, startedMs: Long, deltaMs: Long, countPlay: Boolean): Long {
        if (title.isBlank() || (deltaMs <= 0L && !countPlay)) return segmentId
        val cleanTitle = title.trim()
        val cleanArtist = artist.ifBlank { "Artista desconocido" }.trim()
        val plays = if (countPlay) 1 else 0
        val now = System.currentTimeMillis()
        val db = writableDatabase
        var id = segmentId
        db.beginTransaction()
        try {
            val values = ContentValues().apply {
                put("title", cleanTitle)
                put("artist", cleanArtist)
                put("source_package", sourcePackage)
                put("last_played_ms", now)
            }
            db.insertWithOnConflict("tracks", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            val trackId = db.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=?", arrayOf(cleanTitle, cleanArtist))
                .use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            check(trackId > 0) { "track row not found" }
            db.execSQL("UPDATE tracks SET plays=plays+?, listened_ms=listened_ms+?, last_played_ms=? WHERE id=?", arrayOf(plays, deltaMs, now, trackId))
            if (id > 0) {
                db.execSQL("UPDATE segments SET listened_ms=listened_ms+?, counted_as_play=MAX(counted_as_play, ?) WHERE id=?", arrayOf(deltaMs, plays, id))
            } else {
                db.execSQL("INSERT INTO segments(track_id, started_ms, listened_ms, counted_as_play) VALUES(?,?,?,?)", arrayOf(trackId, startedMs, deltaMs, plays))
                id = db.rawQuery("SELECT last_insert_rowid()", null).use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return id
    }

    fun totals(): Totals {
        readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(SUM(plays),0), COALESCE(SUM(listened_ms),0) FROM tracks", null).use { c ->
            if (c.moveToFirst()) return Totals(c.getInt(0), c.getInt(1), c.getLong(2))
        }
        return Totals(0, 0, 0L)
    }

    fun topTracks(limit: Int = 5): List<TrackStat> {
        val out = mutableListOf<TrackStat>()
        readableDatabase.rawQuery("SELECT title, artist, source_package, plays, listened_ms FROM tracks ORDER BY plays DESC, listened_ms DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4))
        }
        return out
    }

    /**
     * Summary of the listening whose attempt started in [fromMs, toMs).
     * Uses only the existing `segments` table, so no schema change is needed.
     */
    fun summary(fromMs: Long, toMs: Long, limit: Int = 5): PeriodSummary {
        val range = arrayOf(fromMs.toString(), toMs.toString())
        val rdb = readableDatabase
        var listenedMs = 0L
        var plays = 0
        var unique = 0
        rdb.rawQuery("SELECT COALESCE(SUM(listened_ms),0), COALESCE(SUM(counted_as_play),0), COUNT(DISTINCT track_id) FROM segments WHERE started_ms >= ? AND started_ms < ?", range).use { c ->
            if (c.moveToFirst()) { listenedMs = c.getLong(0); plays = c.getInt(1); unique = c.getInt(2) }
        }
        var busiestDayMs: Long? = null
        rdb.rawQuery("SELECT MIN(started_ms) FROM segments WHERE started_ms >= ? AND started_ms < ? GROUP BY strftime('%Y-%m-%d', started_ms/1000, 'unixepoch', 'localtime') ORDER BY SUM(listened_ms) DESC LIMIT 1", range).use { c ->
            if (c.moveToFirst()) busiestDayMs = c.getLong(0)
        }
        val tracks = mutableListOf<TrackStat>()
        rdb.rawQuery("SELECT t.title, t.artist, t.source_package, SUM(s.counted_as_play) AS p, SUM(s.listened_ms) AS ms FROM segments s JOIN tracks t ON t.id = s.track_id WHERE s.started_ms >= ? AND s.started_ms < ? GROUP BY t.id HAVING p > 0 ORDER BY p DESC, ms DESC LIMIT ?", arrayOf(range[0], range[1], limit.toString())).use { c ->
            while (c.moveToNext()) tracks += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4))
        }
        val artists = mutableListOf<ArtistStat>()
        rdb.rawQuery("SELECT t.artist, SUM(s.counted_as_play) AS p, SUM(s.listened_ms) AS ms FROM segments s JOIN tracks t ON t.id = s.track_id WHERE s.started_ms >= ? AND s.started_ms < ? GROUP BY t.artist HAVING p > 0 ORDER BY p DESC, ms DESC LIMIT ?", arrayOf(range[0], range[1], limit.toString())).use { c ->
            while (c.moveToNext()) artists += ArtistStat(c.getString(0), c.getInt(1), c.getLong(2))
        }
        return PeriodSummary(listenedMs, plays, unique, busiestDayMs, tracks, artists)
    }

    /** Whole database as JSON text, for backups. */
    @Synchronized
    fun exportJson(): String {
        val rdb = readableDatabase
        val tracks = org.json.JSONArray()
        rdb.rawQuery("SELECT id, title, artist, source_package, plays, listened_ms, last_played_ms FROM tracks ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                tracks.put(org.json.JSONObject()
                    .put("id", c.getLong(0)).put("title", c.getString(1)).put("artist", c.getString(2))
                    .put("source_package", c.getString(3)).put("plays", c.getInt(4))
                    .put("listened_ms", c.getLong(5)).put("last_played_ms", c.getLong(6)))
            }
        }
        val segments = org.json.JSONArray()
        rdb.rawQuery("SELECT track_id, started_ms, listened_ms, counted_as_play FROM segments ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                segments.put(org.json.JSONObject()
                    .put("track_id", c.getLong(0)).put("started_ms", c.getLong(1))
                    .put("listened_ms", c.getLong(2)).put("counted_as_play", c.getInt(3)))
            }
        }
        return org.json.JSONObject()
            .put("app", "RewindYou").put("format", 1).put("exported_ms", System.currentTimeMillis())
            .put("tracks", tracks).put("segments", segments).toString()
    }

    /**
     * Replaces ALL data with the content of a backup made by [exportJson].
     * Runs in one transaction: if the file is invalid nothing changes. Returns (songs, attempts) imported.
     */
    @Synchronized
    fun importJson(text: String): Pair<Int, Int> {
        val root = org.json.JSONObject(text)
        require(root.optString("app") == "RewindYou" && root.optInt("format", 0) == 1) { "Not a RewindYou backup" }
        val tracks = root.getJSONArray("tracks")
        val segments = root.getJSONArray("segments")
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM segments")
            db.execSQL("DELETE FROM tracks")
            for (i in 0 until tracks.length()) {
                val t = tracks.getJSONObject(i)
                val values = ContentValues().apply {
                    put("id", t.getLong("id"))
                    put("title", t.getString("title"))
                    put("artist", t.getString("artist"))
                    put("source_package", t.optString("source_package", ""))
                    put("plays", t.getInt("plays"))
                    put("listened_ms", t.getLong("listened_ms"))
                    put("last_played_ms", t.getLong("last_played_ms"))
                }
                db.insertOrThrow("tracks", null, values)
            }
            for (i in 0 until segments.length()) {
                val g = segments.getJSONObject(i)
                val values = ContentValues().apply {
                    put("track_id", g.getLong("track_id"))
                    put("started_ms", g.getLong("started_ms"))
                    put("listened_ms", g.getLong("listened_ms"))
                    put("counted_as_play", g.getInt("counted_as_play"))
                }
                db.insertOrThrow("segments", null, values)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return tracks.length() to segments.length()
    }

    companion object { const val MIN_PLAY_MS = 30_000L }
}

data class Totals(val uniqueTracks: Int, val plays: Int, val listenedMs: Long)
data class TrackStat(val title: String, val artist: String, val sourcePackage: String, val plays: Int, val listenedMs: Long)
data class ArtistStat(val artist: String, val plays: Int, val listenedMs: Long)
data class PeriodSummary(val listenedMs: Long, val plays: Int, val uniqueTracks: Int, val busiestDayMs: Long?, val topTracks: List<TrackStat>, val topArtists: List<ArtistStat>)
