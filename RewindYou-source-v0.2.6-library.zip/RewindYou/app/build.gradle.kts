plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rewindyou.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rewindyou.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.2.6"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
