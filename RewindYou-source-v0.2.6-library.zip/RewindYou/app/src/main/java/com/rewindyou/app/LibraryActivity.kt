package com.rewindyou.app

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * Full ranking of songs and artists with search. Tapping a song edits its title/artist;
 * tapping an artist renames it on all of their songs.
 */
class LibraryActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }

    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var summary: TextView
    private lateinit var adapter: RowAdapter
    private lateinit var songsButton: Button
    private lateinit var artistsButton: Button

    private var showArtists = false
    private var allTracks: List<LibraryTrack> = emptyList()
    private var allArtists: List<LibraryArtist> = emptyList()
    private val shown = mutableListOf<Any>()   // same order as the rows on screen

    // Same look as MainActivity: it follows the mode and palette chosen there.
    private val dark: Boolean
        get() = when (prefs.getString(MainActivity.KEY_THEME_MODE, MainActivity.THEME_SYSTEM)) {
            MainActivity.THEME_DARK -> true
            MainActivity.THEME_LIGHT -> false
            else -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        }
    private val palette: MainActivity.Palette
        get() = MainActivity.PALETTES.firstOrNull { it.name == prefs.getString(MainActivity.KEY_PALETTE, MainActivity.PALETTES[0].name) } ?: MainActivity.PALETTES[0]
    private val backgroundColor: Int get() = if (dark) palette.darkBg else palette.lightBg
    private val surfaceColor: Int get() = if (dark) Color.rgb(39, 36, 53) else Color.WHITE
    private val textColor: Int get() = if (dark) Color.rgb(246, 243, 252) else Color.rgb(42, 38, 55)
    private val mutedColor: Int get() = if (dark) Color.rgb(190, 183, 207) else Color.rgb(89, 82, 112)
    private val inactiveColor: Int get() = if (dark) Color.rgb(78, 73, 101) else Color.rgb(160, 154, 184)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (!dark) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backgroundColor)
            fitsSystemWindows = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(8))
        }
        page.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(button("◀") { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(TextView(this).apply {
            text = "Ranking completo"
            textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (dark) textColor else palette.primary)
            setPadding(dp(12), 0, 0, 0)
        })
        content.addView(header, matchWrap())

        songsButton = button("Canciones") { setMode(false) }
        artistsButton = button("Artistas") { setMode(true) }
        content.addView(buttonRow(songsButton, artistsButton), matchWrap())

        search = EditText(this).apply {
            hint = "Buscar por título o artista"
            setSingleLine()
            textSize = 15f
            setTextColor(textColor)
            setHintTextColor(mutedColor)
            backgroundTintList = ColorStateList.valueOf(palette.secondary)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) { render() }
            })
        }
        content.addView(search, matchWrap())

        summary = TextView(this).apply {
            textSize = 13f; setTextColor(mutedColor); setPadding(0, dp(2), 0, dp(8))
        }
        content.addView(summary)

        adapter = RowAdapter(mutableListOf())
        list = ListView(this).apply {
            divider = ColorDrawable(backgroundColor)
            dividerHeight = dp(6)
            setBackgroundColor(backgroundColor)
            setOnItemClickListener { _, _, position, _ -> onRowClick(position) }
        }
        list.adapter = adapter
        content.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        allTracks = db.allTracks()
        allArtists = db.allArtists()
        updateModeButtons()
        render()
    }

    private fun setMode(artists: Boolean) {
        showArtists = artists
        updateModeButtons()
        render()
    }

    private fun updateModeButtons() {
        songsButton.backgroundTintList = ColorStateList.valueOf(if (!showArtists) palette.primary else inactiveColor)
        artistsButton.backgroundTintList = ColorStateList.valueOf(if (showArtists) palette.primary else inactiveColor)
    }

    private fun render() {
        val query = search.text.toString().trim().lowercase()
        shown.clear()
        val labels = mutableListOf<String>()
        if (!showArtists) {
            allTracks.forEachIndexed { index, t ->
                if (query.isEmpty() || t.title.lowercase().contains(query) || t.artist.lowercase().contains(query)) {
                    shown += t
                    labels += "${index + 1}. ${t.title}\n    ${t.artist} · ${playsLabel(t.plays)}"
                }
            }
            summary.text = if (allTracks.isEmpty()) "Todavía no hay canciones registradas." else "${shown.size} de ${allTracks.size} canciones · tocá una para editarla"
        } else {
            allArtists.forEachIndexed { index, a ->
                if (query.isEmpty() || a.artist.lowercase().contains(query)) {
                    shown += a
                    labels += "${index + 1}. ${a.artist}\n    ${playsLabel(a.plays)} · ${a.songs} ${if (a.songs == 1) "canción" else "canciones"}"
                }
            }
            summary.text = if (allArtists.isEmpty()) "Todavía no hay artistas registrados." else "${shown.size} de ${allArtists.size} artistas · tocá uno para renombrarlo"
        }
        adapter.clear()
        adapter.addAll(labels)
    }

    private fun onRowClick(position: Int) {
        when (val item = shown.getOrNull(position)) {
            is LibraryTrack -> editTrack(item)
            is LibraryArtist -> editArtist(item)
            else -> Unit
        }
    }

    private fun editTrack(track: LibraryTrack) {
        val titleInput = EditText(this).apply { setText(track.title); hint = "Título"; setSingleLine() }
        val artistInput = EditText(this).apply { setText(track.artist); hint = "Artista"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(titleInput)
            addView(artistInput)
        }
        AlertDialog.Builder(this)
            .setTitle("Editar canción")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ -> saveTrack(track, titleInput.text.toString(), artistInput.text.toString()) }
            .show()
    }

    private fun saveTrack(track: LibraryTrack, rawTitle: String, rawArtist: String) {
        val title = rawTitle.trim()
        val artist = rawArtist.trim().ifBlank { ListeningDatabase.UNKNOWN_ARTIST }
        if (title.isEmpty()) { toast("El título no puede estar vacío."); return }
        if (title == track.title && artist == track.artist) return
        val existing = db.findTrackId(title, artist)
        if (existing != null && existing != track.id) {
            AlertDialog.Builder(this)
                .setTitle("Unir canciones")
                .setMessage("Ya existe «$title» de $artist. ¿Querés unirlas? Sus reproducciones y su tiempo se suman, y no se puede deshacer.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Unir") { _, _ -> applyEdit(track.id, title, artist) }
                .show()
        } else {
            applyEdit(track.id, title, artist)
        }
    }

    private fun applyEdit(id: Long, title: String, artist: String) {
        try {
            db.updateTrack(id, title, artist)
            toast("Cambios guardados.")
            reload()
        } catch (e: Exception) {
            toast("No se pudo guardar: ${e.message}")
        }
    }

    private fun editArtist(artist: LibraryArtist) {
        val input = EditText(this).apply { setText(artist.artist); hint = "Artista"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Renombrar artista")
            .setMessage("Se cambia en las ${artist.songs} canciones de este artista. Si alguna queda igual a otra que ya existe, se unen.")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim().ifBlank { ListeningDatabase.UNKNOWN_ARTIST }
                if (newName == artist.artist) return@setPositiveButton
                try {
                    val count = db.renameArtist(artist.artist, newName)
                    toast("Listo: $count canciones actualizadas.")
                    reload()
                } catch (e: Exception) {
                    toast("No se pudo guardar: ${e.message}")
                }
            }
            .show()
    }

    private inner class RowAdapter(items: MutableList<String>) : ArrayAdapter<String>(this@LibraryActivity, 0, items) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = (convertView as? TextView) ?: TextView(this@LibraryActivity).apply {
                textSize = 15f
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            view.text = getItem(position)
            view.setTextColor(textColor)
            view.setBackgroundColor(surfaceColor)
            return view
        }
    }

    private fun playsLabel(n: Int) = "$n ${if (n == 1) "reproducción" else "reproducciones"}"
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        backgroundTintList = ColorStateList.valueOf(palette.primary)
        setTextColor(Color.WHITE)
        setOnClickListener { action() }
    }
    private fun buttonRow(vararg buttons: Button) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        buttons.forEachIndexed { i, b ->
            addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i < buttons.size - 1) marginEnd = dp(8) })
        }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
