plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rewindyou.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rewindyou.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.3.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
