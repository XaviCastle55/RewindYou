package com.rewindyou.app

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * Full ranking of songs and artists with search. Tapping a song edits its title/artist;
 * tapping an artist renames it on all of their songs.
 */
class LibraryActivity : Activity() {
    private val db by lazy { ListeningDatabase(this) }
    private val ui by lazy { Ui(this) }

    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var summary: TextView
    private lateinit var adapter: RowAdapter
    private lateinit var modeHolder: LinearLayout

    private var showArtists = false
    private var allTracks: List<LibraryTrack> = emptyList()
    private var allArtists: List<LibraryArtist> = emptyList()
    private val shown = mutableListOf<Any>()   // same order as the rows on screen

    private data class RowItem(val rank: Int, val title: String, val subtitle: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui.applySystemBars(window)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(8))
        }
        page.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ui.button("◀", filled = false) { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(ui.label("Ranking completo", 22f, ui.textColor, true).apply { setPadding(ui.dp(14), 0, 0, 0) })
        content.addView(header, ui.matchWrap(10))

        modeHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(modeHolder, ui.matchWrap(10))

        search = EditText(this).apply {
            hint = "Buscar por título o artista"
            setSingleLine()
            textSize = 15f
            setTextColor(ui.textColor)
            setHintTextColor(ui.mutedColor)
            background = ui.rounded(ui.surfaceColor, 14, ui.outlineColor, 1)
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) { render() }
            })
        }
        content.addView(search, ui.matchWrap(6))

        summary = ui.label("", 13f, ui.mutedColor).apply { setPadding(ui.dp(4), ui.dp(2), 0, ui.dp(8)) }
        content.addView(summary)

        adapter = RowAdapter(mutableListOf())
        list = ListView(this).apply {
            divider = ColorDrawable(ui.backgroundColor)
            dividerHeight = ui.dp(8)
            setBackgroundColor(ui.backgroundColor)
            setOnItemClickListener { _, _, position, _ -> onRowClick(position) }
        }
        list.adapter = adapter
        content.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        allTracks = db.allTracks()
        allArtists = db.allArtists()
        renderModeControl()
        render()
    }

    private fun setMode(artists: Boolean) {
        showArtists = artists
        renderModeControl()
        render()
    }

    private fun renderModeControl() {
        modeHolder.removeAllViews()
        modeHolder.addView(ui.segmented(listOf("Canciones", "Artistas"), if (showArtists) 1 else 0) { index -> setMode(index == 1) })
    }

    private fun render() {
        val query = search.text.toString().trim().lowercase()
        shown.clear()
        val rows = mutableListOf<RowItem>()
        if (!showArtists) {
            allTracks.forEachIndexed { index, t ->
                if (query.isEmpty() || t.title.lowercase().contains(query) || t.artist.lowercase().contains(query)) {
                    shown += t
                    rows += RowItem(index + 1, t.title, "${t.artist} · ${ui.playsLabel(t.plays)}")
                }
            }
            summary.text = if (allTracks.isEmpty()) "Todavía no hay canciones registradas." else "${shown.size} de ${allTracks.size} canciones · tocá una para editarla"
        } else {
            allArtists.forEachIndexed { index, a ->
                if (query.isEmpty() || a.artist.lowercase().contains(query)) {
                    shown += a
                    rows += RowItem(index + 1, a.artist, "${ui.playsLabel(a.plays)} · ${a.songs} ${if (a.songs == 1) "canción" else "canciones"}")
                }
            }
            summary.text = if (allArtists.isEmpty()) "Todavía no hay artistas registrados." else "${shown.size} de ${allArtists.size} artistas · tocá uno para renombrarlo"
        }
        adapter.clear()
        adapter.addAll(rows)
    }

    private fun onRowClick(position: Int) {
        when (val item = shown.getOrNull(position)) {
            is LibraryTrack -> editTrack(item)
            is LibraryArtist -> editArtist(item)
            else -> Unit
        }
    }

    private fun editTrack(track: LibraryTrack) {
        val titleInput = EditText(this).apply { setText(track.title); hint = "Título"; setSingleLine() }
        val artistInput = EditText(this).apply { setText(track.artist); hint = "Artista"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(titleInput)
            addView(artistInput)
        }
        AlertDialog.Builder(this)
            .setTitle("Editar canción")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ -> saveTrack(track, titleInput.text.toString(), artistInput.text.toString()) }
            .show()
    }

    private fun saveTrack(track: LibraryTrack, rawTitle: String, rawArtist: String) {
        val title = rawTitle.trim()
        val artist = rawArtist.trim().ifBlank { ListeningDatabase.UNKNOWN_ARTIST }
        if (title.isEmpty()) { toast("El título no puede estar vacío."); return }
        if (title == track.title && artist == track.artist) return
        val existing = db.findTrackId(title, artist)
        if (existing != null && existing != track.id) {
            AlertDialog.Builder(this)
                .setTitle("Unir canciones")
                .setMessage("Ya existe «$title» de $artist. ¿Querés unirlas? Sus reproducciones y su tiempo se suman, y no se puede deshacer.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Unir") { _, _ -> applyEdit(track.id, title, artist) }
                .show()
        } else {
            applyEdit(track.id, title, artist)
        }
    }

    private fun applyEdit(id: Long, title: String, artist: String) {
        try {
            db.updateTrack(id, title, artist)
            toast("Cambios guardados.")
            reload()
        } catch (e: Exception) {
            toast("No se pudo guardar: ${e.message}")
        }
    }

    private fun editArtist(artist: LibraryArtist) {
        val input = EditText(this).apply { setText(artist.artist); hint = "Artista"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Renombrar artista")
            .setMessage("Se cambia en las ${artist.songs} canciones de este artista. Si alguna queda igual a otra que ya existe, se unen.")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim().ifBlank { ListeningDatabase.UNKNOWN_ARTIST }
                if (newName == artist.artist) return@setPositiveButton
                try {
                    val count = db.renameArtist(artist.artist, newName)
                    toast("Listo: $count canciones actualizadas.")
                    reload()
                } catch (e: Exception) {
                    toast("No se pudo guardar: ${e.message}")
                }
            }
            .show()
    }

    private inner class RowAdapter(items: MutableList<RowItem>) : ArrayAdapter<RowItem>(this@LibraryActivity, 0, items) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: ui.rankRow().apply {
                background = ui.rounded(ui.surfaceColor, 16, ui.outlineColor, 1)
                setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10))
            }
            val item = getItem(position)
            if (item != null) ui.bindRankRow(row, item.rank, item.title, item.subtitle)
            return row
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
