package com.rewindyou.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only store. Each listening attempt is one row in `segments`; an attempt counts as a play after 30 s of listening. */
class ListeningDatabase(context: Context) : SQLiteOpenHelper(context, "rewindyou.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            source_package TEXT NOT NULL,
            plays INTEGER NOT NULL DEFAULT 0,
            listened_ms INTEGER NOT NULL DEFAULT 0,
            last_played_ms INTEGER NOT NULL,
            UNIQUE(title, artist)
        )""")
        db.execSQL("CREATE TABLE segments (id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, started_ms INTEGER NOT NULL, listened_ms INTEGER NOT NULL, counted_as_play INTEGER NOT NULL, FOREIGN KEY(track_id) REFERENCES tracks(id))")
        createAliasTable(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Additive migration: existing statistics are kept untouched.
        if (oldVersion < 2) createAliasTable(db)
    }

    /** Remembers manual corrections: what the player reports (orig) -> what the user wants stored (new). */
    private fun createAliasTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS aliases (orig_title TEXT NOT NULL, orig_artist TEXT NOT NULL, new_title TEXT NOT NULL, new_artist TEXT NOT NULL, PRIMARY KEY(orig_title, orig_artist))")
    }

    /**
     * Adds listening progress for one attempt (one pass at a song, pauses included).
     * [segmentId] <= 0 creates the attempt's row in `segments`; otherwise that row is extended.
     * [countPlay] adds one play to the track and flags the segment as a play. Returns the segment id.
     */
    @Synchronized
    fun recordProgress(segmentId: Long, title: String, artist: String, sourcePackage: String, startedMs: Long, deltaMs: Long, countPlay: Boolean): Long {
        if (title.isBlank() || (deltaMs <= 0L && !countPlay)) return segmentId
        var cleanTitle = title.trim()
        var cleanArtist = artist.ifBlank { UNKNOWN_ARTIST }.trim()
        val plays = if (countPlay) 1 else 0
        val now = System.currentTimeMillis()
        val db = writableDatabase
        var id = segmentId
        db.beginTransaction()
        try {
            // Apply the user's manual corrections, if this song was edited before.
            db.rawQuery("SELECT new_title, new_artist FROM aliases WHERE orig_title=? AND orig_artist=?", arrayOf(cleanTitle, cleanArtist)).use { c ->
                if (c.moveToFirst()) { cleanTitle = c.getString(0); cleanArtist = c.getString(1) }
            }
            val values = ContentValues().apply {
                put("title", cleanTitle)
                put("artist", cleanArtist)
                put("source_package", sourcePackage)
                put("last_played_ms", now)
            }
            db.insertWithOnConflict("tracks", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            val trackId = db.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=?", arrayOf(cleanTitle, cleanArtist))
                .use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            check(trackId > 0) { "track row not found" }
            db.execSQL("UPDATE tracks SET plays=plays+?, listened_ms=listened_ms+?, last_played_ms=? WHERE id=?", arrayOf(plays, deltaMs, now, trackId))
            if (id > 0) {
                db.execSQL("UPDATE segments SET listened_ms=listened_ms+?, counted_as_play=MAX(counted_as_play, ?) WHERE id=?", arrayOf(deltaMs, plays, id))
            } else {
                db.execSQL("INSERT INTO segments(track_id, started_ms, listened_ms, counted_as_play) VALUES(?,?,?,?)", arrayOf(trackId, startedMs, deltaMs, plays))
                id = db.rawQuery("SELECT last_insert_rowid()", null).use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return id
    }

    fun totals(): Totals {
        readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(SUM(plays),0), COALESCE(SUM(listened_ms),0) FROM tracks", null).use { c ->
            if (c.moveToFirst()) return Totals(c.getInt(0), c.getInt(1), c.getLong(2))
        }
        return Totals(0, 0, 0L)
    }

    fun topTracks(limit: Int = 5): List<TrackStat> {
        val out = mutableListOf<TrackStat>()
        readableDatabase.rawQuery("SELECT title, artist, source_package, plays, listened_ms FROM tracks ORDER BY plays DESC, listened_ms DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4))
        }
        return out
    }

    /**
     * Summary of the listening whose attempt started in [fromMs, toMs).
     * Uses only the existing `segments` table, so no schema change is needed.
     */
    fun summary(fromMs: Long, toMs: Long, limit: Int = 5): PeriodSummary {
        val range = arrayOf(fromMs.toString(), toMs.toString())
        val rdb = readableDatabase
        var listenedMs = 0L
        var plays = 0
        var unique = 0
        rdb.rawQuery("SELECT COALESCE(SUM(listened_ms),0), COALESCE(SUM(counted_as_play),0), COUNT(DISTINCT track_id) FROM segments WHERE started_ms >= ? AND started_ms < ?", range).use { c ->
            if (c.moveToFirst()) { listenedMs = c.getLong(0); plays = c.getInt(1); unique = c.getInt(2) }
        }
        var busiestDayMs: Long? = null
        rdb.rawQuery("SELECT MIN(started_ms) FROM segments WHERE started_ms >= ? AND started_ms < ? GROUP BY strftime('%Y-%m-%d', started_ms/1000, 'unixepoch', 'localtime') ORDER BY SUM(listened_ms) DESC LIMIT 1", range).use { c ->
            if (c.moveToFirst()) busiestDayMs = c.getLong(0)
        }
        val tracks = mutableListOf<TrackStat>()
        rdb.rawQuery("SELECT t.title, t.artist, t.source_package, SUM(s.counted_as_play) AS p, SUM(s.listened_ms) AS ms FROM segments s JOIN tracks t ON t.id = s.track_id WHERE s.started_ms >= ? AND s.started_ms < ? GROUP BY t.id HAVING p > 0 ORDER BY p DESC, ms DESC LIMIT ?", arrayOf(range[0], range[1], limit.toString())).use { c ->
            while (c.moveToNext()) tracks += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4))
        }
        val artists = mutableListOf<ArtistStat>()
        rdb.rawQuery("SELECT t.artist, SUM(s.counted_as_play) AS p, SUM(s.listened_ms) AS ms FROM segments s JOIN tracks t ON t.id = s.track_id WHERE s.started_ms >= ? AND s.started_ms < ? GROUP BY t.artist HAVING p > 0 ORDER BY p DESC, ms DESC LIMIT ?", arrayOf(range[0], range[1], limit.toString())).use { c ->
            while (c.moveToNext()) artists += ArtistStat(c.getString(0), c.getInt(1), c.getLong(2))
        }
        return PeriodSummary(listenedMs, plays, unique, busiestDayMs, tracks, artists)
    }

    /** Whole database as JSON text, for backups. */
    @Synchronized
    fun exportJson(): String {
        val rdb = readableDatabase
        val tracks = org.json.JSONArray()
        rdb.rawQuery("SELECT id, title, artist, source_package, plays, listened_ms, last_played_ms FROM tracks ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                tracks.put(org.json.JSONObject()
                    .put("id", c.getLong(0)).put("title", c.getString(1)).put("artist", c.getString(2))
                    .put("source_package", c.getString(3)).put("plays", c.getInt(4))
                    .put("listened_ms", c.getLong(5)).put("last_played_ms", c.getLong(6)))
            }
        }
        val segments = org.json.JSONArray()
        rdb.rawQuery("SELECT track_id, started_ms, listened_ms, counted_as_play FROM segments ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                segments.put(org.json.JSONObject()
                    .put("track_id", c.getLong(0)).put("started_ms", c.getLong(1))
                    .put("listened_ms", c.getLong(2)).put("counted_as_play", c.getInt(3)))
            }
        }
        val aliases = org.json.JSONArray()
        rdb.rawQuery("SELECT orig_title, orig_artist, new_title, new_artist FROM aliases", null).use { c ->
            while (c.moveToNext()) {
                aliases.put(org.json.JSONObject()
                    .put("orig_title", c.getString(0)).put("orig_artist", c.getString(1))
                    .put("new_title", c.getString(2)).put("new_artist", c.getString(3)))
            }
        }
        return org.json.JSONObject()
            .put("app", "RewindYou").put("format", 1).put("exported_ms", System.currentTimeMillis())
            .put("tracks", tracks).put("segments", segments).put("aliases", aliases).toString()
    }

    /**
     * Replaces ALL data with the content of a backup made by [exportJson].
     * Runs in one transaction: if the file is invalid nothing changes. Returns (songs, attempts) imported.
     */
    @Synchronized
    fun importJson(text: String): Pair<Int, Int> {
        val root = org.json.JSONObject(text)
        require(root.optString("app") == "RewindYou" && root.optInt("format", 0) == 1) { "Not a RewindYou backup" }
        val tracks = root.getJSONArray("tracks")
        val segments = root.getJSONArray("segments")
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM segments")
            db.execSQL("DELETE FROM tracks")
            db.execSQL("DELETE FROM aliases")
            for (i in 0 until tracks.length()) {
                val t = tracks.getJSONObject(i)
                val values = ContentValues().apply {
                    put("id", t.getLong("id"))
                    put("title", t.getString("title"))
                    put("artist", t.getString("artist"))
                    put("source_package", t.optString("source_package", ""))
                    put("plays", t.getInt("plays"))
                    put("listened_ms", t.getLong("listened_ms"))
                    put("last_played_ms", t.getLong("last_played_ms"))
                }
                db.insertOrThrow("tracks", null, values)
            }
            for (i in 0 until segments.length()) {
                val g = segments.getJSONObject(i)
                val values = ContentValues().apply {
                    put("track_id", g.getLong("track_id"))
                    put("started_ms", g.getLong("started_ms"))
                    put("listened_ms", g.getLong("listened_ms"))
                    put("counted_as_play", g.getInt("counted_as_play"))
                }
                db.insertOrThrow("segments", null, values)
            }
            val aliases = root.optJSONArray("aliases") // absent in backups made before 0.2.6
            if (aliases != null) {
                for (i in 0 until aliases.length()) {
                    val a = aliases.getJSONObject(i)
                    val values = ContentValues().apply {
                        put("orig_title", a.getString("orig_title"))
                        put("orig_artist", a.getString("orig_artist"))
                        put("new_title", a.getString("new_title"))
                        put("new_artist", a.getString("new_artist"))
                    }
                    db.insertWithOnConflict("aliases", null, values, SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return tracks.length() to segments.length()
    }

    /** All songs, best first, for the full ranking. */
    fun allTracks(): List<LibraryTrack> {
        val out = mutableListOf<LibraryTrack>()
        readableDatabase.rawQuery("SELECT id, title, artist, plays FROM tracks ORDER BY plays DESC, listened_ms DESC, title COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out += LibraryTrack(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3))
        }
        return out
    }

    /** All artists, best first. */
    fun allArtists(): List<LibraryArtist> {
        val out = mutableListOf<LibraryArtist>()
        readableDatabase.rawQuery("SELECT artist, SUM(plays) AS p, COUNT(*) AS n FROM tracks GROUP BY artist ORDER BY p DESC, SUM(listened_ms) DESC, artist COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out += LibraryArtist(c.getString(0), c.getInt(1), c.getInt(2))
        }
        return out
    }

    fun findTrackId(title: String, artist: String): Long? =
        readableDatabase.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=?", arrayOf(title, artist)).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        }

    /**
     * Changes a song's title/artist. If another song already has that title and artist, the two are
     * merged (plays and time are added up). The correction is remembered, so future plays that the
     * player reports with the old text are stored under the corrected one.
     */
    @Synchronized
    fun updateTrack(id: Long, newTitle: String, newArtist: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            applyTrackEdit(db, id, newTitle.trim(), newArtist.trim().ifBlank { UNKNOWN_ARTIST })
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Renames an artist on all of their songs. Returns how many songs were processed. */
    @Synchronized
    fun renameArtist(oldArtist: String, newArtist: String): Int {
        val target = newArtist.trim().ifBlank { UNKNOWN_ARTIST }
        val db = writableDatabase
        var count = 0
        db.beginTransaction()
        try {
            val rows = mutableListOf<Pair<Long, String>>()
            db.rawQuery("SELECT id, title FROM tracks WHERE artist=?", arrayOf(oldArtist)).use { c ->
                while (c.moveToNext()) rows += c.getLong(0) to c.getString(1)
            }
            for ((id, title) in rows) { applyTrackEdit(db, id, title, target); count++ }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return count
    }

    private fun applyTrackEdit(db: SQLiteDatabase, id: Long, newTitle: String, newArtist: String) {
        require(newTitle.isNotEmpty()) { "empty title" }
        var oldTitle = ""
        var oldArtist = ""
        db.rawQuery("SELECT title, artist FROM tracks WHERE id=?", arrayOf(id.toString())).use { c ->
            if (!c.moveToFirst()) return
            oldTitle = c.getString(0)
            oldArtist = c.getString(1)
        }
        if (oldTitle == newTitle && oldArtist == newArtist) return
        val existing = db.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=? AND id<>?", arrayOf(newTitle, newArtist, id.toString())).use { c ->
            if (c.moveToFirst()) c.getLong(0) else -1L
        }
        // Corrections that already pointed to the old text now point to the new one.
        db.execSQL("UPDATE aliases SET new_title=?, new_artist=? WHERE new_title=? AND new_artist=?", arrayOf(newTitle, newArtist, oldTitle, oldArtist))
        // Editing back to a text that used to be corrected removes that correction.
        db.execSQL("DELETE FROM aliases WHERE orig_title=? AND orig_artist=?", arrayOf(newTitle, newArtist))
        db.execSQL("INSERT OR REPLACE INTO aliases(orig_title, orig_artist, new_title, new_artist) VALUES(?,?,?,?)", arrayOf(oldTitle, oldArtist, newTitle, newArtist))
        if (existing > 0) mergeTracks(db, id, existing)
        else db.execSQL("UPDATE tracks SET title=?, artist=? WHERE id=?", arrayOf(newTitle, newArtist, id))
    }

    private fun mergeTracks(db: SQLiteDatabase, fromId: Long, intoId: Long) {
        db.execSQL("UPDATE segments SET track_id=? WHERE track_id=?", arrayOf(intoId, fromId))
        db.execSQL(
            "UPDATE tracks SET plays = plays + (SELECT plays FROM tracks WHERE id=?), listened_ms = listened_ms + (SELECT listened_ms FROM tracks WHERE id=?), last_played_ms = MAX(last_played_ms, (SELECT last_played_ms FROM tracks WHERE id=?)) WHERE id=?",
            arrayOf(fromId, fromId, fromId, intoId)
        )
        db.execSQL("DELETE FROM tracks WHERE id=?", arrayOf(fromId))
    }

    companion object {
        const val MIN_PLAY_MS = 30_000L
        const val UNKNOWN_ARTIST = "Artista desconocido"
    }
}

data class Totals(val uniqueTracks: Int, val plays: Int, val listenedMs: Long)
data class TrackStat(val title: String, val artist: String, val sourcePackage: String, val plays: Int, val listenedMs: Long)
data class ArtistStat(val artist: String, val plays: Int, val listenedMs: Long)
data class PeriodSummary(val listenedMs: Long, val plays: Int, val uniqueTracks: Int, val busiestDayMs: Long?, val topTracks: List<TrackStat>, val topArtists: List<ArtistStat>)
data class LibraryTrack(val id: Long, val title: String, val artist: String, val plays: Int)
data class LibraryArtist(val artist: String, val plays: Int, val songs: Int)
