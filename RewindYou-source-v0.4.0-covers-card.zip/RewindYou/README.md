# RewindYou — Android starter project

**Version:** 0.2.0 (appearance and player-selection update)  
**Language:** Kotlin  
**Minimum Android:** 8.0 (API 26)  
**Storage:** local SQLite database; no account or cloud service

## Included in this source version

- Android app named **RewindYou**.
- Appearance options: follow the phone's light/dark setting, force light mode, or force dark mode.
- Six color palettes: violet/turquoise, red/burgundy, blue, green, orange, and yellow.
- Programmatic status/navigation bar colors and status-bar icon contrast based on the chosen appearance.
- A player selector that lists installed launcher apps and lets the user select packages to monitor. Samsung Music and Musicolet are selected by default.
- A `NotificationListenerService` that asks Android for active media sessions and filters by the selected package names.
- Local storage for track title, artist, listening duration, and counted playback segments.
- A 30-second threshold for counting a play, plus a top-five and total-stats screen.
- Setup links for notification-listener access and app battery settings.

## Planned, not implemented yet

- Album metadata and album-art lookup through online music databases, with recoverable image cache and manual cover selection.
- Weekly/monthly/yearly recap screens and recap history.
- Automatic month-end/year-end recap preparation and notifications.
- Customizable recap-image editor, templates, and manual image export.
- More reliable recovery/checkpointing for an interrupted listening segment.

## Important limitations

This is still an early prototype and the updated source has not been compiled or tested in this environment. The GitHub Actions build should be used to verify compilation before installing the APK. The player picker shows installed apps with launcher icons, not only music apps. Selecting an app does not guarantee compatibility: RewindYou can only track media sessions and metadata that Android and that player expose.

Android media players expose different metadata and playback-state behavior. Exact restart/seek detection may not always be exposed, and OEM battery management can interrupt callbacks. The current implementation estimates segment duration from the elapsed time between playback-state events; an interrupted segment may not be finalized if Android kills the service without a final callback.

## Build through GitHub Actions on a phone

The project ZIP is designed to be placed in the existing repository workflow that extracts `RewindYou-source-updated.zip`, runs Gradle, and uploads the APK as an artifact. Replace the old ZIP in the repository with this updated ZIP, then run the existing Android build workflow. If the workflow is configured to trigger on pushes, committing the replaced ZIP may start the build automatically.

After the workflow succeeds, download the `RewindYou-APK` artifact, extract `app-debug.apk`, and install it on the Samsung phone. Keep Play Protect enabled; do not treat a successful build as a security audit.

## First-run setup

1. Open RewindYou.
2. Tap **Habilitar acceso multimedia** and enable RewindYou in Android's notification-access settings.
3. Return to RewindYou and select the music apps you want to track.
4. If desired, review battery settings to improve background continuity. Android can still defer or interrupt background work.
5. Play music in a selected player, lock the screen, then pause or change tracks to finalize a listening segment. Reopen RewindYou and refresh the stats.

## Package names used for the suggested defaults

- Samsung Music: `com.sec.android.app.music`
- YouTube Music: `com.google.android.apps.youtube.music`
- Musicolet: `in.krosbits.musicolet`
