package com.rewindyou.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }
    private val ui by lazy { Ui(this) }

    private lateinit var root: LinearLayout
    private lateinit var statusCard: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var statusAction: Button
    private lateinit var heroTime: TextView
    private lateinit var heroDetail: TextView
    private lateinit var tileSongs: TextView
    private lateinit var tilePlays: TextView
    private lateinit var tileTime: TextView
    private lateinit var topCard: LinearLayout
    private lateinit var periodHolder: LinearLayout
    private lateinit var summaryTitle: TextView
    private lateinit var summaryBody: TextView
    private lateinit var summaryLimitButton: Button

    private var summaryPeriod = StatPeriod.WEEK
    private var summaryOffset = 0   // 0 = período en curso, -1 = el anterior, etc.
    private var summaryLimit = 5    // longitud del ranking dentro de los resúmenes
    private var summaryText: String? = null
    private var appliedSignature = ""

    data class Palette(val name: String, val primary: Int, val secondary: Int, val lightBg: Int, val darkBg: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.contains(KEY_SELECTED_PACKAGES)) {
            prefs.edit().putStringSet(KEY_SELECTED_PACKAGES, defaultPackages()).apply()
        }
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) {
            // The mode or palette may have changed in Ajustes, or the system dark setting while in the background.
            if (ui.signature() != appliedSignature) buildUi()
            refresh()
        }
    }

    private fun buildUi() {
        appliedSignature = ui.signature()
        ui.applySystemBars(window)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(ui.backgroundColor) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(8), ui.dp(18), ui.dp(28))
        }
        scroll.addView(root)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        // ---- Encabezado ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher_foreground) },
            LinearLayout.LayoutParams(ui.dp(64), ui.dp(64)).apply { marginStart = -ui.dp(8); marginEnd = ui.dp(2) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(ui.label("RewindYou", 26f, ui.textColor, true))
        titles.addView(ui.label("Tu música, tu historial", 13f, ui.mutedColor))
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "⚙"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(ui.textColor)
            contentDescription = "Ajustes"
            background = ui.rounded(ui.surfaceColor, 22, ui.outlineColor, 1)
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        root.addView(header, ui.matchWrap(12))

        // ---- Estado del registro ----
        statusCard = ui.card(12).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusText = ui.label("", 13f, ui.mutedColor)
        statusCard.addView(statusText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        statusAction = ui.button("Habilitar") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        statusCard.addView(statusAction, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = ui.dp(8) })
        root.addView(statusCard, ui.matchWrap(12))

        // ---- Tarjeta principal: esta semana ----
        val hero = ui.hero()
        hero.addView(ui.label("ESTA SEMANA", 12f, Color.argb(215, 255, 255, 255), true).apply { letterSpacing = 0.1f })
        heroTime = ui.label("0 s", 36f, Color.WHITE, true).apply { setPadding(0, ui.dp(4), 0, ui.dp(2)) }
        hero.addView(heroTime)
        heroDetail = ui.label("", 14f, Color.argb(230, 255, 255, 255))
        hero.addView(heroDetail)
        root.addView(hero, ui.matchWrap(12))

        // ---- Cifras totales ----
        tileSongs = ui.label("0", 17f, ui.accentColor, true)
        tilePlays = ui.label("0", 17f, ui.accentColor, true)
        tileTime = ui.label("0s", 17f, ui.accentColor, true)
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            ui.statTile(tileSongs, "Canciones"),
            ui.statTile(tilePlays, "Reprod."),
            ui.statTile(tileTime, "Tiempo")
        ).forEachIndexed { i, tile ->
            tiles.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i < 2) marginEnd = ui.dp(8) })
        }
        root.addView(tiles, ui.matchWrap(4))

        // ---- Top 5 ----
        root.addView(ui.section("TOP 5 CANCIONES"))
        topCard = ui.card(8)
        root.addView(topCard, ui.matchWrap(8))
        root.addView(ui.button("Ver ranking completo y editar", filled = false) {
            startActivity(Intent(this, LibraryActivity::class.java))
        }, ui.matchWrap(4))

        // ---- Resúmenes ----
        root.addView(ui.section("RESÚMENES"))
        periodHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(periodHolder, ui.matchWrap(10))
        val summaryCard = ui.card(16)
        summaryTitle = ui.label("", 15f, ui.accentColor, true).apply { setPadding(0, 0, 0, ui.dp(8)) }
        summaryBody = ui.label("", 14f).apply { setLineSpacing(0f, 1.18f) }
        summaryCard.addView(summaryTitle)
        summaryCard.addView(summaryBody)
        root.addView(summaryCard, ui.matchWrap(8))
        root.addView(ui.buttonRow(
            ui.button("◀ Anterior", filled = false) { stepSummary(-1) },
            ui.button("Siguiente ▶", filled = false) { stepSummary(1) }
        ), ui.matchWrap(8))
        summaryLimitButton = ui.button("Ranking: Top $summaryLimit", filled = false) { cycleSummaryLimit() }
        root.addView(ui.buttonRow(
            ui.button("Compartir texto") { shareSummary() },
            summaryLimitButton
        ), ui.matchWrap(8))
        root.addView(ui.button("Crear tarjeta de imagen para compartir") {
            startActivity(
                Intent(this, ShareCardActivity::class.java)
                    .putExtra(ShareCardActivity.EXTRA_PERIOD, summaryPeriod.ordinal)
                    .putExtra(ShareCardActivity.EXTRA_OFFSET, summaryOffset)
            )
        }, ui.matchWrap(8))
    }

    private fun refresh() {
        updateStatus()
        val totals = db.totals()
        tileSongs.text = totals.uniqueTracks.toString()
        tilePlays.text = totals.plays.toString()
        tileTime.text = ui.formatShort(totals.listenedMs)

        val (weekFrom, weekTo) = periodRange(StatPeriod.WEEK, 0)
        val week = db.summary(weekFrom, weekTo, 1)
        heroTime.text = ui.formatLong(week.listenedMs)
        heroDetail.text = if (week.plays == 0 && week.listenedMs == 0L) {
            "Todavía no hay escucha esta semana."
        } else {
            "${ui.playsLabel(week.plays)} · ${week.uniqueTracks} ${if (week.uniqueTracks == 1) "canción" else "canciones"}"
        }

        populateTop()
        showSummary(summaryPeriod, summaryOffset)
    }

    private fun updateStatus() {
        val enabled = ui.listenerEnabled()
        val players = (prefs.getStringSet(KEY_SELECTED_PACKAGES, defaultPackages()) ?: emptySet()).size
        if (enabled) {
            statusCard.background = ui.rounded(ui.surfaceColor, 18, ui.outlineColor, 1)
            statusText.setTextColor(ui.okColor)
            statusText.text = "● Registro activo · $players ${if (players == 1) "reproductor" else "reproductores"}"
            statusAction.visibility = View.GONE
        } else {
            statusCard.background = ui.rounded(ui.warnBackground, 18, ui.warnColor, 1)
            statusText.setTextColor(ui.warnColor)
            statusText.text = "Falta habilitar el acceso multimedia para registrar tu música."
            statusAction.visibility = View.VISIBLE
        }
    }

    private fun populateTop() {
        topCard.removeAllViews()
        val rows = db.topTracks(5)
        if (rows.isEmpty()) {
            topCard.addView(ui.label("Todavía no hay canciones registradas. Habilitá el acceso y reproducí música en una de las apps seleccionadas.", 14f, ui.mutedColor).apply {
                setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8))
            })
            return
        }
        rows.forEachIndexed { index, track ->
            if (index > 0) topCard.addView(ui.divider())
            val row = ui.rankRow()
            ui.bindRankRow(row, index + 1, track.title, "${track.artist} · ${ui.playsLabel(track.plays)}", db.coverBitmap(track.coverHash), true)
            topCard.addView(row)
        }
    }

    // ---------------- Resúmenes ----------------
    private fun renderPeriodControl() {
        periodHolder.removeAllViews()
        periodHolder.addView(ui.segmented(listOf("Semana", "Mes", "Año"), summaryPeriod.ordinal) { index ->
            showSummary(StatPeriod.values()[index], 0)
        })
    }

    private fun stepSummary(delta: Int) {
        val next = summaryOffset + delta
        if (next > 0) return // no hay resúmenes del futuro
        showSummary(summaryPeriod, next)
    }

    private fun showSummary(period: StatPeriod, offset: Int) {
        summaryPeriod = period
        summaryOffset = offset
        renderPeriodControl()
        val (from, to) = periodRange(period, offset)
        val s = db.summary(from, to, summaryLimit)
        val es = Locale.forLanguageTag("es")
        val title = "${period.title} · ${periodLabel(period, from, to)}" + (if (offset == 0) " (en curso)" else "")
        val body = if (s.plays == 0 && s.listenedMs == 0L) "No hay escucha registrada en este período." else buildString {
            append("Tiempo escuchado: ${ui.formatLong(s.listenedMs)}\n")
            append("Reproducciones: ${s.plays}\n")
            append("Canciones distintas: ${s.uniqueTracks}")
            s.busiestDayMs?.let { append("\nDía más activo: ${SimpleDateFormat("EEEE d 'de' MMMM", es).format(Date(it))}") }
            if (s.topTracks.isNotEmpty()) {
                append("\n\nTop canciones")
                s.topTracks.forEachIndexed { i, t -> append("\n${i + 1}. ${t.title}\n   ${t.artist} · ${ui.playsLabel(t.plays)}") }
            }
            if (s.topArtists.isNotEmpty()) {
                append("\n\nTop artistas")
                s.topArtists.forEachIndexed { i, a -> append("\n${i + 1}. ${a.artist} · ${ui.playsLabel(a.plays)}") }
            }
        }
        summaryText = "$title\n\n$body"
        summaryTitle.text = title
        summaryBody.text = body
    }

    private fun cycleSummaryLimit() {
        summaryLimit = when (summaryLimit) { 5 -> 10; 10 -> 25; else -> 5 }
        summaryLimitButton.text = "Ranking: Top $summaryLimit"
        showSummary(summaryPeriod, summaryOffset)
    }

    private fun shareSummary() {
        val text = summaryText ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartir resumen"))
    }

    companion object {
        val PALETTES = listOf(
            Palette("Violeta + turquesa", Color.rgb(105, 64, 190), Color.rgb(0, 157, 150), Color.rgb(247, 245, 252), Color.rgb(23, 20, 37)),
            Palette("Rojo + bordó", Color.rgb(183, 40, 69), Color.rgb(111, 23, 52), Color.rgb(255, 246, 248), Color.rgb(38, 17, 25)),
            Palette("Azul eléctrico", Color.rgb(40, 105, 220), Color.rgb(91, 190, 239), Color.rgb(243, 248, 255), Color.rgb(14, 24, 42)),
            Palette("Verde", Color.rgb(32, 139, 87), Color.rgb(105, 190, 115), Color.rgb(244, 251, 246), Color.rgb(15, 32, 24)),
            Palette("Naranja", Color.rgb(216, 105, 35), Color.rgb(246, 169, 66), Color.rgb(255, 249, 241), Color.rgb(39, 25, 15)),
            Palette("Amarillo", Color.rgb(173, 130, 0), Color.rgb(235, 190, 35), Color.rgb(255, 252, 235), Color.rgb(35, 31, 14))
        )
        fun defaultPackages(): Set<String> = setOf(PKG_SAMSUNG_MUSIC, PKG_MUSICOLET)

        const val PREFS = "rewindyou_preferences"
        const val KEY_SAMSUNG_MUSIC = "samsung_music"
        const val KEY_YOUTUBE_MUSIC = "youtube_music"
        const val KEY_MUSICOLET = "musicolet"
        const val KEY_SELECTED_PACKAGES = "selected_music_packages"
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_PALETTE = "color_palette"
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        const val PKG_SAMSUNG_MUSIC = "com.sec.android.app.music"
        const val PKG_YOUTUBE_MUSIC = "com.google.android.apps.youtube.music"
        const val PKG_MUSICOLET = "in.krosbits.musicolet"
    }
}
