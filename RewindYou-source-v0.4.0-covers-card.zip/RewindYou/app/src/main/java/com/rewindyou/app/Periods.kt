package com.rewindyou.app

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Periods used by the summaries and the shareable card. Weeks start on Monday. */
enum class StatPeriod(val title: String, val cardTitle: String) {
    WEEK("Resumen semanal", "Mi semana en música"),
    MONTH("Resumen mensual", "Mi mes en música"),
    YEAR("Resumen anual", "Mi año en música")
}

/** Start (inclusive) and end (exclusive) of the period, in milliseconds. [offset] 0 = current, -1 = previous... */
fun periodRange(period: StatPeriod, offset: Int): Pair<Long, Long> {
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
    when (period) {
        StatPeriod.WEEK -> {
            cal.add(Calendar.DAY_OF_YEAR, -((cal.get(Calendar.DAY_OF_WEEK) + 5) % 7)) // vuelve al lunes
            cal.add(Calendar.DAY_OF_YEAR, 7 * offset)
        }
        StatPeriod.MONTH -> { cal.set(Calendar.DAY_OF_MONTH, 1); cal.add(Calendar.MONTH, offset) }
        StatPeriod.YEAR -> { cal.set(Calendar.MONTH, Calendar.JANUARY); cal.set(Calendar.DAY_OF_MONTH, 1); cal.add(Calendar.YEAR, offset) }
    }
    val start = cal.timeInMillis
    when (period) {
        StatPeriod.WEEK -> cal.add(Calendar.DAY_OF_YEAR, 7)
        StatPeriod.MONTH -> cal.add(Calendar.MONTH, 1)
        StatPeriod.YEAR -> cal.add(Calendar.YEAR, 1)
    }
    return start to cal.timeInMillis
}

fun periodLabel(period: StatPeriod, startMs: Long, endMs: Long): String {
    val es = Locale.forLanguageTag("es")
    return when (period) {
        StatPeriod.WEEK -> "${SimpleDateFormat("d MMM", es).format(Date(startMs))} – ${SimpleDateFormat("d MMM yyyy", es).format(Date(endMs - 1))}"
        StatPeriod.MONTH -> SimpleDateFormat("MMMM yyyy", es).format(Date(startMs)).replaceFirstChar { it.uppercase() }
        StatPeriod.YEAR -> SimpleDateFormat("yyyy", es).format(Date(startMs))
    }
}
