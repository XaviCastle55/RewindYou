package com.rewindyou.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Appearance, players, permissions and backup. More options can be added here later. */
class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }
    private val ui by lazy { Ui(this) }

    private lateinit var playersSummary: TextView
    private lateinit var listenerStatus: TextView

    private data class InstalledApp(val packageName: String, val label: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::playersSummary.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        ui.applySystemBars(window)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(ui.backgroundColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(28))
        }
        scroll.addView(root)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        // ---- Encabezado ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ui.button("◀", filled = false) { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(ui.label("Ajustes", 24f, ui.textColor, true).apply { setPadding(ui.dp(14), 0, 0, 0) })
        root.addView(header, ui.matchWrap(4))

        // ---- Apariencia ----
        root.addView(ui.section("APARIENCIA"))
        val appearance = ui.card(14)
        appearance.addView(ui.label("Modo", 14f, ui.mutedColor, true).apply { setPadding(0, 0, 0, ui.dp(8)) })
        val modes = listOf(MainActivity.THEME_SYSTEM, MainActivity.THEME_LIGHT, MainActivity.THEME_DARK)
        val currentMode = prefs.getString(MainActivity.KEY_THEME_MODE, MainActivity.THEME_SYSTEM)
        appearance.addView(ui.segmented(listOf("Teléfono", "Claro", "Oscuro"), modes.indexOf(currentMode).coerceAtLeast(0)) { index ->
            prefs.edit().putString(MainActivity.KEY_THEME_MODE, modes[index]).apply()
            buildUi()
        }, ui.matchWrap(14))

        appearance.addView(ui.label("Paleta de colores", 14f, ui.mutedColor, true).apply { setPadding(0, 0, 0, ui.dp(8)) })
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val currentName = ui.palette.name
        MainActivity.PALETTES.forEachIndexed { i, p ->
            val selected = p.name == currentName
            swatches.addView(TextView(this).apply {
                text = if (selected) "✓" else ""
                gravity = Gravity.CENTER
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                contentDescription = p.name
                background = ui.gradient(p.primary, p.secondary, 14).also { if (selected) it.setStroke(ui.dp(3), ui.textColor) }
                setOnClickListener {
                    prefs.edit().putString(MainActivity.KEY_PALETTE, p.name).apply()
                    buildUi()
                }
            }, LinearLayout.LayoutParams(0, ui.dp(48), 1f).apply { if (i < MainActivity.PALETTES.size - 1) marginEnd = ui.dp(8) })
        }
        appearance.addView(swatches, ui.matchWrap(6))
        appearance.addView(ui.label(currentName, 13f, ui.mutedColor))
        root.addView(appearance, ui.matchWrap(8))

        // ---- Reproductores ----
        root.addView(ui.section("REPRODUCTORES"))
        val players = ui.card(14)
        playersSummary = ui.label("", 14f)
        players.addView(playersSummary, ui.matchWrap(10))
        players.addView(ui.button("Elegir reproductores instalados") { choosePlayers() }, ui.matchWrap(8))
        players.addView(ui.hint("Samsung Music y Musicolet vienen seleccionados. Algunas apps podrían no exponer sus datos multimedia, aunque estén seleccionadas."))
        root.addView(players, ui.matchWrap(8))

        // ---- Permisos ----
        root.addView(ui.section("PERMISOS Y FUNCIONAMIENTO"))
        val permissions = ui.card(14)
        listenerStatus = ui.label("", 14f)
        permissions.addView(listenerStatus, ui.matchWrap(10))
        permissions.addView(ui.button("1 · Habilitar acceso multimedia") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, ui.matchWrap(4))
        permissions.addView(ui.hint("En esa pantalla, activá RewindYou. Es un permiso especial de Android necesario para detectar las sesiones de reproducción."))
        permissions.addView(ui.button("2 · Abrir ajustes de batería") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:$packageName")))
        }, ui.matchWrap(4))
        permissions.addView(ui.hint("Para mejorar la continuidad en Samsung, podés revisar los ajustes de batería. Android todavía puede suspender el registro en algunas situaciones."))
        root.addView(permissions, ui.matchWrap(8))

        // ---- Copia de seguridad ----
        root.addView(ui.section("COPIA DE SEGURIDAD"))
        val backup = ui.card(14)
        backup.addView(ui.hint("Guardá tus estadísticas en un archivo para no perderlas si cambiás de teléfono o hay que reinstalar la app. Conviene copiar el archivo fuera del teléfono (por ejemplo, a Drive)."))
        backup.addView(ui.buttonRow(
            ui.button("Exportar") { startExport() },
            ui.button("Importar", filled = false) { startImport() }
        ))
        root.addView(backup, ui.matchWrap(8))

        // ---- Acerca de ----
        root.addView(ui.section("ACERCA DE"))
        root.addView(ui.hint("RewindYou ${appVersion()}"))

        refreshStatus()
    }

    private fun refreshStatus() {
        listenerStatus.text = if (ui.listenerEnabled()) "Acceso multimedia: habilitado" else "Acceso multimedia: falta habilitarlo"
        listenerStatus.setTextColor(if (ui.listenerEnabled()) ui.okColor else ui.warnColor)
        val selected = prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()) ?: emptySet()
        val names = installedApps().filter { it.packageName in selected }.map { it.label }.sortedBy { it.lowercase() }
        playersSummary.text = if (names.isEmpty()) "No hay reproductores seleccionados." else "Seleccionados (${names.size}): " + names.joinToString(", ")
    }

    private fun appVersion(): String {
        @Suppress("DEPRECATION")
        val name = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { null }
        return name ?: ""
    }

    // ---------------- Reproductores ----------------
    private fun installedApps(): List<InstalledApp> =
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName) null else InstalledApp(pkg, info.loadLabel(packageManager).toString())
            }
            .distinctBy { it.packageName }

    private fun choosePlayers() {
        val apps = installedApps().sortedBy { it.label.lowercase() }
        val selected = (prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()) ?: MainActivity.defaultPackages()).toMutableSet()
        val labels = apps.map { "${it.label}\n${it.packageName}" }.toTypedArray()
        val checked = apps.map { it.packageName in selected }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Elegir reproductores")
            // Se omite setMessage para que la lista de aplicaciones se muestre correctamente.
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) selected.add(apps[which].packageName) else selected.remove(apps[which].packageName)
            }
            .setNeutralButton("Restablecer sugeridos") { _, _ ->
                prefs.edit().putStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()).apply()
                refreshStatus()
            }
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putStringSet(MainActivity.KEY_SELECTED_PACKAGES, selected.toSet()).apply()
                refreshStatus()
            }
            .show()
    }

    // ---------------- Copia de seguridad ----------------
    @Suppress("DEPRECATION")
    private fun startExport() {
        val name = "RewindYou-copia-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json"
        startActivityForResult(
            Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, name),
            REQ_EXPORT
        )
    }

    @Suppress("DEPRECATION")
    private fun startImport() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_EXPORT -> exportTo(uri)
            REQ_IMPORT -> confirmImport(uri)
        }
    }

    private fun exportTo(uri: Uri) {
        try {
            val json = db.exportJson()
            val stream = contentResolver.openOutputStream(uri, "wt") ?: error("No se pudo abrir el archivo")
            stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            toast("Copia guardada (${json.length / 1024 + 1} KB).")
        } catch (e: Exception) {
            toast("No se pudo guardar la copia: ${e.message}")
        }
    }

    private fun confirmImport(uri: Uri) {
        val text = try {
            contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
        } catch (e: Exception) { null }
        if (text.isNullOrBlank()) { toast("No se pudo leer el archivo."); return }
        val current = db.totals()
        AlertDialog.Builder(this)
            .setTitle("Importar copia de seguridad")
            .setMessage("Esto reemplaza las estadísticas actuales de este teléfono (${current.plays} reproducciones) por las de la copia. Pausá la música antes de continuar.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Reemplazar") { _, _ ->
                try {
                    val (songs, _) = db.importJson(text)
                    toast("Copia importada: $songs canciones.")
                } catch (e: Exception) {
                    toast("El archivo no es una copia válida de RewindYou. No se cambió nada.")
                }
            }
            .show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private companion object {
        const val REQ_EXPORT = 4101
        const val REQ_IMPORT = 4102
    }
}
