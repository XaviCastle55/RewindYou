package com.rewindyou.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils

/** Draws the shareable summary image. Pure drawing: everything it shows comes in through [Data]. */
object CardRenderer {
    enum class Style { COLOR, DARK, LIGHT }

    class Row(val title: String, val subtitle: String, val cover: Bitmap?)

    class Data(
        val width: Int,
        val height: Int,
        val style: Style,
        val palette: MainActivity.Palette,
        val title: String,
        val periodLabel: String,
        val heroTime: String,
        val heroDetail: String,
        val heading: String,
        val rows: List<Row>,
        val showCovers: Boolean,
        val featuredCover: Bitmap?,   // large image for the #1 song
        val logo: Bitmap?
    )

    fun render(d: Data): Bitmap {
        val bitmap = Bitmap.createBitmap(d.width, d.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        val w = d.width.toFloat()
        val h = d.height.toFloat()
        val p = d.palette
        val story = d.height > d.width

        val textColor: Int
        val mutedColor: Int
        val accentColor: Int
        val badgeColor: Int
        val placeholderColor: Int
        val decoColor: Int
        when (d.style) {
            Style.COLOR -> {
                val gradient = LinearGradient(0f, 0f, w, h, p.primary, shade(p.primary, 0.42f), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, Paint().apply { shader = gradient })
                textColor = Color.WHITE
                mutedColor = Color.argb(205, 255, 255, 255)
                accentColor = Color.WHITE
                badgeColor = Color.argb(80, 255, 255, 255)
                placeholderColor = Color.argb(50, 255, 255, 255)
                decoColor = Color.argb(34, 255, 255, 255)
            }
            Style.DARK -> {
                c.drawColor(p.darkBg)
                textColor = Color.rgb(246, 243, 252)
                mutedColor = Color.argb(190, 246, 243, 252)
                accentColor = blend(p.primary, Color.WHITE, 0.45f)
                badgeColor = p.primary
                placeholderColor = Color.argb(40, 255, 255, 255)
                decoColor = withAlpha(p.primary, 80)
            }
            Style.LIGHT -> {
                c.drawColor(p.lightBg)
                textColor = Color.rgb(34, 31, 46)
                mutedColor = Color.argb(185, 34, 31, 46)
                accentColor = p.primary
                badgeColor = p.primary
                placeholderColor = Color.argb(40, 0, 0, 0)
                decoColor = withAlpha(p.primary, 45)
            }
        }

        // Decorative circles
        val deco = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = decoColor }
        c.drawCircle(w * 0.93f, h * 0.05f, w * 0.38f, deco)
        c.drawCircle(w * 0.02f, h * 0.99f, w * 0.30f, deco)

        val margin = 72f
        val contentW = w - 2 * margin

        // Header: logo + name
        d.logo?.let { c.drawBitmap(it, null, RectF(margin - 26f, margin - 26f, margin + 106f, margin + 106f), Paint(Paint.FILTER_BITMAP_FLAG)) }
        c.drawText("RewindYou", margin + 92f, margin + 52f, textPaint(46f, textColor, true))

        // Custom title and period
        val yTitle = if (story) 330f else 290f
        val titlePaint = textPaint(if (story) 78f else 68f, textColor, true)
        while (titlePaint.measureText(d.title) > contentW && titlePaint.textSize > 34f) titlePaint.textSize -= 2f
        c.drawText(fit(d.title, titlePaint, contentW), margin, yTitle, titlePaint)
        c.drawText(fit(d.periodLabel, textPaint(36f, mutedColor), contentW), margin, yTitle + 62f, textPaint(36f, mutedColor))

        // Big number
        val yHero = if (story) 610f else 470f
        val heroPaint = textPaint(if (story) 130f else 100f, textColor, true)
        while (heroPaint.measureText(d.heroTime) > contentW && heroPaint.textSize > 40f) heroPaint.textSize -= 4f
        c.drawText(d.heroTime, margin, yHero, heroPaint)
        val detailPaint = textPaint(38f, mutedColor)
        c.drawText(fit(d.heroDetail, detailPaint, contentW), margin, yHero + (if (story) 72f else 58f), detailPaint)

        // Ranking
        val yHeading = if (story) 800f else 600f
        c.drawText(d.heading, margin, yHeading, textPaint(30f, accentColor, true, 0.12f))
        val rowH = if (story) 120f else 82f
        val yRows = yHeading + 34f
        val featured = d.showCovers && d.rows.isNotEmpty()
        val featuredSize = if (story) 340f else 190f
        val skip = if (featured) 1 else 0
        val maxListRows = if (featured) (if (story) 5 else 2) else (if (story) 8 else 4)
        var yCursor = yRows
        if (d.rows.isEmpty()) {
            c.drawText("Todavía no hay escucha en este período.", margin, yRows + 60f, textPaint(34f, mutedColor))
        }
        if (featured) {
            val first = d.rows[0]
            drawCover(c, d.featuredCover ?: first.cover, margin, yCursor, featuredSize, placeholderColor)
            val xT = margin + featuredSize + 32f
            val maxW = w - margin - xT
            c.drawText("N.º 1", xT, yCursor + featuredSize * 0.22f, textPaint(featuredSize * 0.12f, accentColor, true, 0.1f))
            val bigTitle = textPaint(featuredSize * 0.14f, textColor, true)
            c.drawText(fit(first.title, bigTitle, maxW), xT, yCursor + featuredSize * 0.48f, bigTitle)
            val bigSub = textPaint(featuredSize * 0.10f, mutedColor)
            c.drawText(fit(first.subtitle, bigSub, maxW), xT, yCursor + featuredSize * 0.65f, bigSub)
            yCursor += featuredSize + 28f
        }
        d.rows.drop(skip).take(maxListRows).forEachIndexed { index, row ->
            val top = yCursor + index * rowH
            val centerY = top + rowH / 2f
            val radius = rowH * 0.24f
            val cx = margin + radius
            c.drawCircle(cx, centerY, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = badgeColor })
            val numberPaint = textPaint(radius * 1.05f, Color.WHITE, true)
            val number = (index + 1 + skip).toString()
            c.drawText(number, cx - numberPaint.measureText(number) / 2f, centerY + numberPaint.textSize * 0.35f, numberPaint)

            var xText = cx + radius + 24f
            if (d.showCovers) {
                val size = rowH - 18f
                drawCover(c, row.cover, xText, centerY - size / 2f, size, placeholderColor)
                xText += size + 22f
            }
            val maxW = w - margin - xText
            val titleRowPaint = textPaint(rowH * 0.31f, textColor, true)
            val subPaint = textPaint(rowH * 0.24f, mutedColor)
            c.drawText(fit(row.title, titleRowPaint, maxW), xText, centerY - rowH * 0.03f, titleRowPaint)
            c.drawText(fit(row.subtitle, subPaint, maxW), xText, centerY + rowH * 0.27f, subPaint)
        }

        // Footer
        c.drawText("Generado con RewindYou", margin, h - 54f, textPaint(28f, mutedColor))
        return bitmap
    }

    private fun drawCover(c: Canvas, cover: Bitmap?, left: Float, top: Float, size: Float, placeholder: Int) {
        val rect = RectF(left, top, left + size, top + size)
        val radius = size * 0.18f
        if (cover == null) {
            c.drawRoundRect(rect, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = placeholder })
            return
        }
        val path = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        c.save()
        c.clipPath(path)
        c.drawBitmap(cover, null, rect, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restore()
    }

    private fun textPaint(size: Float, color: Int, bold: Boolean = false, spacing: Float = 0f): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            letterSpacing = spacing
        }

    private fun fit(text: String, paint: TextPaint, maxWidth: Float): String =
        TextUtils.ellipsize(text, paint, maxWidth, TextUtils.TruncateAt.END).toString()

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    private fun shade(color: Int, factor: Float): Int =
        Color.rgb((Color.red(color) * factor).toInt(), (Color.green(color) * factor).toInt(), (Color.blue(color) * factor).toInt())

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}
