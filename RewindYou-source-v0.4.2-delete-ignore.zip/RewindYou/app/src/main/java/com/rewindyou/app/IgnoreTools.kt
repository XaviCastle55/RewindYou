package com.rewindyou.app

import android.app.Activity
import android.app.AlertDialog
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

/** Dialogs to ignore songs and manage the ignore rules. [onChanged] runs after anything is modified. */
class IgnoreTools(private val activity: Activity, private val db: ListeningDatabase, private val onChanged: () -> Unit) {
    private fun dp(value: Int) = (value * activity.resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(activity, message, Toast.LENGTH_LONG).show()

    /** Asks for a text; songs whose title or artist contains it will be deleted and no longer recorded. */
    fun askText(initial: String) {
        val input = EditText(activity).apply {
            setText(initial)
            hint = "Texto a ignorar"
            setSingleLine()
            setSelection(text.length)
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(activity)
            .setTitle("Ignorar por texto")
            .setMessage("Se eliminarán y dejarán de registrarse las canciones cuyo título o artista contenga este texto (sin distinguir mayúsculas). Podés acortarlo; por ejemplo «PTT-» o «-WA0».")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar") { _, _ -> confirmRule(IgnoreRule(input.text.toString().trim(), "")) }
            .show()
    }

    /** Shows what the rule would delete and, if confirmed, saves it and deletes the matches. */
    fun confirmRule(rule: IgnoreRule) {
        if (rule.artist.isEmpty() && rule.text.length < 3) {
            toast("Escribí al menos 3 caracteres.")
            return
        }
        val matches = db.tracksMatching(rule)
        val preview = matches.take(8).joinToString("\n") { "• ${it.title} — ${it.artist}" } +
            (if (matches.size > 8) "\n… y ${matches.size - 8} más" else "")
        val intro = if (matches.isEmpty()) {
            "No hay canciones registradas que coincidan. Solo se ignorarán las que suenen de ahora en adelante."
        } else {
            "Se eliminarán ${matches.size} ${if (matches.size == 1) "canción" else "canciones"} del ranking:\n$preview"
        }
        AlertDialog.Builder(activity)
            .setTitle("Ignorar «${rule.text}»")
            .setMessage("$intro\n\nNo se volverán a registrar. Esto no se puede deshacer.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton(if (matches.isEmpty()) "Ignorar" else "Eliminar e ignorar") { _, _ ->
                db.addIgnored(rule)
                val removed = db.deleteTracks(matches.map { it.id })
                toast(if (removed > 0) "Se eliminaron $removed y se ignorarán." else "Regla agregada.")
                onChanged()
            }
            .show()
    }

    /** List of rules: add one, add the WhatsApp preset, or tap a rule to stop ignoring it. */
    fun manageList() {
        val rules = db.allIgnored()
        val labels = mutableListOf("＋ Añadir un texto…", "＋ Audios de WhatsApp (-WA0)")
        rules.forEach { labels += it.label() }
        AlertDialog.Builder(activity)
            .setTitle("Ignorados (${rules.size})")
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> askText("")
                    1 -> confirmRule(IgnoreRule("-WA0", ""))
                    else -> askRemove(rules[which - 2])
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun askRemove(rule: IgnoreRule) {
        AlertDialog.Builder(activity)
            .setTitle("Dejar de ignorar")
            .setMessage("${rule.label()}\n\nLas canciones ya eliminadas no se recuperan; volverán a registrarse si suenan.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Dejar de ignorar") { _, _ ->
                db.removeIgnored(rule)
                toast("Regla eliminada.")
                onChanged()
            }
            .show()
    }
}
