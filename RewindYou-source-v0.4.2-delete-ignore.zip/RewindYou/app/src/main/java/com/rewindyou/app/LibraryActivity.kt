package com.rewindyou.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * Full ranking of songs and artists with search.
 * Tap a song for its menu (edit, cover, delete); long-press to select several and delete them.
 * Tap an artist to rename it on all of their songs.
 */
class LibraryActivity : Activity() {
    private val db by lazy { ListeningDatabase(this) }
    private val ui by lazy { Ui(this) }
    private val ignoreTools by lazy { IgnoreTools(this, db) { reload() } }

    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var summary: TextView
    private lateinit var adapter: RowAdapter
    private lateinit var modeHolder: LinearLayout
    private lateinit var selectionBar: LinearLayout
    private lateinit var selectionText: TextView

    private var showArtists = false
    private var allTracks: List<LibraryTrack> = emptyList()
    private var allArtists: List<LibraryArtist> = emptyList()
    private val shown = mutableListOf<Any>()   // same order as the rows on screen
    private var pendingCoverTrack: LibraryTrack? = null
    private var selecting = false
    private val selectedIds = mutableSetOf<Long>()

    private data class RowItem(
        val rank: Int,
        val title: String,
        val subtitle: String,
        val coverHash: String? = null,
        val showCover: Boolean = false,
        val id: Long = -1L
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui.applySystemBars(window)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(8))
        }
        page.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ui.button("◀", filled = false) { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(ui.label("Ranking completo", 22f, ui.textColor, true).apply { setPadding(ui.dp(14), 0, 0, 0) })
        content.addView(header, ui.matchWrap(10))

        // Shown while several songs are selected
        selectionBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        selectionText = ui.label("", 14f, ui.accentColor, true).apply { setPadding(ui.dp(4), 0, 0, ui.dp(6)) }
        selectionBar.addView(selectionText)
        selectionBar.addView(ui.buttonRow(
            ui.button("Todas", filled = false) { selectAllShown() },
            ui.button("Eliminar") { deleteSelected() },
            ui.button("Cancelar", filled = false) { exitSelection() }
        ), ui.matchWrap(10))
        content.addView(selectionBar)

        modeHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(modeHolder, ui.matchWrap(10))

        search = EditText(this).apply {
            hint = "Buscar por título o artista"
            setSingleLine()
            textSize = 15f
            setTextColor(ui.textColor)
            setHintTextColor(ui.mutedColor)
            background = ui.rounded(ui.surfaceColor, 14, ui.outlineColor, 1)
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) { render() }
            })
        }
        content.addView(search, ui.matchWrap(6))

        summary = ui.label("", 13f, ui.mutedColor).apply { setPadding(ui.dp(4), ui.dp(2), 0, ui.dp(8)) }
        content.addView(summary)

        adapter = RowAdapter(mutableListOf())
        list = ListView(this).apply {
            divider = ColorDrawable(ui.backgroundColor)
            dividerHeight = ui.dp(8)
            setBackgroundColor(ui.backgroundColor)
            setOnItemClickListener { _, _, position, _ -> onRowClick(position) }
            setOnItemLongClickListener { _, _, position, _ -> onRowLongClick(position); true }
        }
        list.adapter = adapter
        content.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (selecting) exitSelection() else super.onBackPressed()
    }

    private fun reload() {
        allTracks = db.allTracks()
        allArtists = db.allArtists()
        selectedIds.retainAll(allTracks.map { it.id }.toSet())
        if (selecting && selectedIds.isEmpty()) selecting = false
        updateSelectionUi()
        renderModeControl()
        render()
    }

    private fun setMode(artists: Boolean) {
        if (selecting) exitSelection()
        showArtists = artists
        renderModeControl()
        render()
    }

    private fun renderModeControl() {
        modeHolder.removeAllViews()
        modeHolder.addView(ui.segmented(listOf("Canciones", "Artistas"), if (showArtists) 1 else 0) { index -> setMode(index == 1) })
    }

    private fun render() {
        val query = search.text.toString().trim().lowercase()
        shown.clear()
        val rows = mutableListOf<RowItem>()
        if (!showArtists) {
            allTracks.forEachIndexed { index, t ->
                if (query.isEmpty() || t.title.lowercase().contains(query) || t.artist.lowercase().contains(query)) {
                    shown += t
                    rows += RowItem(index + 1, t.title, "${t.artist} · ${ui.playsLabel(t.plays)}", t.coverHash, true, t.id)
                }
            }
            summary.text = if (allTracks.isEmpty()) "Todavía no hay canciones registradas."
            else "${shown.size} de ${allTracks.size} canciones · tocá una para ver opciones · mantené presionada para seleccionar varias"
        } else {
            allArtists.forEachIndexed { index, a ->
                if (query.isEmpty() || a.artist.lowercase().contains(query)) {
                    shown += a
                    rows += RowItem(index + 1, a.artist, "${ui.playsLabel(a.plays)} · ${a.songs} ${if (a.songs == 1) "canción" else "canciones"}")
                }
            }
            summary.text = if (allArtists.isEmpty()) "Todavía no hay artistas registrados."
            else "${shown.size} de ${allArtists.size} artistas · tocá uno para renombrarlo"
        }
        adapter.clear()
        adapter.addAll(rows)
    }

    // ---------------- Toques y selección ----------------
    private fun onRowClick(position: Int) {
        when (val item = shown.getOrNull(position)) {
            is LibraryTrack -> if (selecting) toggleSelection(item.id) else showTrackMenu(item)
            is LibraryArtist -> if (!selecting) editArtist(item)
            else -> Unit
        }
    }

    private fun onRowLongClick(position: Int) {
        val track = shown.getOrNull(position) as? LibraryTrack ?: return
        selecting = true
        selectedIds += track.id
        updateSelectionUi()
    }

    private fun toggleSelection(id: Long) {
        if (!selectedIds.add(id)) selectedIds.remove(id)
        if (selectedIds.isEmpty()) exitSelection() else updateSelectionUi()
    }

    private fun selectAllShown() {
        shown.filterIsInstance<LibraryTrack>().forEach { selectedIds += it.id }
        updateSelectionUi()
    }

    private fun exitSelection() {
        selecting = false
        selectedIds.clear()
        updateSelectionUi()
    }

    private fun updateSelectionUi() {
        selectionBar.visibility = if (selecting) View.VISIBLE else View.GONE
        selectionText.text = "${selectedIds.size} ${if (selectedIds.size == 1) "seleccionada" else "seleccionadas"}"
        adapter.notifyDataSetChanged()
    }

    private fun deleteSelected() {
        val ids = selectedIds.toList()
        if (ids.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Eliminar canciones")
            .setMessage("¿Eliminar ${ids.size} ${if (ids.size == 1) "canción" else "canciones"} del ranking? Se borran sus reproducciones y su tiempo, y no se puede deshacer. Si vuelven a sonar, se registrarán de nuevo.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Eliminar") { _, _ ->
                val removed = db.deleteTracks(ids)
                exitSelection()
                toast("Se eliminaron $removed.")
                reload()
            }
            .show()
    }

    // ---------------- Menú de una canción ----------------
    private fun showTrackMenu(track: LibraryTrack) {
        val items = arrayOf("Editar título y artista", "Cambiar carátula", "Eliminar…")
        AlertDialog.Builder(this)
            .setTitle(track.title)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> editTrack(track)
                    1 -> { pendingCoverTrack = track; pickCover() }
                    else -> deleteMenu(track)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteMenu(track: LibraryTrack) {
        val items = arrayOf("Eliminar solo esta entrada", "Eliminar e ignorar esta canción", "Eliminar e ignorar por texto…")
        AlertDialog.Builder(this)
            .setTitle("Eliminar «${track.title}»")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> confirmDeleteOne(track)
                    1 -> ignoreTools.confirmRule(IgnoreRule(track.title, track.artist))
                    else -> ignoreTools.askText(track.title)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteOne(track: LibraryTrack) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar canción")
            .setMessage("¿Eliminar «${track.title}» de ${track.artist}? Se borran sus reproducciones y su tiempo, y no se puede deshacer. Si vuelve a sonar, se registrará de nuevo.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Eliminar") { _, _ ->
                db.deleteTracks(listOf(track.id))
                toast("Canción eliminada.")
                reload()
            }
            .show()
    }

    // ---------------- Editar ----------------
    private fun editTrack(track: LibraryTrack) {
        val titleInput = EditText(this).apply { setText(track.title); hint = "Título"; setSingleLine() }
        val artistInput = EditText(this).apply { setText(track.artist); hint = "Artista"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(titleInput)
            addView(artistInput)
        }
        AlertDialog.Builder(this)
            .setTitle("Editar canción")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ -> saveTrack(track, titleInput.text.toString(), artistInput.text.toString()) }
            .show()
    }

    @Suppress("DEPRECATION")
    private fun pickCover() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_COVER)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_COVER || resultCode != RESULT_OK || uri == null) return
        val track = pendingCoverTrack ?: return
        try {
            val bitmap = decodeImage(uri, 1024)
            if (bitmap == null) {
                toast("No se pudo leer la imagen.")
            } else {
                db.saveCoverForTrack(track.id, bitmap, ListeningDatabase.SOURCE_MANUAL)
                toast("Carátula guardada.")
                reload()
            }
        } catch (e: Exception) {
            toast("No se pudo guardar la carátula: ${e.message}")
        }
    }

    /** Reads an image from [uri] reduced so its larger side is about [maxSide] px. */
    private fun decodeImage(uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
    }

    private fun saveTrack(track: LibraryTrack, rawTitle: String, rawArtist: String) {
        val title = rawTitle.trim()
        val artist = rawArtist.trim().ifBlank { ListeningDatabase.UNKNOWN_ARTIST }
        if (title.isEmpty()) { toast("El título no puede estar vacío."); return }
        if (title == track.title && artist == track.artist) return
        val existing = db.findTrackId(title, artist)
        if (existing != null && existing != track.id) {
            AlertDialog.Builder(this)
                .setTitle("Unir canciones")
                .setMessage("Ya existe «$title» de $artist. ¿Querés unirlas? Sus reproducciones y su tiempo se suman, y no se puede deshacer.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Unir") { _, _ -> applyEdit(track.id, title, artist) }
                .show()
        } else {
            applyEdit(track.id, title, artist)
        }
    }

    private fun applyEdit(id: Long, title: String, artist: String) {
        try {
            db.updateTrack(id, title, artist)
            toast("Cambios guardados.")
            reload()
        } catch (e: Exception) {
            toast("No se pudo guardar: ${e.message}")
        }
    }

    private fun editArtist(artist: LibraryArtist) {
        val input = EditText(this).apply { setText(artist.artist); hint = "Artista"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Renombrar artista")
            .setMessage("Se cambia en las ${artist.songs} canciones de este artista. Si alguna queda igual a otra que ya existe, se unen.")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim().ifBlank { ListeningDatabase.UNKNOWN_ARTIST }
                if (newName == artist.artist) return@setPositiveButton
                try {
                    val count = db.renameArtist(artist.artist, newName)
                    toast("Listo: $count canciones actualizadas.")
                    reload()
                } catch (e: Exception) {
                    toast("No se pudo guardar: ${e.message}")
                }
            }
            .show()
    }

    private inner class RowAdapter(items: MutableList<RowItem>) : ArrayAdapter<RowItem>(this@LibraryActivity, 0, items) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: ui.rankRow().apply {
                setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10))
            }
            val item = getItem(position)
            if (item != null) {
                ui.bindRankRow(row, item.rank, item.title, item.subtitle, if (item.showCover) db.coverBitmap(item.coverHash) else null, item.showCover)
                val selected = selecting && item.id in selectedIds
                row.background = if (selected) {
                    ui.rounded(ui.blend(ui.surfaceColor, ui.palette.primary, 0.28f), 16, ui.palette.primary, 2)
                } else {
                    ui.rounded(ui.surfaceColor, 16, ui.outlineColor, 1)
                }
            }
            return row
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private companion object {
        const val REQ_COVER = 4301
    }
}
