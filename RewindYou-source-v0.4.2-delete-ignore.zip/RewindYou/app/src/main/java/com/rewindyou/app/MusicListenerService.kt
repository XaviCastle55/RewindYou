package com.rewindyou.app

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.concurrent.ConcurrentHashMap

/**
 * Receives media-session metadata/state through Android's notification-listener authorization.
 * It does not read notification text or media audio; it only tracks the opted-in players.
 */
class MusicListenerService : NotificationListenerService() {
    private val controllers = ConcurrentHashMap<String, MediaController>()
    private val callbacks = ConcurrentHashMap<String, MediaController.Callback>()
    private val recorder by lazy { SessionRecorder(ListeningDatabase(this)) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // Notification contents are intentionally not read. Used only to notice new media sessions.
        refreshSessions()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refreshSessions() }

    private fun refreshSessions() {
        try {
            val allowed = selectedPackages()
            val active = getSystemService(android.media.session.MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MusicListenerService::class.java))
                .filter { it.packageName in allowed }
            val activeKeys = active.map { key(it) }.toSet()
            controllers.keys.toList().filter { it !in activeKeys }.forEach { removeController(it) }
            active.forEach { controller ->
                val k = key(controller)
                if (controllers.putIfAbsent(k, controller) == null) {
                    val callback = object : MediaController.Callback() {
                        override fun onMetadataChanged(metadata: MediaMetadata?) { recorder.update(k, controller.packageName, metadata, controller.playbackState) }
                        override fun onPlaybackStateChanged(state: PlaybackState?) { recorder.update(k, controller.packageName, controller.metadata, state) }
                        override fun onSessionDestroyed() { removeController(k) }
                    }
                    callbacks[k] = callback
                    controller.registerCallback(callback)
                    // Only a newly detected session is synced here. Already-known sessions are driven by
                    // their callbacks, so unrelated notifications can no longer disturb the play counting.
                    recorder.update(k, controller.packageName, controller.metadata, controller.playbackState)
                }
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Media-session access is not available yet", e)
        } catch (e: Exception) { Log.e(TAG, "Could not refresh media sessions", e) }
    }

    private fun removeController(k: String) {
        callbacks.remove(k)?.let { cb -> controllers[k]?.unregisterCallback(cb) }
        controllers.remove(k)
        recorder.finish(k)
    }

    override fun onListenerDisconnected() {
        controllers.keys.toList().forEach(::removeController)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        controllers.keys.toList().forEach(::removeController)
        super.onDestroy()
    }

    private fun key(controller: MediaController) = controller.packageName + ":" + controller.sessionToken.hashCode()

    private fun selectedPackages(): Set<String> {
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val saved = prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, null)
        if (saved != null) return saved.toSet()
        // Compatibility with installations created before selectable players were added.
        return buildSet {
            if (prefs.getBoolean(MainActivity.KEY_SAMSUNG_MUSIC, true)) add(MainActivity.PKG_SAMSUNG_MUSIC)
            if (prefs.getBoolean(MainActivity.KEY_YOUTUBE_MUSIC, true)) add(MainActivity.PKG_YOUTUBE_MUSIC)
            if (prefs.getBoolean(MainActivity.KEY_MUSICOLET, true)) add(MainActivity.PKG_MUSICOLET)
        }
    }

    companion object { private const val TAG = "RewindYou" }
}

/**
 * Turns media-session events into listening "attempts".
 *
 * Rules:
 *  - Every second the player reports PLAYING is added to the listening time (restarts included).
 *  - A pause, buffering or seek keeps the same attempt; the clock just stops while not PLAYING.
 *  - Jumping back to the very beginning of the song (player position <= RESTART_ZONE_MS, coming from
 *    at least RESTART_MIN_JUMP_MS further ahead) closes the attempt and starts a new one.
 *  - A partial rewind (anywhere past the start zone) only adds time; it is NOT a new play.
 *  - An attempt counts as one play once it has accumulated MIN_PLAY_MS (30 s) of real listening.
 *  - Progress is written to the database every CHECKPOINT_MS and on pause/finish, so a killed
 *    service loses at most a few seconds.
 */
private class SessionRecorder(private val db: ListeningDatabase) {
    private class Attempt(val title: String, var artist: String, val pkg: String, val startedWall: Long) {
        var accumulatedMs = 0L      // listening time of the runs that already ended
        var runStartElapsed = -1L   // elapsedRealtime when the current PLAYING run began; -1 if not playing
        var savedMs = 0L            // how much of the total is already stored in the database
        var segmentId = -1L         // row in `segments` for this attempt (-1 until first save)
        var playCounted = false
        var refPosition = -1L       // last known song position in ms (-1 = unknown)
        var refElapsed = 0L         // elapsedRealtime when refPosition was taken
        var speed = 1f
        var cover: Bitmap? = null   // album art reported by the player, until it is stored
        var coverSaved = false

        val isPlaying: Boolean get() = runStartElapsed >= 0L
        fun listenedMs(now: Long): Long = accumulatedMs + if (isPlaying) (now - runStartElapsed).coerceAtLeast(0L) else 0L
        fun expectedPosition(now: Long): Long = when {
            refPosition < 0L -> -1L
            isPlaying -> refPosition + ((now - refElapsed).coerceAtLeast(0L) * speed).toLong()
            else -> refPosition
        }
    }

    private val attempts = ConcurrentHashMap<String, Attempt>()
    private val handler = Handler(Looper.getMainLooper())
    private var checkpointPending = false
    private val checkpointTask = Runnable { checkpoint() }

    @Synchronized fun update(key: String, pkg: String, metadata: MediaMetadata?, state: PlaybackState?) {
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)?.trim().orEmpty()
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.trim().orEmpty()
        val now = SystemClock.elapsedRealtime()
        var attempt = attempts[key]
        var trackChanged = false

        if (attempt != null && title.isNotBlank()) {
            if (isDifferentTrack(attempt, title, artist)) {
                finish(key); attempt = null; trackChanged = true
            } else if (attempt.artist.isBlank() && artist.isNotBlank() && attempt.segmentId <= 0L) {
                attempt.artist = artist
            }
        }

        when (state?.state ?: PlaybackState.STATE_NONE) {
            PlaybackState.STATE_PLAYING -> {
                if (title.isBlank()) return
                // On a track change the state we hold may still belong to the previous song.
                val position = if (trackChanged) -1L else positionOf(state, now)
                if (attempt != null && isRestart(attempt, position, now)) { finish(key); attempt = null }
                if (attempt == null) {
                    if (db.isIgnored(title, artist)) return
                    attempt = Attempt(title, artist, pkg, System.currentTimeMillis())
                    attempts[key] = attempt
                }
                if (!attempt.isPlaying) attempt.runStartElapsed = now
                attempt.refPosition = position
                attempt.refElapsed = now
                attempt.speed = (state?.playbackSpeed ?: 1f).takeIf { it > 0f } ?: 1f
                if (!attempt.coverSaved && attempt.cover == null) attempt.cover = coverOf(metadata)
                scheduleCheckpoint()
            }
            PlaybackState.STATE_PAUSED -> {
                if (attempt == null) return
                val position = positionOf(state, now)
                if (isRestart(attempt, position, now)) { finish(key); return }
                pauseClock(attempt, now)
                if (position >= 0L) { attempt.refPosition = position; attempt.refElapsed = now }
                flush(attempt, now)
            }
            PlaybackState.STATE_STOPPED, PlaybackState.STATE_NONE, PlaybackState.STATE_ERROR -> finish(key)
            else -> {
                // Buffering, connecting, skipping, fast-forward/rewind: stop the clock, keep the attempt.
                if (attempt != null) { pauseClock(attempt, now); flush(attempt, now) }
            }
        }
    }

    @Synchronized fun finish(key: String) {
        val attempt = attempts.remove(key) ?: return
        val now = SystemClock.elapsedRealtime()
        pauseClock(attempt, now)
        flush(attempt, now)
    }

    private fun pauseClock(a: Attempt, now: Long) {
        if (a.isPlaying) {
            a.accumulatedMs += (now - a.runStartElapsed).coerceAtLeast(0L)
            a.runStartElapsed = -1L
        }
    }

    private fun coverOf(metadata: MediaMetadata?): Bitmap? =
        metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    private fun isDifferentTrack(a: Attempt, title: String, artist: String): Boolean =
        a.title != title || (artist.isNotBlank() && a.artist.isNotBlank() && a.artist != artist)

    /** True when the song jumped back to its very beginning from somewhere clearly later. */
    private fun isRestart(a: Attempt, position: Long, now: Long): Boolean {
        if (position < 0L) return false
        val expected = a.expectedPosition(now)
        return expected >= 0L && position <= RESTART_ZONE_MS && expected - position >= RESTART_MIN_JUMP_MS
    }

    /**
     * PlaybackState.position is the position at lastPositionUpdateTime, not "right now".
     * Extrapolate it so a stale state is never mistaken for a seek.
     */
    private fun positionOf(state: PlaybackState?, now: Long): Long {
        if (state == null) return -1L
        val position = state.position
        if (position < 0L) return -1L
        if (state.state != PlaybackState.STATE_PLAYING) return position
        val updated = state.lastPositionUpdateTime
        if (updated <= 0L) return position
        val speed = if (state.playbackSpeed > 0f) state.playbackSpeed else 1f
        return position + ((now - updated).coerceAtLeast(0L) * speed).toLong()
    }

    /** Writes whatever listening time (and the play, once it reaches 30 s) is not stored yet. */
    private fun flush(a: Attempt, now: Long) {
        val total = a.listenedMs(now)
        val delta = total - a.savedMs
        val countPlay = !a.playCounted && total >= ListeningDatabase.MIN_PLAY_MS
        if (a.segmentId <= 0L && total < MIN_SAVE_MS) return // ignore blips shorter than 1 s
        if (delta <= 0L && !countPlay) return
        try {
            a.segmentId = db.recordProgress(a.segmentId, a.title, a.artist, a.pkg, a.startedWall, delta, countPlay)
            a.savedMs += delta
            if (countPlay) a.playCounted = true
            val art = a.cover
            if (!a.coverSaved && art != null && a.segmentId > 0L) {
                try { db.saveCover(a.title, a.artist, art, ListeningDatabase.SOURCE_PLAYER) } catch (e: Exception) { Log.w("RewindYou", "Could not save cover", e) }
                a.coverSaved = true
                a.cover = null
            }
        } catch (e: Exception) {
            Log.e("RewindYou", "Could not save listening progress", e)
        }
    }

    @Synchronized private fun checkpoint() {
        checkpointPending = false
        val now = SystemClock.elapsedRealtime()
        var anyPlaying = false
        for (a in attempts.values) {
            if (a.isPlaying) { anyPlaying = true; flush(a, now) }
        }
        if (anyPlaying) scheduleCheckpoint()
    }

    @Synchronized private fun scheduleCheckpoint() {
        if (!checkpointPending) {
            checkpointPending = true
            handler.postDelayed(checkpointTask, CHECKPOINT_MS)
        }
    }

    private companion object {
        const val RESTART_ZONE_MS = 3_000L      // "back at the start" = player position within the first 3 s
        const val RESTART_MIN_JUMP_MS = 5_000L  // ...coming from at least 5 s further ahead
        const val MIN_SAVE_MS = 1_000L
        const val CHECKPOINT_MS = 15_000L
    }
}
