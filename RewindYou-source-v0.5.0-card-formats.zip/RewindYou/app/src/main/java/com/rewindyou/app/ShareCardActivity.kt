package com.rewindyou.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Builds a shareable image of a summary, with several options, and saves or shares it. */
class ShareCardActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }
    private val ui by lazy { Ui(this) }
    private val handler = Handler(Looper.getMainLooper())
    private val renderTask = Runnable { renderPreview() }

    private var period = StatPeriod.WEEK
    private var offset = 0
    private var formatIndex = 0
    private var bgMode = 0          // 0 = palette style, 1 = blurred cover of the #1 song, 2 = the user's own image
    private var styleIndex = 0
    private var overlayIndex = 1    // how much the photo background is darkened
    private var artists = false
    private var covers = true
    private var customTitle = ""
    private var paletteName: String? = null   // null = same palette as the app

    private var ownImage: Bitmap? = null
    private var currentBitmap: Bitmap? = null
    private var savedUri: Uri? = null

    private lateinit var preview: ImageView
    private lateinit var controls: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        period = StatPeriod.values().getOrElse(intent.getIntExtra(EXTRA_PERIOD, 0)) { StatPeriod.WEEK }
        offset = intent.getIntExtra(EXTRA_OFFSET, 0).coerceAtMost(0)
        formatIndex = prefs.getInt("card_format", 0).coerceIn(0, CardRenderer.Format.values().size - 1)
        bgMode = prefs.getInt("card_bg_mode", 0).coerceIn(0, 2)
        styleIndex = prefs.getInt("card_style", 0).coerceIn(0, 2)
        overlayIndex = prefs.getInt("card_overlay", 1).coerceIn(0, 2)
        artists = prefs.getBoolean("card_artists", false)
        covers = prefs.getBoolean("card_covers", true)
        customTitle = prefs.getString("card_title", "") ?: ""
        paletteName = prefs.getString("card_palette", null)
        buildUi()
        renderControls()
        renderPreview()
    }

    override fun onDestroy() {
        handler.removeCallbacks(renderTask)
        super.onDestroy()
    }

    private fun buildUi() {
        ui.applySystemBars(window)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(ui.backgroundColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(28))
        }
        scroll.addView(root)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ui.button("◀", filled = false) { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(ui.label("Tarjeta para compartir", 22f, ui.textColor, true).apply { setPadding(ui.dp(14), 0, 0, 0) })
        root.addView(header, ui.matchWrap(12))

        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(preview, ui.matchWrap(14))

        root.addView(ui.buttonRow(
            ui.button("Guardar en galería") { saveClicked() },
            ui.button("Compartir", filled = false) { shareImage() }
        ), ui.matchWrap(8))

        val options = ui.card(14)
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        options.addView(controls)

        options.addView(optionLabel("Título personalizado"))
        val titleInput = EditText(this).apply {
            hint = "Por ejemplo: Mi semana con Nico"
            setText(customTitle)
            setSingleLine()
            textSize = 15f
            setTextColor(ui.textColor)
            setHintTextColor(ui.mutedColor)
            background = ui.rounded(ui.inactiveColor, 12)
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    customTitle = s?.toString().orEmpty()
                    prefs.edit().putString("card_title", customTitle).apply()
                    handler.removeCallbacks(renderTask)
                    handler.postDelayed(renderTask, 400)
                }
            })
        }
        options.addView(titleInput, ui.matchWrap(4))
        options.addView(ui.hint("Si lo dejás vacío se usa el título según el período."))
        root.addView(options, ui.matchWrap(8))
    }

    private fun optionLabel(text: String) = ui.label(text, 14f, ui.mutedColor, true).apply { setPadding(0, ui.dp(2), 0, ui.dp(8)) }

    /** Rebuilds the option selectors so the current choice is highlighted. */
    private fun renderControls() {
        controls.removeAllViews()

        controls.addView(optionLabel("Período"))
        controls.addView(ui.segmented(listOf("Semana", "Mes", "Año"), period.ordinal) { index ->
            period = StatPeriod.values()[index]
            offset = 0
            changed()
        }, ui.matchWrap(8))
        controls.addView(ui.buttonRow(
            ui.button("◀ Anterior", filled = false) { offset -= 1; changed() },
            ui.button("Siguiente ▶", filled = false) { if (offset < 0) { offset += 1; changed() } }
        ), ui.matchWrap(14))

        controls.addView(optionLabel("Proporción"))
        controls.addView(ui.segmented(CardRenderer.Format.values().map { it.label }, formatIndex) { index ->
            formatIndex = index
            prefs.edit().putInt("card_format", formatIndex).apply()
            changed()
        }, ui.matchWrap(14))

        controls.addView(optionLabel("Fondo"))
        controls.addView(ui.segmented(listOf("Estilo", "Carátula #1", "Mi imagen"), bgMode) { index ->
            bgMode = index
            prefs.edit().putInt("card_bg_mode", bgMode).apply()
            changed()
        }, ui.matchWrap(10))
        if (bgMode == 0) {
            controls.addView(optionLabel("Estilo"))
            controls.addView(ui.segmented(listOf("Color", "Oscuro", "Claro"), styleIndex) { index ->
                styleIndex = index
                prefs.edit().putInt("card_style", styleIndex).apply()
                changed()
            }, ui.matchWrap(14))
        } else {
            controls.addView(optionLabel("Oscurecer fondo"))
            controls.addView(ui.segmented(listOf("Poco", "Medio", "Mucho"), overlayIndex) { index ->
                overlayIndex = index
                prefs.edit().putInt("card_overlay", overlayIndex).apply()
                changed()
            }, ui.matchWrap(10))
            if (bgMode == 2) {
                controls.addView(ui.button("Elegir imagen de la galería") { pickBackground() }, ui.matchWrap(4))
                controls.addView(ui.hint(
                    if (ownImageFile().exists()) "Imagen elegida. Podés cambiarla cuando quieras."
                    else "Todavía no elegiste una imagen; mientras tanto se usa el estilo oscuro."
                ))
            } else {
                controls.addView(ui.hint("Usa la carátula de la canción #1, difuminada. Si no tiene carátula, se usa el estilo oscuro."))
            }
        }

        controls.addView(optionLabel("Colores"))
        controls.addView(paletteSwatches(), ui.matchWrap(14))

        controls.addView(optionLabel("Contenido"))
        controls.addView(ui.segmented(listOf("Canciones", "Artistas"), if (artists) 1 else 0) { index ->
            artists = index == 1
            prefs.edit().putBoolean("card_artists", artists).apply()
            changed()
        }, ui.matchWrap(14))

        controls.addView(optionLabel("Carátulas"))
        controls.addView(ui.segmented(listOf("Mostrar", "Ocultar"), if (covers) 0 else 1) { index ->
            covers = index == 0
            prefs.edit().putBoolean("card_covers", covers).apply()
            changed()
        }, ui.matchWrap(14))
    }

    private fun paletteSwatches(): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val current = paletteName ?: ui.palette.name
        MainActivity.PALETTES.forEachIndexed { i, p ->
            val selected = p.name == current
            row.addView(TextView(this).apply {
                text = if (selected) "✓" else ""
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.WHITE)
                contentDescription = p.name
                background = ui.gradient(p.primary, p.secondary, 12).also { if (selected) it.setStroke(ui.dp(3), ui.textColor) }
                setOnClickListener {
                    paletteName = p.name
                    prefs.edit().putString("card_palette", p.name).apply()
                    changed()
                }
            }, LinearLayout.LayoutParams(0, ui.dp(40), 1f).apply { if (i < MainActivity.PALETTES.size - 1) marginEnd = ui.dp(8) })
        }
        return row
    }

    private fun changed() {
        renderControls()
        renderPreview()
    }

    // ---------------- Imagen de fondo propia ----------------
    private fun ownImageFile() = File(filesDir, "card_bg.jpg")

    private fun loadOwnImage(): Bitmap? {
        ownImage?.let { return it }
        val file = ownImageFile()
        if (!file.exists()) return null
        ownImage = decodeFile(file, 1600)
        return ownImage
    }

    private fun decodeFile(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    @Suppress("DEPRECATION")
    private fun pickBackground() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_BACKGROUND)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_BACKGROUND || resultCode != RESULT_OK || uri == null) return
        try {
            val bitmap = decodeUri(uri, 2048)
            if (bitmap == null) {
                toast("No se pudo leer la imagen.")
                return
            }
            ownImageFile().outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            ownImage = null
            bgMode = 2
            prefs.edit().putInt("card_bg_mode", bgMode).apply()
            changed()
        } catch (e: Exception) {
            toast("No se pudo guardar la imagen: ${e.message}")
        }
    }

    private fun decodeUri(uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
    }

    // ---------------- Dibujo ----------------
    private fun renderPreview() {
        val (from, to) = periodRange(period, offset)
        val s = db.summary(from, to, 8)
        val rows: List<CardRenderer.Row> = if (artists) {
            s.topArtists.map { CardRenderer.Row(it.artist, ui.playsLabel(it.plays), null) }
        } else {
            s.topTracks.map { CardRenderer.Row(it.title, "${it.artist} · ${ui.playsLabel(it.plays)}", if (covers) db.coverBitmap(it.coverHash) else null) }
        }
        val palette = MainActivity.PALETTES.firstOrNull { it.name == paletteName } ?: ui.palette
        val topCover = s.topTracks.firstOrNull()?.let { db.coverBitmap(it.coverHash, Int.MAX_VALUE) }
        var photo: Bitmap? = null
        var blur = false
        when (bgMode) {
            1 -> { photo = topCover; blur = true }
            2 -> photo = loadOwnImage()
        }
        val detail = "${ui.playsLabel(s.plays)} · ${s.uniqueTracks} ${if (s.uniqueTracks == 1) "canción" else "canciones"}"
        val data = CardRenderer.Data(
            format = CardRenderer.Format.values()[formatIndex],
            style = if (bgMode == 0) CardRenderer.Style.values()[styleIndex] else CardRenderer.Style.DARK,
            palette = palette,
            title = customTitle.trim().ifEmpty { period.cardTitle },
            periodLabel = periodLabel(period, from, to) + (if (offset == 0) " (en curso)" else ""),
            heroTime = ui.formatLong(s.listenedMs),
            heroDetail = detail,
            rows = rows,
            showCovers = covers && !artists,
            featuredCover = if (covers && !artists) topCover else null,
            photo = photo,
            blurPhoto = blur,
            overlayAlpha = intArrayOf(90, 140, 190)[overlayIndex],
            logo = BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher_foreground)
        )
        val bitmap = CardRenderer.render(data)
        currentBitmap = bitmap
        savedUri = null
        preview.setImageBitmap(bitmap)
    }

    // ---------------- Guardar y compartir ----------------
    private fun saveClicked() {
        if (saveToGallery() != null) toast("Guardada en Imágenes/RewindYou.")
    }

    private fun shareImage() {
        val uri = saveToGallery() ?: return
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                "Compartir tarjeta"
            )
        )
    }

    /** Stores the image in Pictures/RewindYou (no permission needed on Android 10+). */
    private fun saveToGallery(): Uri? {
        val bitmap = currentBitmap ?: return null
        savedUri?.let { return it }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("Guardar en la galería requiere Android 10 o superior.")
            return null
        }
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "RewindYou-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/RewindYou")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("No se pudo crear el archivo")
            val stream = contentResolver.openOutputStream(uri) ?: error("No se pudo escribir la imagen")
            stream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            savedUri = uri
            uri
        } catch (e: Exception) {
            toast("No se pudo guardar la imagen: ${e.message}")
            null
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        const val EXTRA_PERIOD = "period"
        const val EXTRA_OFFSET = "offset"
        private const val REQ_BACKGROUND = 4401
    }
}
