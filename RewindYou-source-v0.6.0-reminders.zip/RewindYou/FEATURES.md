# RewindYou — product requirements and implementation plan

This document records the agreed requirements for the next stages. It is a specification, not proof that every feature is implemented in the current prototype.

## Music capture
- Track playback from the selected players: Samsung Music, YouTube Music, and Musicolet.
- Store statistics locally on the device. No account or cloud service is required for core functionality.
- Record title, artist, source player, listening duration, and counted plays, subject to the metadata/events Android exposes.
- Count a play after at least 30 seconds. Pauses do not add listening time. A resume after pause should continue the same play; a player-reported restart should be treated as a new play.

## Recap generation
- Provide manual recap generation from inside the app for a user-selected week, month, or year.
- Allow selecting past periods as well as the current period where appropriate.
- Automatically prepare a monthly recap after the month ends and an annual recap after the year ends.
- Notify the user when an automatic recap is ready.
- The notification opens the app/recap. It must not automatically save, post, or share an image. The user previews the recap and explicitly saves the image.
- Schedule work using Android-compatible background scheduling and account for battery optimization / delayed execution. Do not promise exact-time execution when Android defers background work.
- Avoid duplicate recaps/notifications for the same period; keep generated recap history available inside the app.

## Recap image editor
- Offer both editable starter templates and a blank canvas to create a design from scratch.
- Advanced editing: move and resize elements on the canvas.
- Let users add, remove, and rearrange recap elements such as title, date range, listening time, top songs/artists, rankings, and optional artwork.
- Allow adjusting text, fonts, sizes, colors, backgrounds, and layout; allow selecting an image from the device as a background where Android permissions/pickers permit.
- Show a preview before export and let the user manually save the finished image to the device.
- Keep template/layout settings local and allow reusing saved designs.
- Generate shareable image files locally; do not share automatically.

## Implemented in source version 0.2.0 (not yet build-verified here)
- Light, dark, and follow-system appearance modes.
- Six selectable color palettes.
- Select installed launcher apps to monitor; Samsung Music and Musicolet are the suggested defaults.
- Adapt status/navigation bar colors and status-bar icon contrast to the selected appearance.

## Suggested implementation stages
1. Build and test appearance and player selection on the actual Samsung phone; verify Samsung Music and Musicolet with the screen locked.
2. Improve track identity so listening from different players can be grouped by title and artist while preserving per-listening source.
3. Add album/cover lookup using online music databases, a recoverable local image cache, and manual cover replacement.
4. Add recap-period queries and manual weekly/monthly/yearly recap screens.
5. Add recap history and scheduled monthly/yearly generation with notifications.
6. Implement a canvas/editor with movable and resizable elements, editable templates, and blank-canvas creation.
7. Render and export the recap image, then test on the target phone.

## Known technical caveats
- Android media-session events and metadata vary by player version; exact restart/seek detection may not always be exposed.
- Android battery management can delay scheduled background work.
- The existing project is an early source prototype and has not been compiled or tested in this environment. The features above are requirements/planned work, not claims of completed functionality.

## Implemented in source version 0.2.2 (not yet build-verified here)
- Play counting rewritten: one "attempt" per pass at a song. Pauses/buffering keep the same attempt; every second of real playback (restarts included) is added to the listening time.
- A jump back to the very beginning of the song starts a new attempt; a partial rewind only adds time and is not a new play.
- A play is counted once per attempt, after 30 s of real listening.
- Unrelated notifications no longer re-evaluate active sessions (they used to split songs into several plays).
- Progress is saved every 15 s, so a killed service loses at most a few seconds.
- The top list shows number of plays per song instead of minutes and seconds.

## Implemented in source version 0.2.4 (not yet build-verified here)
- Manual summaries by week (Monday start), month and year, for the current period or earlier ones (Anterior / Siguiente).
- Each summary shows listening time, plays, distinct songs, busiest day, top 5 songs and top 5 artists, and can be shared as text.
- Built only from the existing `segments` table (attempt start date), so no database migration is needed.

## Implemented in source version 0.2.5 (not yet build-verified here)
- Backup: "Exportar" saves all statistics to a JSON file chosen by the user; "Importar" replaces the current data with a backup (single transaction, nothing changes if the file is invalid).
- The database schema is unchanged (still version 1).

## Implemented in source version 0.2.6 (not yet build-verified here)
- New app icon (adaptive icon plus classic PNG icons).
- Dark mode: appearance/palette selectors now use readable text colors.
- Full ranking screen ("Biblioteca"): all songs or all artists, best first, with search.
- Manual metadata editing: tap a song to change title/artist; tap an artist to rename it on all their songs. If the result equals an existing song, the two are merged (plays and time are added).
- Corrections are remembered in a new `aliases` table, so future plays reported with the old text are stored under the corrected one. Database version 2 (additive migration, data kept). Backups now include the aliases.
- Summary rankings can show Top 5 / 10 / 25.

## Implemented in source version 0.3.0 (not yet build-verified here)
- New look: gradient "this week" card, summary tiles, ranked list with badges, pill-style selectors, rounded cards. Colors follow the chosen mode and palette (shared `Ui.kt`).
- New Ajustes screen (gear button, top right): mode, palette swatches, player selection, permissions/battery shortcuts and backup. The home screen no longer carries those sections.
- A status card on the home screen tells whether the media access is enabled and offers a shortcut when it is not.
- Summaries open on the current week by default, with Semana / Mes / Año selector.

## Implemented in source version 0.4.0 (not yet build-verified here)
- Album covers: while a song plays, the small album art the player reports is stored locally (192 px thumbnail, deduplicated by content hash, table `covers`, files in `files/covers`). It is shown in the home Top 5 and in the full ranking. Nothing is downloaded. Songs get a cover the next time they are played. Covers are not part of the JSON backup. Database version 3 (additive migration).
- Shareable image card: period (week/month/year, with previous periods), format (square or story), style (color/dark/light), palette, custom title, songs or artists, covers on/off. Saved to Pictures/RewindYou or shared (Android 10+).
- Period helpers moved to `Periods.kt`.

## Implemented in source version 0.4.1 (not yet build-verified here)
- Covers are now stored up to 512 px (a larger image from the player replaces a smaller stored one). The database records each cover's size and source (player / files / manual); version 4 (additive migration).
- Ajustes > Carátulas: scans the phone's music catalog (MediaStore) for embedded art of songs without cover or with a small one. No internet. Needs the audio permission and Android 10+.
- Ranking completo > edit a song > "Carátula…": pick an image from the gallery/files as that song's cover (never overwritten automatically).
- Share card: the #1 song now has a large cover.

## Implemented in source version 0.4.2 (not yet build-verified here)
- Ranking completo: tap a song for a menu (edit, change cover, delete). Long-press selects several songs to delete at once (with "Todas" for everything shown by the search).
- Delete options: only this entry; delete and ignore this exact song; delete and ignore by text (contains rule, e.g. "-WA0" for WhatsApp audios). Matches are listed before confirming.
- Ignored rules are checked before recording, so ignored songs are no longer tracked. Managed in Ajustes > Ignorados. Included in backups. Database version 5 (additive).
- Deleting a song also removes its plays, time, cover and manual corrections.

## Implemented in source version 0.5.0 (not yet build-verified here)
- Share card: five proportions (1:1, 9:16, 3:4, 4:3, 16:9) with three layouts; the #1 song's large cover heads the image.
- Gold, silver and bronze medals for ranks 1-3 on the card and in every ranking list of the app.
- Card background: palette style (color/dark/light), the #1 cover blurred, or the user's own image from the gallery/files (copied into the app, darkening level adjustable).

## Implemented in source version 0.6.0 (not yet build-verified here)
- End-of-month and end-of-year reminders (Ajustes > Avisos de resumen), all adjustable: on/off for each, the day of the month (or the last day), the date of the year reminder (Nov 20 - Dec 10), the time, and automatic card creation. Presets: Recomendado (last day / Dec 1) and Anticipado (day 28 / Nov 28). Test notification button.
- With automatic creation the card is built from the saved card options, saved to Pictures/RewindYou and shown in the notification; tapping it opens the card screen to edit it. Alarms are inexact and rescheduled after reboot or update.
- Card building moved to `CardFactory` (shared by the card screen and the reminders).
- Ajustes shows "Creado por XaviCastle55" / "Created by XaviCastle55" below the version.
