package com.rewindyou.app

import android.annotation.TargetApi
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Builds the summary card image from the saved card options. Used by the card screen and by the reminders. */
object CardFactory {
    fun build(context: Context, db: ListeningDatabase, period: StatPeriod, offset: Int): Bitmap {
        val prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val formats = CardRenderer.Format.values()
        val formatIndex = prefs.getInt("card_format", 0).coerceIn(0, formats.size - 1)
        val bgMode = prefs.getInt("card_bg_mode", 0).coerceIn(0, 2)
        val styleIndex = prefs.getInt("card_style", 0).coerceIn(0, 2)
        val overlayIndex = prefs.getInt("card_overlay", 1).coerceIn(0, 2)
        val artists = prefs.getBoolean("card_artists", false)
        val covers = prefs.getBoolean("card_covers", true)
        val customTitle = prefs.getString("card_title", "") ?: ""

        val palettes = MainActivity.PALETTES
        val appPaletteName = prefs.getString(MainActivity.KEY_PALETTE, palettes[0].name)
        val cardPaletteName = prefs.getString("card_palette", null)
        val palette = palettes.firstOrNull { it.name == cardPaletteName }
            ?: palettes.firstOrNull { it.name == appPaletteName }
            ?: palettes[0]

        val (from, to) = periodRange(period, offset)
        val s = db.summary(from, to, 8)
        val rows: List<CardRenderer.Row> = if (artists) {
            s.topArtists.map { CardRenderer.Row(it.artist, playsText(it.plays), null) }
        } else {
            s.topTracks.map { CardRenderer.Row(it.title, "${it.artist} · ${playsText(it.plays)}", if (covers) db.coverBitmap(it.coverHash) else null) }
        }
        val topCover = s.topTracks.firstOrNull()?.let { db.coverBitmap(it.coverHash, Int.MAX_VALUE) }
        var photo: Bitmap? = null
        var blur = false
        when (bgMode) {
            1 -> { photo = topCover; blur = true }
            2 -> photo = loadOwnImage(context)
        }
        val detail = "${playsText(s.plays)} · ${s.uniqueTracks} ${if (s.uniqueTracks == 1) "canción" else "canciones"}"
        val data = CardRenderer.Data(
            format = formats[formatIndex],
            style = if (bgMode == 0) CardRenderer.Style.values()[styleIndex] else CardRenderer.Style.DARK,
            palette = palette,
            title = customTitle.trim().ifEmpty { period.cardTitle },
            periodLabel = periodLabel(period, from, to) + (if (offset == 0) " (en curso)" else ""),
            heroTime = durationText(s.listenedMs),
            heroDetail = detail,
            rows = rows,
            showCovers = covers && !artists,
            featuredCover = if (covers && !artists) topCover else null,
            photo = photo,
            blurPhoto = blur,
            overlayAlpha = intArrayOf(90, 140, 190)[overlayIndex],
            logo = BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher_foreground)
        )
        return CardRenderer.render(data)
    }

    /** Stores the image in Pictures/RewindYou (no permission needed on Android 10+). */
    @TargetApi(Build.VERSION_CODES.Q)
    fun saveToGallery(context: Context, bitmap: Bitmap): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "RewindYou-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/RewindYou")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("No se pudo crear el archivo")
        val stream = resolver.openOutputStream(uri) ?: error("No se pudo escribir la imagen")
        stream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }

    private fun loadOwnImage(context: Context): Bitmap? {
        val file = File(context.filesDir, "card_bg.jpg")
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1600) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun playsText(n: Int) = "$n ${if (n == 1) "reproducción" else "reproducciones"}"

    private fun durationText(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return when {
            h > 0 -> "$h h $m min"
            m > 0 -> "$m min $s s"
            else -> "$s s"
        }
    }
}
