package com.rewindyou.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * End-of-month and end-of-year reminders. Everything is adjustable in Ajustes:
 * on/off, the day (month) or date (year), the time, and whether the card is created automatically.
 * Alarms are inexact (no special permission), so a reminder can arrive a few minutes late.
 */
object ReminderScheduler {
    const val KEY_MONTH_ON = "rem_month_on"
    const val KEY_YEAR_ON = "rem_year_on"
    const val KEY_MONTH_DAY = "rem_month_day"   // 0 = last day of the month, 1..31 = that day (or the last day if the month is shorter)
    const val KEY_YEAR_DATE = "rem_year_date"   // month * 100 + day, for example 1201 = December 1
    const val KEY_HOUR = "rem_hour"
    const val KEY_MINUTE = "rem_minute"
    const val KEY_AUTO = "rem_auto"
    const val TYPE_MONTH = "month"
    const val TYPE_YEAR = "year"
    const val EXTRA_TYPE = "reminder_type"
    private const val CHANNEL_ID = "summaries"

    private fun prefs(context: Context) = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)

    /** Sets (or cancels) the next alarm of each reminder according to the saved settings. */
    fun scheduleAll(context: Context) {
        val p = prefs(context)
        val now = System.currentTimeMillis()
        val hour = p.getInt(KEY_HOUR, 20)
        val minute = p.getInt(KEY_MINUTE, 0)
        schedule(context, TYPE_MONTH, if (p.getBoolean(KEY_MONTH_ON, false)) nextMonthly(now, p.getInt(KEY_MONTH_DAY, 0), hour, minute) else null)
        schedule(context, TYPE_YEAR, if (p.getBoolean(KEY_YEAR_ON, false)) nextYearly(now, p.getInt(KEY_YEAR_DATE, 1201), hour, minute) else null)
    }

    private fun pendingFor(context: Context, type: String): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            if (type == TYPE_YEAR) 12 else 11,
            Intent(context, ReminderReceiver::class.java).putExtra(EXTRA_TYPE, type),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun schedule(context: Context, type: String, whenMs: Long?) {
        val alarms = context.getSystemService(AlarmManager::class.java)
        val pending = pendingFor(context, type)
        if (whenMs == null) {
            alarms.cancel(pending)
        } else {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pending)
        }
    }

    /** The next moment after [now] at [hour]:[minute] on the chosen day of a month (0 = last day). */
    fun nextMonthly(now: Long, dayChoice: Int, hour: Int, minute: Int): Long {
        for (i in 0..13) {
            val c = Calendar.getInstance()
            c.timeInMillis = now
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.add(Calendar.MONTH, i)
            val last = c.getActualMaximum(Calendar.DAY_OF_MONTH)
            c.set(Calendar.DAY_OF_MONTH, if (dayChoice <= 0) last else minOf(dayChoice, last))
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis > now) return c.timeInMillis
        }
        return now + 24L * 60 * 60 * 1000
    }

    /** The next moment after [now] at [hour]:[minute] on the chosen date (month * 100 + day) of a year. */
    fun nextYearly(now: Long, dateCode: Int, hour: Int, minute: Int): Long {
        val month0 = (dateCode / 100 - 1).coerceIn(0, 11)
        val day = (dateCode % 100).coerceIn(1, 28 + 3)
        for (i in 0..2) {
            val c = Calendar.getInstance()
            c.timeInMillis = now
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.set(Calendar.MONTH, month0)
            c.add(Calendar.YEAR, i)
            c.set(Calendar.DAY_OF_MONTH, minOf(day, c.getActualMaximum(Calendar.DAY_OF_MONTH)))
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis > now) return c.timeInMillis
        }
        return now + 24L * 60 * 60 * 1000
    }

    /** Creates the card (if automatic creation is on) and posts the notification. Call it off the main thread. */
    fun fire(context: Context, type: String) {
        val period = if (type == TYPE_YEAR) StatPeriod.YEAR else StatPeriod.MONTH
        var bitmap: Bitmap? = null
        var saved = false
        if (prefs(context).getBoolean(KEY_AUTO, true) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val db = ListeningDatabase(context)
                val card = CardFactory.build(context, db, period, 0)
                CardFactory.saveToGallery(context, card)
                bitmap = card
                saved = true
            } catch (e: Exception) {
                Log.w("RewindYou", "Could not create the automatic card", e)
            }
        }
        postNotification(context, period, saved, bitmap)
    }

    private fun postNotification(context: Context, period: StatPeriod, saved: Boolean, card: Bitmap?) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Resúmenes", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Avisos de fin de mes y de fin de año"
            }
        )
        val monthName = SimpleDateFormat("MMMM", Locale.forLanguageTag("es")).format(Date())
        val title = if (period == StatPeriod.YEAR) "Tu año en música" else "Tu resumen de $monthName"
        val what = if (period == StatPeriod.YEAR) "resumen del año" else "resumen del mes"
        val text = if (saved) "Tu tarjeta ya está lista. Tocá para verla, editarla o compartirla."
        else "Tocá para crear tu tarjeta con el $what."
        val open = Intent(context, ShareCardActivity::class.java)
            .putExtra(ShareCardActivity.EXTRA_PERIOD, period.ordinal)
            .putExtra(ShareCardActivity.EXTRA_OFFSET, 0)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            context,
            if (period == StatPeriod.YEAR) 22 else 21,
            open,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_rewind)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pending)
            .setAutoCancel(true)
        if (card != null) {
            // A reduced copy: very large images do not fit in a notification.
            val width = minOf(card.width, 800)
            val small = Bitmap.createScaledBitmap(card, width, (card.height * width.toFloat() / card.width).toInt().coerceAtLeast(1), true)
            builder.setStyle(Notification.BigPictureStyle().bigPicture(small).setSummaryText(text))
        }
        manager.notify(if (period == StatPeriod.YEAR) 2 else 1, builder.build())
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(ReminderScheduler.EXTRA_TYPE) ?: return
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                ReminderScheduler.fire(app, type)
            } catch (e: Exception) {
                Log.e("RewindYou", "Reminder failed", e)
            } finally {
                try { ReminderScheduler.scheduleAll(app) } catch (e: Exception) { Log.e("RewindYou", "Could not reschedule", e) }
                pending.finish()
            }
        }.start()
    }
}

/** Sets the alarms again after the phone restarts or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.scheduleAll(context.applicationContext)
    }
}
