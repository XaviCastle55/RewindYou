package com.rewindyou.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/**
 * Shared look of every screen: colors that follow the chosen mode and palette (read live from the
 * preferences) plus small builders for cards, buttons, segmented controls and ranking rows.
 */
class Ui(private val activity: Activity) {
    private val prefs = activity.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)

    // ---------- Colors ----------
    val systemDark: Boolean
        get() = (activity.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
    val dark: Boolean
        get() = when (prefs.getString(MainActivity.KEY_THEME_MODE, MainActivity.THEME_SYSTEM)) {
            MainActivity.THEME_DARK -> true
            MainActivity.THEME_LIGHT -> false
            else -> systemDark
        }
    val palette: MainActivity.Palette
        get() = MainActivity.PALETTES.firstOrNull { it.name == prefs.getString(MainActivity.KEY_PALETTE, MainActivity.PALETTES[0].name) } ?: MainActivity.PALETTES[0]

    val backgroundColor: Int get() = if (dark) palette.darkBg else palette.lightBg
    val surfaceColor: Int get() = if (dark) blend(palette.darkBg, Color.WHITE, 0.08f) else Color.WHITE
    val textColor: Int get() = if (dark) Color.rgb(246, 243, 252) else Color.rgb(34, 31, 46)
    val mutedColor: Int get() = if (dark) Color.rgb(184, 178, 203) else Color.rgb(98, 92, 120)
    val inactiveColor: Int get() = if (dark) blend(palette.darkBg, Color.WHITE, 0.16f) else Color.rgb(228, 224, 240)
    val outlineColor: Int get() = if (dark) Color.argb(36, 255, 255, 255) else Color.argb(22, 0, 0, 0)
    val accentColor: Int get() = if (dark) blend(palette.primary, Color.WHITE, 0.4f) else palette.primary
    val okColor: Int get() = if (dark) Color.rgb(116, 222, 164) else Color.rgb(24, 128, 78)
    val warnColor: Int get() = if (dark) Color.rgb(255, 189, 105) else Color.rgb(176, 88, 0)
    val warnBackground: Int get() = if (dark) Color.rgb(64, 44, 22) else Color.rgb(255, 240, 222)

    /** Changes when the mode, palette or system dark setting changes, so a screen knows it must be rebuilt. */
    fun signature(): String =
        "${prefs.getString(MainActivity.KEY_THEME_MODE, "")}|${prefs.getString(MainActivity.KEY_PALETTE, "")}|$systemDark"

    fun applySystemBars(window: Window) {
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (!dark) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
    }

    fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    fun shade(color: Int, factor: Float): Int =
        Color.rgb((Color.red(color) * factor).toInt(), (Color.green(color) * factor).toInt(), (Color.blue(color) * factor).toInt())

    fun dp(value: Int): Int = (value * activity.resources.displayMetrics.density).toInt()

    // ---------- Drawables ----------
    fun rounded(color: Int, radiusDp: Int = 16, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

    fun gradient(from: Int, to: Int, radiusDp: Int = 22): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
        }

    // ---------- Text ----------
    fun label(value: String, sizeSp: Float = 15f, color: Int = textColor, bold: Boolean = false): TextView = TextView(activity).apply {
        text = value
        textSize = sizeSp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun section(value: String): TextView = label(value, 12f, accentColor, true).apply {
        letterSpacing = 0.08f
        setPadding(dp(4), dp(18), 0, dp(8))
    }

    fun hint(value: String, sizeSp: Float = 13f): TextView = label(value, sizeSp, mutedColor).apply {
        setPadding(dp(4), dp(2), dp(4), dp(10))
    }

    fun playsLabel(n: Int): String = "$n ${if (n == 1) "reproducción" else "reproducciones"}"

    fun formatShort(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return when {
            h > 0 -> "${h}h ${m}m"
            m > 0 -> "${m}m ${s}s"
            else -> "${s}s"
        }
    }

    fun formatLong(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return when {
            h > 0 -> "$h h $m min"
            m > 0 -> "$m min $s s"
            else -> "$s s"
        }
    }

    // ---------- Containers ----------
    fun card(paddingDp: Int = 14): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(surfaceColor, 18, outlineColor, 1)
        setPadding(dp(paddingDp), dp(paddingDp), dp(paddingDp), dp(paddingDp))
    }

    fun hero(): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(palette.primary, shade(palette.primary, 0.62f), 24)
        setPadding(dp(20), dp(18), dp(20), dp(18))
    }

    fun divider(): View = View(activity).apply {
        setBackgroundColor(outlineColor)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    }

    fun matchWrap(bottomDp: Int = 8): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(bottomDp) }

    // ---------- Controls ----------
    fun button(value: String, filled: Boolean = true, action: () -> Unit): Button = Button(activity).apply {
        text = value
        isAllCaps = false
        textSize = 14f
        stateListAnimator = null
        minHeight = dp(46)
        minWidth = dp(48)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setTextColor(if (filled) Color.WHITE else textColor)
        val base = rounded(if (filled) palette.primary else inactiveColor, 14)
        background = RippleDrawable(ColorStateList.valueOf(Color.argb(60, 128, 128, 128)), base, null)
        setOnClickListener { action() }
    }

    fun buttonRow(vararg buttons: Button): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.HORIZONTAL
        buttons.forEachIndexed { i, b ->
            addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i < buttons.size - 1) marginEnd = dp(8) })
        }
    }

    /** Pill-shaped selector; the entry at [selected] is highlighted. */
    fun segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(inactiveColor, 14)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        labels.forEachIndexed { index, name ->
            row.addView(TextView(activity).apply {
                text = name
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(10), dp(8), dp(10))
                if (index == selected) {
                    setTextColor(Color.WHITE)
                    typeface = Typeface.DEFAULT_BOLD
                    background = rounded(palette.primary, 12)
                } else {
                    setTextColor(mutedColor)
                }
                setOnClickListener { onSelect(index) }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    fun statTile(valueView: TextView, caption: String): LinearLayout = card(12).apply {
        gravity = Gravity.CENTER_HORIZONTAL
        valueView.gravity = Gravity.CENTER
        valueView.maxLines = 1
        addView(valueView)
        addView(label(caption, 12f, mutedColor).apply { gravity = Gravity.CENTER })
    }

    /** A label with an on/off switch at its right. */
    fun toggle(labelText: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        row.addView(label(labelText, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val primary = palette.primary
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        row.addView(Switch(activity).apply {
            isChecked = checked
            thumbTintList = ColorStateList(states, intArrayOf(primary, if (dark) Color.rgb(200, 196, 214) else Color.WHITE))
            trackTintList = ColorStateList(states, intArrayOf(Color.argb(130, Color.red(primary), Color.green(primary), Color.blue(primary)), inactiveColor))
            setOnCheckedChangeListener { _, value -> onChange(value) }
        })
        return row
    }

    // ---------- Ranking rows ----------
    /** Row layout: rank badge, cover thumbnail (optional) and two lines of text. */
    fun rankRow(): LinearLayout {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        row.addView(TextView(activity).apply {
            gravity = Gravity.CENTER
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(palette.primary) }
        }, LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(10) })
        row.addView(ImageView(activity).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(inactiveColor, 10)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                }
            }
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(12) })
        val texts = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label("", 15f, textColor, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        texts.addView(label("", 13f, mutedColor).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    fun bindRankRow(row: LinearLayout, rank: Int, title: String, subtitle: String, cover: Bitmap? = null, showCover: Boolean = false) {
        val badge = row.getChildAt(0) as TextView
        badge.text = rank.toString()
        val medal = medalOf(rank)
        if (medal != null) {
            // Gold, silver and bronze for the podium
            badge.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(medal.light, medal.dark)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), medal.ring)
            }
            badge.setTextColor(medal.text)
        } else {
            badge.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(palette.primary) }
            badge.setTextColor(Color.WHITE)
        }
        val image = row.getChildAt(1) as ImageView
        image.visibility = if (showCover) View.VISIBLE else View.GONE
        image.setImageBitmap(cover)
        val texts = row.getChildAt(2) as LinearLayout
        (texts.getChildAt(0) as TextView).text = title
        (texts.getChildAt(1) as TextView).text = subtitle
    }

    private class Medal(val light: Int, val dark: Int, val ring: Int, val text: Int)

    private fun medalOf(rank: Int): Medal? = when (rank) {
        1 -> Medal(Color.rgb(255, 232, 128), Color.rgb(199, 144, 20), Color.rgb(150, 100, 8), Color.rgb(84, 55, 0))
        2 -> Medal(Color.rgb(246, 249, 252), Color.rgb(140, 152, 166), Color.rgb(98, 110, 124), Color.rgb(48, 58, 70))
        3 -> Medal(Color.rgb(240, 178, 120), Color.rgb(150, 82, 34), Color.rgb(108, 56, 20), Color.rgb(64, 32, 8))
        else -> null
    }

    // ---------- System state ----------
    fun listenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(activity.contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { ComponentName.unflattenFromString(it)?.packageName == activity.packageName }
    }
}
