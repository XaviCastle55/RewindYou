package com.rewindyou.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils

/** Draws the shareable summary image. Pure drawing: everything it shows comes in through [Data]. */
object CardRenderer {
    enum class Style { COLOR, DARK, LIGHT }

    enum class Format(val label: String, val width: Int, val height: Int) {
        SQUARE("1:1", 1080, 1080),
        STORY("9:16", 1080, 1920),
        PORTRAIT("3:4", 1080, 1440),
        LANDSCAPE("4:3", 1440, 1080),
        WIDE("16:9", 1920, 1080)
    }

    class Row(val title: String, val subtitle: String, val cover: Bitmap?)

    class Data(
        val format: Format,
        val style: Style,                 // used when there is no photo background
        val palette: MainActivity.Palette,
        val title: String,
        val periodLabel: String,
        val heroTime: String,
        val heroDetail: String,
        val rows: List<Row>,              // #1 first
        val showCovers: Boolean,
        val featuredCover: Bitmap?,       // large image for the #1 song
        val photo: Bitmap?,               // optional photo background
        val blurLevel: Int,               // 0 = sharp, 1..10 = increasingly blurred
        val overlayAlpha: Int,            // 0..255 black layer over the photo so the text stays readable
        val logo: Bitmap?
    )

    private class Look(val text: Int, val muted: Int, val accent: Int, val badge: Int, val placeholder: Int)
    private class MedalColors(val light: Int, val dark: Int, val ring: Int, val text: Int)

    fun render(d: Data): Bitmap {
        val w = d.format.width
        val h = d.format.height
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        val look = drawBackground(c, d, w.toFloat(), h.toFloat())
        when (d.format) {
            Format.SQUARE -> drawCompact(c, d, look, w.toFloat(), 380f, 150f, 76f, 4, 50f, 70f)
            Format.PORTRAIT -> drawCompact(c, d, look, w.toFloat(), 420f, 170f, 96f, 6, 52f, 66f)
            Format.STORY -> drawStory(c, d, look, w.toFloat())
            Format.LANDSCAPE -> drawWide(c, d, look, w.toFloat(), 520f, 52f, 84f, 88f)
            Format.WIDE -> drawWide(c, d, look, w.toFloat(), 640f, 60f, 104f, 96f)
        }
        c.drawText("Generado con RewindYou", 72f, h - 44f, textPaint(28f, look.muted))
        return bitmap
    }

    // ---------------- Layouts ----------------

    /** 1:1 and 3:4 — cover at the top left, numbers at its right, ranking below. */
    private fun drawCompact(
        c: Canvas, d: Data, look: Look, w: Float,
        coverSize: Float, coverY: Float, rowH: Float, rowCount: Int, titleSize: Float, kpiSize: Float
    ) {
        val margin = 72f
        val s = coverSize / 380f
        drawHeader(c, d, look, margin, 76f, 1f)
        drawFeaturedArt(c, d, look, margin, coverY, coverSize)
        val colX = margin + coverSize + 40f
        drawStats(c, d, look, colX, w - margin - colX, coverY + 65f * s, titleSize, coverY + 112f * s, coverY + 210f * s, kpiSize, coverY + 254f * s)
        d.rows.firstOrNull()?.let { first ->
            val titlePaint = textPaint(40f * s, look.text, true)
            val subPaint = textPaint(28f * s, look.muted)
            c.drawText(fit(first.title, titlePaint, w - 2 * margin), margin, coverY + coverSize + 62f * s, titlePaint)
            c.drawText(fit(first.subtitle, subPaint, w - 2 * margin), margin, coverY + coverSize + 104f * s, subPaint)
        }
        val y0 = coverY + coverSize + 140f * s
        d.rows.drop(1).take(rowCount).forEachIndexed { i, row -> drawRow(c, d, look, margin, y0 + i * rowH, rowH, w - 2 * margin, i + 2, row) }
        drawEmptyNote(c, d, look, margin, y0)
    }

    /** 9:16 — big centered cover, then the ranking. */
    private fun drawStory(c: Canvas, d: Data, look: Look, w: Float) {
        val margin = 72f
        val maxW = w - 2 * margin
        drawHeader(c, d, look, margin, 96f, 1.1f)
        drawStats(c, d, look, margin, maxW, 300f, 78f, 360f, 470f, 96f, 528f)
        val coverSize = 520f
        val coverTop = 580f
        drawFeaturedArt(c, d, look, (w - coverSize) / 2f, coverTop, coverSize)
        d.rows.firstOrNull()?.let { first ->
            val titlePaint = textPaint(54f, look.text, true)
            val subPaint = textPaint(36f, look.muted)
            val title = fit(first.title, titlePaint, maxW)
            val sub = fit(first.subtitle, subPaint, maxW)
            c.drawText(title, (w - titlePaint.measureText(title)) / 2f, coverTop + coverSize + 70f, titlePaint)
            c.drawText(sub, (w - subPaint.measureText(sub)) / 2f, coverTop + coverSize + 122f, subPaint)
        }
        val y0 = 1290f
        d.rows.drop(1).take(5).forEachIndexed { i, row -> drawRow(c, d, look, margin, y0 + i * 104f, 104f, maxW, i + 2, row) }
        drawEmptyNote(c, d, look, margin, y0)
    }

    /** 4:3 and 16:9 — cover on the left, numbers and ranking on the right. */
    private fun drawWide(c: Canvas, d: Data, look: Look, w: Float, coverSize: Float, titleSize: Float, kpiSize: Float, rowH: Float) {
        val margin = 72f
        drawHeader(c, d, look, margin, 76f, 1f)
        val coverTop = 160f
        drawFeaturedArt(c, d, look, margin, coverTop, coverSize)
        d.rows.firstOrNull()?.let { first ->
            val titlePaint = textPaint(40f, look.text, true)
            val subPaint = textPaint(28f, look.muted)
            c.drawText(fit(first.title, titlePaint, coverSize + 40f), margin, coverTop + coverSize + 62f, titlePaint)
            c.drawText(fit(first.subtitle, subPaint, coverSize + 40f), margin, coverTop + coverSize + 104f, subPaint)
        }
        val x0 = margin + coverSize + 72f
        val colW = w - margin - x0
        drawStats(c, d, look, x0, colW, 230f, titleSize, 284f, 410f, kpiSize, 458f)
        val y0 = 520f
        d.rows.drop(1).take(5).forEachIndexed { i, row -> drawRow(c, d, look, x0, y0 + i * rowH, rowH, colW, i + 2, row) }
        drawEmptyNote(c, d, look, x0, y0)
    }

    // ---------------- Pieces ----------------

    private fun drawHeader(c: Canvas, d: Data, look: Look, margin: Float, centerY: Float, scale: Float) {
        val box = 112f * scale
        val left = margin - 22f * scale
        d.logo?.let { c.drawBitmap(it, null, RectF(left, centerY - box / 2f, left + box, centerY + box / 2f), Paint(Paint.FILTER_BITMAP_FLAG)) }
        c.drawText("RewindYou", margin + 62f * scale, centerY + 15f * scale, textPaint(42f * scale, look.text, true))
    }

    private fun drawStats(
        c: Canvas, d: Data, look: Look, x: Float, maxW: Float,
        titleY: Float, titleSize: Float, periodY: Float, kpiY: Float, kpiSize: Float, detailY: Float
    ) {
        val titlePaint = textPaint(titleSize, look.text, true)
        while (titlePaint.measureText(d.title) > maxW && titlePaint.textSize > 30f) titlePaint.textSize -= 2f
        c.drawText(fit(d.title, titlePaint, maxW), x, titleY, titlePaint)
        val small = titleSize * 0.56f
        val periodPaint = textPaint(small, look.muted)
        c.drawText(fit(d.periodLabel, periodPaint, maxW), x, periodY, periodPaint)
        val kpiPaint = textPaint(kpiSize, look.text, true)
        while (kpiPaint.measureText(d.heroTime) > maxW && kpiPaint.textSize > 36f) kpiPaint.textSize -= 4f
        c.drawText(d.heroTime, x, kpiY, kpiPaint)
        val detailPaint = textPaint(small, look.muted)
        c.drawText(fit(d.heroDetail, detailPaint, maxW), x, detailY, detailPaint)
    }

    /** The #1 song: its large cover with a gold medal, or a tile with a big medal when there is no cover. */
    private fun drawFeaturedArt(c: Canvas, d: Data, look: Look, left: Float, top: Float, size: Float) {
        if (d.rows.isEmpty()) return
        val cover = if (d.showCovers) (d.featuredCover ?: d.rows[0].cover) else null
        if (cover != null) {
            drawCover(c, cover, left, top, size, look.placeholder)
            drawMedal(c, left + size * 0.17f, top + size * 0.17f, size * 0.12f, 1, look.badge)
        } else {
            val rect = RectF(left, top, left + size, top + size)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(left, top, left + size, top + size, withAlpha(d.palette.primary, 235), shade(d.palette.primary, 0.5f), Shader.TileMode.CLAMP)
            }
            c.drawRoundRect(rect, size * 0.08f, size * 0.08f, paint)
            drawMedal(c, left + size / 2f, top + size / 2f, size * 0.28f, 1, look.badge)
        }
    }

    private fun drawRow(c: Canvas, d: Data, look: Look, x: Float, top: Float, rowH: Float, width: Float, rank: Int, row: Row) {
        val centerY = top + rowH / 2f
        val radius = rowH * 0.30f
        drawMedal(c, x + radius, centerY, radius, rank, look.badge)
        var textX = x + 2f * radius + 22f
        if (d.showCovers) {
            val size = rowH - 14f
            drawCover(c, row.cover, textX, centerY - size / 2f, size, look.placeholder)
            textX += size + 20f
        }
        val maxW = x + width - textX
        val titlePaint = textPaint(rowH * 0.30f, look.text, true)
        val subPaint = textPaint(rowH * 0.23f, look.muted)
        c.drawText(fit(row.title, titlePaint, maxW), textX, centerY - rowH * 0.02f, titlePaint)
        c.drawText(fit(row.subtitle, subPaint, maxW), textX, centerY + rowH * 0.28f, subPaint)
    }

    private fun drawEmptyNote(c: Canvas, d: Data, look: Look, x: Float, y: Float) {
        if (d.rows.isEmpty()) c.drawText("Todavía no hay escucha en este período.", x, y + 40f, textPaint(34f, look.muted))
    }

    /** Gold, silver and bronze for ranks 1–3; a plain badge in the palette color for the rest. */
    private fun drawMedal(c: Canvas, cx: Float, cy: Float, r: Float, rank: Int, badgeColor: Int) {
        val number = rank.toString()
        val medal = medalColors(rank)
        if (medal == null) {
            c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = badgeColor })
            val paint = textPaint(r * 1.0f, Color.WHITE, true)
            c.drawText(number, cx - paint.measureText(number) / 2f, cy + paint.textSize * 0.35f, paint)
            return
        }
        c.drawCircle(cx, cy + r * 0.07f, r * 1.04f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) })
        c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = medal.ring })
        val face = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, medal.light, medal.dark, Shader.TileMode.CLAMP)
        }
        c.drawCircle(cx, cy, r * 0.86f, face)
        c.drawCircle(cx, cy, r * 0.70f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = r * 0.06f
            color = withAlpha(medal.light, 170)
        })
        c.drawOval(RectF(cx - r * 0.62f, cy - r * 0.74f, cx + r * 0.08f, cy - r * 0.22f), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(95, 255, 255, 255) })
        val paint = textPaint(r * 1.0f, medal.text, true)
        c.drawText(number, cx - paint.measureText(number) / 2f, cy + paint.textSize * 0.35f, paint)
    }

    private fun medalColors(rank: Int): MedalColors? = when (rank) {
        1 -> MedalColors(Color.rgb(255, 232, 128), Color.rgb(199, 144, 20), Color.rgb(150, 100, 8), Color.rgb(84, 55, 0))
        2 -> MedalColors(Color.rgb(246, 249, 252), Color.rgb(140, 152, 166), Color.rgb(98, 110, 124), Color.rgb(48, 58, 70))
        3 -> MedalColors(Color.rgb(240, 178, 120), Color.rgb(150, 82, 34), Color.rgb(108, 56, 20), Color.rgb(64, 32, 8))
        else -> null
    }

    private fun drawCover(c: Canvas, cover: Bitmap?, left: Float, top: Float, size: Float, placeholder: Int) {
        val rect = RectF(left, top, left + size, top + size)
        val radius = size * 0.12f
        if (cover == null) {
            c.drawRoundRect(rect, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = placeholder })
            return
        }
        val path = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        c.save()
        c.clipPath(path)
        c.drawBitmap(cover, null, rect, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restore()
    }

    // ---------------- Background ----------------

    private fun drawBackground(c: Canvas, d: Data, w: Float, h: Float): Look {
        val p = d.palette
        val photo = d.photo
        if (photo != null) {
            val dest = RectF(0f, 0f, w, h)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            if (d.blurLevel > 0) {
                c.drawBitmap(blurredFor(photo, w.toInt(), h.toInt(), d.blurLevel), null, dest, paint)
            } else {
                c.drawBitmap(photo, centerCropRect(photo, w, h), dest, paint)
            }
            c.drawColor(Color.argb(d.overlayAlpha.coerceIn(0, 255), 0, 0, 0))
            return Look(
                text = Color.rgb(246, 243, 252),
                muted = Color.argb(205, 246, 243, 252),
                accent = blend(p.primary, Color.WHITE, 0.5f),
                badge = p.primary,
                placeholder = Color.argb(50, 255, 255, 255)
            )
        }
        val look: Look
        val decoColor: Int
        when (d.style) {
            Style.COLOR -> {
                val gradient = LinearGradient(0f, 0f, w, h, p.primary, shade(p.primary, 0.42f), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, Paint().apply { shader = gradient })
                look = Look(Color.WHITE, Color.argb(205, 255, 255, 255), Color.WHITE, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
                decoColor = Color.argb(34, 255, 255, 255)
            }
            Style.DARK -> {
                c.drawColor(p.darkBg)
                look = Look(Color.rgb(246, 243, 252), Color.argb(190, 246, 243, 252), blend(p.primary, Color.WHITE, 0.45f), p.primary, Color.argb(40, 255, 255, 255))
                decoColor = withAlpha(p.primary, 80)
            }
            Style.LIGHT -> {
                c.drawColor(p.lightBg)
                look = Look(Color.rgb(34, 31, 46), Color.argb(185, 34, 31, 46), p.primary, p.primary, Color.argb(40, 0, 0, 0))
                decoColor = withAlpha(p.primary, 45)
            }
        }
        val deco = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = decoColor }
        c.drawCircle(w * 0.93f, h * 0.05f, minOf(w, h) * 0.38f, deco)
        c.drawCircle(w * 0.02f, h * 0.99f, minOf(w, h) * 0.30f, deco)
        return look
    }

    private fun centerCropRect(src: Bitmap, w: Float, h: Float): Rect {
        val scale = maxOf(w / src.width, h / src.height)
        val sw = (w / scale).toInt().coerceIn(1, src.width)
        val sh = (h / scale).toInt().coerceIn(1, src.height)
        val left = (src.width - sw) / 2
        val top = (src.height - sh) / 2
        return Rect(left, top, left + sw, top + sh)
    }

    /**
     * A small, blurred copy of the photo cropped to the card's proportions (drawn stretched to full size).
     * A higher [level] (1..10) means a smaller working image and a wider blur, so the result is softer.
     */
    private fun blurredFor(photo: Bitmap, w: Int, h: Int, level: Int): Bitmap {
        val divisor = 2 + level * 2
        val radius = 1 + level / 3
        val passes = 1 + level / 5
        val small = Bitmap.createBitmap(maxOf(w / divisor, 16), maxOf(h / divisor, 16), Bitmap.Config.ARGB_8888)
        val dest = RectF(0f, 0f, small.width.toFloat(), small.height.toFloat())
        Canvas(small).drawBitmap(photo, centerCropRect(photo, dest.width(), dest.height()), dest, Paint(Paint.FILTER_BITMAP_FLAG))
        repeat(passes) { boxBlur(small, radius) }
        return small
    }

    private fun boxBlur(bitmap: Bitmap, radius: Int) {
        val w = bitmap.width
        val h = bitmap.height
        val src = IntArray(w * h)
        bitmap.getPixels(src, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        val n = 2 * radius + 1
        for (y in 0 until h) {
            for (x in 0 until w) {
                var a = 0; var r = 0; var g = 0; var b = 0
                for (k in -radius..radius) {
                    val p = src[y * w + (x + k).coerceIn(0, w - 1)]
                    a += p ushr 24; r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255
                }
                tmp[y * w + x] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var a = 0; var r = 0; var g = 0; var b = 0
                for (k in -radius..radius) {
                    val p = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                    a += p ushr 24; r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255
                }
                src[y * w + x] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        bitmap.setPixels(src, 0, w, 0, 0, w, h)
    }

    // ---------------- Helpers ----------------

    private fun textPaint(size: Float, color: Int, bold: Boolean = false, spacing: Float = 0f): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            letterSpacing = spacing
        }

    private fun fit(text: String, paint: TextPaint, maxWidth: Float): String =
        TextUtils.ellipsize(text, paint, maxWidth, TextUtils.TruncateAt.END).toString()

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    private fun shade(color: Int, factor: Float): Int =
        Color.rgb((Color.red(color) * factor).toInt(), (Color.green(color) * factor).toInt(), (Color.blue(color) * factor).toInt())

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}
