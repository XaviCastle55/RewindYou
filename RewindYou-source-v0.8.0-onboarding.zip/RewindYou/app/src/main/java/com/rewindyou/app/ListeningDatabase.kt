package com.rewindyou.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only store. Each listening attempt is one row in `segments`; an attempt counts as a play after 30 s of listening. */
class ListeningDatabase(context: Context) : SQLiteOpenHelper(context, "rewindyou.db", null, 5) {
    private val appContext: Context = context.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            source_package TEXT NOT NULL,
            plays INTEGER NOT NULL DEFAULT 0,
            listened_ms INTEGER NOT NULL DEFAULT 0,
            last_played_ms INTEGER NOT NULL,
            UNIQUE(title, artist)
        )""")
        db.execSQL("CREATE TABLE segments (id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, started_ms INTEGER NOT NULL, listened_ms INTEGER NOT NULL, counted_as_play INTEGER NOT NULL, FOREIGN KEY(track_id) REFERENCES tracks(id))")
        createAliasTable(db)
        createCoverTable(db)
        createIgnoredTable(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Additive migration: existing statistics are kept untouched.
        if (oldVersion < 2) createAliasTable(db)
        if (oldVersion < 3) {
            createCoverTable(db) // already includes the size/source columns
        } else if (oldVersion < 4) {
            db.execSQL("ALTER TABLE covers ADD COLUMN size INTEGER NOT NULL DEFAULT 192")
            db.execSQL("ALTER TABLE covers ADD COLUMN source TEXT NOT NULL DEFAULT 'player'")
        }
        if (oldVersion < 5) createIgnoredTable(db)
    }

    /** Songs the user does not want recorded. [artist] empty = "contains" rule; otherwise exact title + artist. */
    private fun createIgnoredTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS ignored (text TEXT NOT NULL, artist TEXT NOT NULL DEFAULT '', PRIMARY KEY(text, artist))")
    }

    /** One small cover image per song; identical images share a single file (`hash`). */
    private fun createCoverTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS covers (track_id INTEGER PRIMARY KEY, hash TEXT NOT NULL, size INTEGER NOT NULL DEFAULT 192, source TEXT NOT NULL DEFAULT 'player')")
    }

    /** Remembers manual corrections: what the player reports (orig) -> what the user wants stored (new). */
    private fun createAliasTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS aliases (orig_title TEXT NOT NULL, orig_artist TEXT NOT NULL, new_title TEXT NOT NULL, new_artist TEXT NOT NULL, PRIMARY KEY(orig_title, orig_artist))")
    }

    /**
     * Adds listening progress for one attempt (one pass at a song, pauses included).
     * [segmentId] <= 0 creates the attempt's row in `segments`; otherwise that row is extended.
     * [countPlay] adds one play to the track and flags the segment as a play. Returns the segment id.
     */
    @Synchronized
    fun recordProgress(segmentId: Long, title: String, artist: String, sourcePackage: String, startedMs: Long, deltaMs: Long, countPlay: Boolean): Long {
        if (title.isBlank() || (deltaMs <= 0L && !countPlay)) return segmentId
        var cleanTitle = title.trim()
        var cleanArtist = artist.ifBlank { UNKNOWN_ARTIST }.trim()
        if (isIgnored(cleanTitle, cleanArtist)) return segmentId
        val plays = if (countPlay) 1 else 0
        val now = System.currentTimeMillis()
        val db = writableDatabase
        var id = segmentId
        db.beginTransaction()
        try {
            // Apply the user's manual corrections, if this song was edited before.
            db.rawQuery("SELECT new_title, new_artist FROM aliases WHERE orig_title=? AND orig_artist=?", arrayOf(cleanTitle, cleanArtist)).use { c ->
                if (c.moveToFirst()) { cleanTitle = c.getString(0); cleanArtist = c.getString(1) }
            }
            val values = ContentValues().apply {
                put("title", cleanTitle)
                put("artist", cleanArtist)
                put("source_package", sourcePackage)
                put("last_played_ms", now)
            }
            db.insertWithOnConflict("tracks", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            val trackId = db.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=?", arrayOf(cleanTitle, cleanArtist))
                .use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            check(trackId > 0) { "track row not found" }
            db.execSQL("UPDATE tracks SET plays=plays+?, listened_ms=listened_ms+?, last_played_ms=? WHERE id=?", arrayOf(plays, deltaMs, now, trackId))
            if (id > 0) {
                db.execSQL("UPDATE segments SET listened_ms=listened_ms+?, counted_as_play=MAX(counted_as_play, ?) WHERE id=?", arrayOf(deltaMs, plays, id))
            } else {
                db.execSQL("INSERT INTO segments(track_id, started_ms, listened_ms, counted_as_play) VALUES(?,?,?,?)", arrayOf(trackId, startedMs, deltaMs, plays))
                id = db.rawQuery("SELECT last_insert_rowid()", null).use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return id
    }

    fun totals(): Totals {
        readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(SUM(plays),0), COALESCE(SUM(listened_ms),0) FROM tracks", null).use { c ->
            if (c.moveToFirst()) return Totals(c.getInt(0), c.getInt(1), c.getLong(2))
        }
        return Totals(0, 0, 0L)
    }

    fun topTracks(limit: Int = 5): List<TrackStat> {
        val out = mutableListOf<TrackStat>()
        readableDatabase.rawQuery("SELECT t.title, t.artist, t.source_package, t.plays, t.listened_ms, c.hash FROM tracks t LEFT JOIN covers c ON c.track_id = t.id ORDER BY t.plays DESC, t.listened_ms DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4), c.getString(5))
        }
        return out
    }

    /**
     * Summary of the listening whose attempt started in [fromMs, toMs).
     * Uses only the existing `segments` table, so no schema change is needed.
     */
    fun summary(fromMs: Long, toMs: Long, limit: Int = 5): PeriodSummary {
        val range = arrayOf(fromMs.toString(), toMs.toString())
        val rdb = readableDatabase
        var listenedMs = 0L
        var plays = 0
        var unique = 0
        rdb.rawQuery("SELECT COALESCE(SUM(listened_ms),0), COALESCE(SUM(counted_as_play),0), COUNT(DISTINCT track_id) FROM segments WHERE started_ms >= ? AND started_ms < ?", range).use { c ->
            if (c.moveToFirst()) { listenedMs = c.getLong(0); plays = c.getInt(1); unique = c.getInt(2) }
        }
        var busiestDayMs: Long? = null
        rdb.rawQuery("SELECT MIN(started_ms) FROM segments WHERE started_ms >= ? AND started_ms < ? GROUP BY strftime('%Y-%m-%d', started_ms/1000, 'unixepoch', 'localtime') ORDER BY SUM(listened_ms) DESC LIMIT 1", range).use { c ->
            if (c.moveToFirst()) busiestDayMs = c.getLong(0)
        }
        val tracks = mutableListOf<TrackStat>()
        rdb.rawQuery("SELECT t.title, t.artist, t.source_package, SUM(s.counted_as_play) AS p, SUM(s.listened_ms) AS ms, (SELECT hash FROM covers WHERE track_id = t.id) FROM segments s JOIN tracks t ON t.id = s.track_id WHERE s.started_ms >= ? AND s.started_ms < ? GROUP BY t.id HAVING p > 0 ORDER BY p DESC, ms DESC LIMIT ?", arrayOf(range[0], range[1], limit.toString())).use { c ->
            while (c.moveToNext()) tracks += TrackStat(c.getString(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4), c.getString(5))
        }
        val artists = mutableListOf<ArtistStat>()
        rdb.rawQuery("SELECT t.artist, SUM(s.counted_as_play) AS p, SUM(s.listened_ms) AS ms FROM segments s JOIN tracks t ON t.id = s.track_id WHERE s.started_ms >= ? AND s.started_ms < ? GROUP BY t.artist HAVING p > 0 ORDER BY p DESC, ms DESC LIMIT ?", arrayOf(range[0], range[1], limit.toString())).use { c ->
            while (c.moveToNext()) artists += ArtistStat(c.getString(0), c.getInt(1), c.getLong(2))
        }
        return PeriodSummary(listenedMs, plays, unique, busiestDayMs, tracks, artists)
    }

    /** Whole database as JSON text, for backups. */
    @Synchronized
    fun exportJson(settings: org.json.JSONObject? = null): String {
        val rdb = readableDatabase
        val tracks = org.json.JSONArray()
        rdb.rawQuery("SELECT id, title, artist, source_package, plays, listened_ms, last_played_ms FROM tracks ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                tracks.put(org.json.JSONObject()
                    .put("id", c.getLong(0)).put("title", c.getString(1)).put("artist", c.getString(2))
                    .put("source_package", c.getString(3)).put("plays", c.getInt(4))
                    .put("listened_ms", c.getLong(5)).put("last_played_ms", c.getLong(6)))
            }
        }
        val segments = org.json.JSONArray()
        rdb.rawQuery("SELECT track_id, started_ms, listened_ms, counted_as_play FROM segments ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                segments.put(org.json.JSONObject()
                    .put("track_id", c.getLong(0)).put("started_ms", c.getLong(1))
                    .put("listened_ms", c.getLong(2)).put("counted_as_play", c.getInt(3)))
            }
        }
        val aliases = org.json.JSONArray()
        rdb.rawQuery("SELECT orig_title, orig_artist, new_title, new_artist FROM aliases", null).use { c ->
            while (c.moveToNext()) {
                aliases.put(org.json.JSONObject()
                    .put("orig_title", c.getString(0)).put("orig_artist", c.getString(1))
                    .put("new_title", c.getString(2)).put("new_artist", c.getString(3)))
            }
        }
        val ignoredRules = org.json.JSONArray()
        rdb.rawQuery("SELECT text, artist FROM ignored", null).use { c ->
            while (c.moveToNext()) ignoredRules.put(org.json.JSONObject().put("text", c.getString(0)).put("artist", c.getString(1)))
        }
        val root = org.json.JSONObject()
            .put("app", "RewindYou").put("format", 1).put("exported_ms", System.currentTimeMillis())
            .put("tracks", tracks).put("segments", segments).put("aliases", aliases).put("ignored", ignoredRules)
        if (settings != null) root.put("settings", settings)
        return root.toString()
    }

    /**
     * Replaces ALL data with the content of a backup made by [exportJson].
     * Runs in one transaction: if the file is invalid nothing changes. Returns (songs, attempts) imported.
     */
    @Synchronized
    fun importJson(text: String): Pair<Int, Int> {
        val root = org.json.JSONObject(text)
        require(root.optString("app") == "RewindYou" && root.optInt("format", 0) == 1) { "Not a RewindYou backup" }
        val tracks = root.getJSONArray("tracks")
        val segments = root.getJSONArray("segments")
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM segments")
            db.execSQL("DELETE FROM tracks")
            db.execSQL("DELETE FROM aliases")
            db.execSQL("DELETE FROM covers")
            db.execSQL("DELETE FROM ignored")
            for (i in 0 until tracks.length()) {
                val t = tracks.getJSONObject(i)
                val values = ContentValues().apply {
                    put("id", t.getLong("id"))
                    put("title", t.getString("title"))
                    put("artist", t.getString("artist"))
                    put("source_package", t.optString("source_package", ""))
                    put("plays", t.getInt("plays"))
                    put("listened_ms", t.getLong("listened_ms"))
                    put("last_played_ms", t.getLong("last_played_ms"))
                }
                db.insertOrThrow("tracks", null, values)
            }
            for (i in 0 until segments.length()) {
                val g = segments.getJSONObject(i)
                val values = ContentValues().apply {
                    put("track_id", g.getLong("track_id"))
                    put("started_ms", g.getLong("started_ms"))
                    put("listened_ms", g.getLong("listened_ms"))
                    put("counted_as_play", g.getInt("counted_as_play"))
                }
                db.insertOrThrow("segments", null, values)
            }
            val aliases = root.optJSONArray("aliases") // absent in backups made before 0.2.6
            if (aliases != null) {
                for (i in 0 until aliases.length()) {
                    val a = aliases.getJSONObject(i)
                    val values = ContentValues().apply {
                        put("orig_title", a.getString("orig_title"))
                        put("orig_artist", a.getString("orig_artist"))
                        put("new_title", a.getString("new_title"))
                        put("new_artist", a.getString("new_artist"))
                    }
                    db.insertWithOnConflict("aliases", null, values, SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            val ignoredRules = root.optJSONArray("ignored") // absent in backups made before 0.4.2
            if (ignoredRules != null) {
                for (i in 0 until ignoredRules.length()) {
                    val r = ignoredRules.getJSONObject(i)
                    val values = ContentValues().apply {
                        put("text", r.getString("text"))
                        put("artist", r.optString("artist", ""))
                    }
                    db.insertWithOnConflict("ignored", null, values, SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return tracks.length() to segments.length()
    }

    /** All songs, best first, for the full ranking. */
    fun allTracks(): List<LibraryTrack> {
        val out = mutableListOf<LibraryTrack>()
        readableDatabase.rawQuery("SELECT t.id, t.title, t.artist, t.plays, c.hash FROM tracks t LEFT JOIN covers c ON c.track_id = t.id ORDER BY t.plays DESC, t.listened_ms DESC, t.title COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out += LibraryTrack(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getString(4))
        }
        return out
    }

    /** All artists, best first. */
    fun allArtists(): List<LibraryArtist> {
        val out = mutableListOf<LibraryArtist>()
        readableDatabase.rawQuery("SELECT artist, SUM(plays) AS p, COUNT(*) AS n FROM tracks GROUP BY artist ORDER BY p DESC, SUM(listened_ms) DESC, artist COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out += LibraryArtist(c.getString(0), c.getInt(1), c.getInt(2))
        }
        return out
    }

    fun findTrackId(title: String, artist: String): Long? =
        readableDatabase.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=?", arrayOf(title, artist)).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        }

    /**
     * Changes a song's title/artist. If another song already has that title and artist, the two are
     * merged (plays and time are added up). The correction is remembered, so future plays that the
     * player reports with the old text are stored under the corrected one.
     */
    @Synchronized
    fun updateTrack(id: Long, newTitle: String, newArtist: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            applyTrackEdit(db, id, newTitle.trim(), newArtist.trim().ifBlank { UNKNOWN_ARTIST })
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Renames an artist on all of their songs. Returns how many songs were processed. */
    @Synchronized
    fun renameArtist(oldArtist: String, newArtist: String): Int {
        val target = newArtist.trim().ifBlank { UNKNOWN_ARTIST }
        val db = writableDatabase
        var count = 0
        db.beginTransaction()
        try {
            val rows = mutableListOf<Pair<Long, String>>()
            db.rawQuery("SELECT id, title FROM tracks WHERE artist=?", arrayOf(oldArtist)).use { c ->
                while (c.moveToNext()) rows += c.getLong(0) to c.getString(1)
            }
            for ((id, title) in rows) { applyTrackEdit(db, id, title, target); count++ }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return count
    }

    private fun applyTrackEdit(db: SQLiteDatabase, id: Long, newTitle: String, newArtist: String) {
        require(newTitle.isNotEmpty()) { "empty title" }
        var oldTitle = ""
        var oldArtist = ""
        db.rawQuery("SELECT title, artist FROM tracks WHERE id=?", arrayOf(id.toString())).use { c ->
            if (!c.moveToFirst()) return
            oldTitle = c.getString(0)
            oldArtist = c.getString(1)
        }
        if (oldTitle == newTitle && oldArtist == newArtist) return
        val existing = db.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=? AND id<>?", arrayOf(newTitle, newArtist, id.toString())).use { c ->
            if (c.moveToFirst()) c.getLong(0) else -1L
        }
        // Corrections that already pointed to the old text now point to the new one.
        db.execSQL("UPDATE aliases SET new_title=?, new_artist=? WHERE new_title=? AND new_artist=?", arrayOf(newTitle, newArtist, oldTitle, oldArtist))
        // Editing back to a text that used to be corrected removes that correction.
        db.execSQL("DELETE FROM aliases WHERE orig_title=? AND orig_artist=?", arrayOf(newTitle, newArtist))
        db.execSQL("INSERT OR REPLACE INTO aliases(orig_title, orig_artist, new_title, new_artist) VALUES(?,?,?,?)", arrayOf(oldTitle, oldArtist, newTitle, newArtist))
        if (existing > 0) mergeTracks(db, id, existing)
        else db.execSQL("UPDATE tracks SET title=?, artist=? WHERE id=?", arrayOf(newTitle, newArtist, id))
    }

    private fun mergeTracks(db: SQLiteDatabase, fromId: Long, intoId: Long) {
        db.execSQL("UPDATE segments SET track_id=? WHERE track_id=?", arrayOf(intoId, fromId))
        db.execSQL(
            "UPDATE tracks SET plays = plays + (SELECT plays FROM tracks WHERE id=?), listened_ms = listened_ms + (SELECT listened_ms FROM tracks WHERE id=?), last_played_ms = MAX(last_played_ms, (SELECT last_played_ms FROM tracks WHERE id=?)) WHERE id=?",
            arrayOf(fromId, fromId, fromId, intoId)
        )
        db.execSQL("UPDATE covers SET track_id=? WHERE track_id=? AND NOT EXISTS (SELECT 1 FROM covers WHERE track_id=?)", arrayOf(intoId, fromId, intoId))
        db.execSQL("DELETE FROM covers WHERE track_id=?", arrayOf(fromId))
        db.execSQL("DELETE FROM tracks WHERE id=?", arrayOf(fromId))
    }

    // ---------------- Eliminar e ignorar ----------------
    @Synchronized
    fun addIgnored(rule: IgnoreRule) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO ignored(text, artist) VALUES(?,?)", arrayOf(rule.text, rule.artist))
    }

    @Synchronized
    fun removeIgnored(rule: IgnoreRule) {
        writableDatabase.execSQL("DELETE FROM ignored WHERE text=? AND artist=?", arrayOf(rule.text, rule.artist))
    }

    fun allIgnored(): List<IgnoreRule> {
        val out = mutableListOf<IgnoreRule>()
        readableDatabase.rawQuery("SELECT text, artist FROM ignored ORDER BY text COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out += IgnoreRule(c.getString(0), c.getString(1))
        }
        return out
    }

    /** True if the song (as the player reports it, or as corrected by the user) matches an ignore rule. */
    fun isIgnored(title: String, artist: String): Boolean {
        val rules = allIgnored()
        if (rules.isEmpty()) return false
        val t = title.trim()
        val a = artist.ifBlank { UNKNOWN_ARTIST }.trim()
        if (rules.any { it.matches(t, a) }) return true
        var mapped: Pair<String, String>? = null
        readableDatabase.rawQuery("SELECT new_title, new_artist FROM aliases WHERE orig_title=? AND orig_artist=?", arrayOf(t, a)).use { c ->
            if (c.moveToFirst()) mapped = c.getString(0) to c.getString(1)
        }
        val m = mapped ?: return false
        return rules.any { it.matches(m.first, m.second) }
    }

    /** Recorded songs that the rule would match. */
    fun tracksMatching(rule: IgnoreRule): List<LibraryTrack> {
        val out = mutableListOf<LibraryTrack>()
        readableDatabase.rawQuery("SELECT id, title, artist, plays FROM tracks ORDER BY plays DESC", null).use { c ->
            while (c.moveToNext()) {
                val title = c.getString(1)
                val artist = c.getString(2)
                if (rule.matches(title, artist)) out += LibraryTrack(c.getLong(0), title, artist, c.getInt(3))
            }
        }
        return out
    }

    /** Deletes songs with their plays, time, covers and corrections. Returns how many were deleted. */
    @Synchronized
    fun deleteTracks(ids: List<Long>): Int {
        if (ids.isEmpty()) return 0
        val db = writableDatabase
        val hashes = mutableSetOf<String>()
        var count = 0
        db.beginTransaction()
        try {
            for (id in ids) {
                var found = false
                var title = ""
                var artist = ""
                var hash: String? = null
                db.rawQuery("SELECT t.title, t.artist, (SELECT hash FROM covers WHERE track_id = t.id) FROM tracks t WHERE t.id=?", arrayOf(id.toString())).use { c ->
                    if (c.moveToFirst()) { found = true; title = c.getString(0); artist = c.getString(1); hash = c.getString(2) }
                }
                if (!found) continue
                db.execSQL("DELETE FROM segments WHERE track_id=?", arrayOf(id))
                db.execSQL("DELETE FROM covers WHERE track_id=?", arrayOf(id))
                db.execSQL("DELETE FROM aliases WHERE (new_title=? AND new_artist=?) OR (orig_title=? AND orig_artist=?)", arrayOf(title, artist, title, artist))
                db.execSQL("DELETE FROM tracks WHERE id=?", arrayOf(id))
                hash?.let { hashes += it }
                count++
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        for (h in hashes) {
            val used = db.rawQuery("SELECT 1 FROM covers WHERE hash=?", arrayOf(h)).use { it.moveToFirst() }
            if (!used) coverFile(h).delete()
        }
        return count
    }

    // ---------------- Carátulas ----------------
    /**
     * Stores the album art for a song (looked up by the text the player reports).
     * A better (larger) image replaces a smaller one; a cover chosen by the user is never replaced automatically.
     */
    @Synchronized
    fun saveCover(title: String, artist: String, art: Bitmap, source: String): Boolean {
        val db = writableDatabase
        var t = title.trim()
        var a = artist.ifBlank { UNKNOWN_ARTIST }.trim()
        db.rawQuery("SELECT new_title, new_artist FROM aliases WHERE orig_title=? AND orig_artist=?", arrayOf(t, a)).use { c ->
            if (c.moveToFirst()) { t = c.getString(0); a = c.getString(1) }
        }
        val trackId = db.rawQuery("SELECT id FROM tracks WHERE title=? AND artist=?", arrayOf(t, a)).use { c ->
            if (c.moveToFirst()) c.getLong(0) else -1L
        }
        if (trackId <= 0L) return false
        return saveCoverForTrack(trackId, art, source)
    }

    @Synchronized
    fun saveCoverForTrack(trackId: Long, art: Bitmap, source: String): Boolean {
        if (art.width <= 0 || art.height <= 0) return false
        val db = writableDatabase
        val newSize = minOf(art.width, art.height, COVER_MAX_PX)
        var oldHash: String? = null
        var oldSize = 0
        var oldSource = ""
        db.rawQuery("SELECT hash, size, source FROM covers WHERE track_id=?", arrayOf(trackId.toString())).use { c ->
            if (c.moveToFirst()) { oldHash = c.getString(0); oldSize = c.getInt(1); oldSource = c.getString(2) }
        }
        if (oldHash != null) {
            if (oldSource == SOURCE_MANUAL && source != SOURCE_MANUAL) return false
            if (source != SOURCE_MANUAL && newSize <= oldSize) return false
        }
        val bytes = encodeCover(art, newSize)
        val hash = sha1(bytes)
        val file = coverFile(hash)
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            file.writeBytes(bytes)
        }
        db.execSQL("INSERT OR REPLACE INTO covers(track_id, hash, size, source) VALUES(?,?,?,?)", arrayOf(trackId, hash, newSize, source))
        val previous = oldHash
        if (previous != null && previous != hash) {
            val stillUsed = db.rawQuery("SELECT 1 FROM covers WHERE hash=?", arrayOf(previous)).use { it.moveToFirst() }
            if (!stillUsed) coverFile(previous).delete()
        }
        return true
    }

    /**
     * The stored cover for [hash], decoded so its side is at least about [maxSide] px (never larger than the file).
     * Use the default for lists and Int.MAX_VALUE for the full-size image.
     */
    fun coverBitmap(hash: String?, maxSide: Int = 160): Bitmap? {
        if (hash == null) return null
        val key = "$hash@$maxSide"
        CoverCache.get(key)?.let { return it }
        val file = coverFile(hash)
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxSide) sample *= 2
        val bitmap = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
        if (bitmap != null) CoverCache.put(key, bitmap)
        return bitmap
    }

    /** Songs that have no cover, or only a small automatic one, best-played first. */
    fun tracksNeedingCover(minSize: Int): List<LibraryTrack> {
        val out = mutableListOf<LibraryTrack>()
        readableDatabase.rawQuery(
            "SELECT t.id, t.title, t.artist FROM tracks t LEFT JOIN covers c ON c.track_id = t.id WHERE c.track_id IS NULL OR (c.size < ? AND c.source <> 'manual') ORDER BY t.plays DESC",
            arrayOf(minSize.toString())
        ).use { c ->
            while (c.moveToNext()) out += LibraryTrack(c.getLong(0), c.getString(1), c.getString(2), 0)
        }
        return out
    }

    fun coverStats(): CoverStats {
        val rdb = readableDatabase
        fun count(sql: String): Int = rdb.rawQuery(sql, null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        return CoverStats(
            tracks = count("SELECT COUNT(*) FROM tracks"),
            withCover = count("SELECT COUNT(*) FROM covers c JOIN tracks t ON t.id = c.track_id"),
            highRes = count("SELECT COUNT(*) FROM covers c JOIN tracks t ON t.id = c.track_id WHERE c.size >= 400"),
            fromFiles = count("SELECT COUNT(*) FROM covers c JOIN tracks t ON t.id = c.track_id WHERE c.source = 'files'"),
            manual = count("SELECT COUNT(*) FROM covers c JOIN tracks t ON t.id = c.track_id WHERE c.source = 'manual'")
        )
    }

    private fun coverFile(hash: String) = java.io.File(appContext.filesDir, "covers/$hash.jpg")

    /** Center-crops to a square and scales down to [side] px (never up). */
    private fun encodeCover(src: Bitmap, side: Int): ByteArray {
        val crop = minOf(src.width, src.height)
        val square = Bitmap.createBitmap(src, (src.width - crop) / 2, (src.height - crop) / 2, crop, crop)
        val scaled = if (crop > side) Bitmap.createScaledBitmap(square, side, side, true) else square
        val out = java.io.ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
        return out.toByteArray()
    }

    private fun sha1(bytes: ByteArray): String =
        java.security.MessageDigest.getInstance("SHA-1").digest(bytes).joinToString("") { "%02x".format(it) }

    companion object {
        const val COVER_MAX_PX = 512
        const val SOURCE_PLAYER = "player"
        const val SOURCE_FILES = "files"
        const val SOURCE_MANUAL = "manual"
        const val MIN_PLAY_MS = 30_000L
        const val UNKNOWN_ARTIST = "Artista desconocido"
    }
}

data class Totals(val uniqueTracks: Int, val plays: Int, val listenedMs: Long)
data class TrackStat(val title: String, val artist: String, val sourcePackage: String, val plays: Int, val listenedMs: Long, val coverHash: String? = null)
data class ArtistStat(val artist: String, val plays: Int, val listenedMs: Long)
data class PeriodSummary(val listenedMs: Long, val plays: Int, val uniqueTracks: Int, val busiestDayMs: Long?, val topTracks: List<TrackStat>, val topArtists: List<ArtistStat>)
data class LibraryTrack(val id: Long, val title: String, val artist: String, val plays: Int, val coverHash: String? = null)
data class LibraryArtist(val artist: String, val plays: Int, val songs: Int)

/** Decoded covers kept in memory (by size in bytes) so scrolling a list does not re-read the files. */
object CoverCache {
    private val cache = object : android.util.LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    fun get(key: String): Bitmap? = cache.get(key)
    fun put(key: String, bitmap: Bitmap) { cache.put(key, bitmap) }
}

data class CoverStats(val tracks: Int, val withCover: Int, val highRes: Int, val fromFiles: Int, val manual: Int)

/**
 * A rule for songs that must not be recorded. [artist] empty: the title or artist contains [text];
 * otherwise: exactly this title and this artist. Comparisons ignore upper/lower case.
 */
data class IgnoreRule(val text: String, val artist: String) {
    fun matches(title: String, artistName: String): Boolean =
        if (artist.isEmpty()) title.contains(text, ignoreCase = true) || artistName.contains(text, ignoreCase = true)
        else title.equals(text, ignoreCase = true) && artistName.equals(artist, ignoreCase = true)

    fun label(): String = if (artist.isEmpty()) "Contiene «$text»" else "«$text» — $artist (exacta)"
}
