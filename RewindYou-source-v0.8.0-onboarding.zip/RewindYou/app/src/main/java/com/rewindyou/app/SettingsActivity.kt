package com.rewindyou.app

import android.Manifest
import android.annotation.TargetApi
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Appearance, players, permissions and backup. More options can be added here later. */
class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE) }
    private val db by lazy { ListeningDatabase(this) }
    private val ui by lazy { Ui(this) }

    private lateinit var playersSummary: TextView
    private lateinit var listenerStatus: TextView
    private lateinit var coverStatus: TextView
    private lateinit var ignoredStatus: TextView
    private lateinit var remindersHolder: LinearLayout
    private lateinit var recordingHolder: LinearLayout
    private val ignoreTools by lazy { IgnoreTools(this, db) { refreshStatus() } }
    private var scanning = false

    private data class InstalledApp(val packageName: String, val label: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (intent.getBooleanExtra(EXTRA_OPEN_PLAYERS, false)) window.decorView.post { choosePlayers() }
    }

    override fun onResume() {
        super.onResume()
        if (::playersSummary.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        ui.applySystemBars(window)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(ui.backgroundColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(28))
        }
        scroll.addView(root)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        // ---- Encabezado ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ui.button("◀", filled = false) { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(ui.label("Ajustes", 24f, ui.textColor, true).apply { setPadding(ui.dp(14), 0, 0, 0) })
        root.addView(header, ui.matchWrap(4))

        // ---- Apariencia ----
        root.addView(ui.section("APARIENCIA"))
        val appearance = ui.card(14)
        appearance.addView(ui.label("Modo", 14f, ui.mutedColor, true).apply { setPadding(0, 0, 0, ui.dp(8)) })
        val modes = listOf(MainActivity.THEME_SYSTEM, MainActivity.THEME_LIGHT, MainActivity.THEME_DARK)
        val currentMode = prefs.getString(MainActivity.KEY_THEME_MODE, MainActivity.THEME_SYSTEM)
        appearance.addView(ui.segmented(listOf("Teléfono", "Claro", "Oscuro"), modes.indexOf(currentMode).coerceAtLeast(0)) { index ->
            prefs.edit().putString(MainActivity.KEY_THEME_MODE, modes[index]).apply()
            buildUi()
        }, ui.matchWrap(14))

        appearance.addView(ui.label("Paleta de colores", 14f, ui.mutedColor, true).apply { setPadding(0, 0, 0, ui.dp(8)) })
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val currentName = ui.palette.name
        MainActivity.PALETTES.forEachIndexed { i, p ->
            val selected = p.name == currentName
            swatches.addView(TextView(this).apply {
                text = if (selected) "✓" else ""
                gravity = Gravity.CENTER
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                contentDescription = p.name
                background = ui.gradient(p.primary, p.secondary, 14).also { if (selected) it.setStroke(ui.dp(3), ui.textColor) }
                setOnClickListener {
                    prefs.edit().putString(MainActivity.KEY_PALETTE, p.name).apply()
                    buildUi()
                }
            }, LinearLayout.LayoutParams(0, ui.dp(48), 1f).apply { if (i < MainActivity.PALETTES.size - 1) marginEnd = ui.dp(8) })
        }
        appearance.addView(swatches, ui.matchWrap(6))
        appearance.addView(ui.label(currentName, 13f, ui.mutedColor))
        root.addView(appearance, ui.matchWrap(8))

        // ---- Reproductores ----
        root.addView(ui.section("REPRODUCTORES"))
        val players = ui.card(14)
        playersSummary = ui.label("", 14f)
        players.addView(playersSummary, ui.matchWrap(10))
        players.addView(ui.button("Elegir reproductores instalados") { choosePlayers() }, ui.matchWrap(8))
        players.addView(ui.hint("Samsung Music y Musicolet vienen seleccionados. Algunas apps podrían no exponer sus datos multimedia, aunque estén seleccionadas."))
        root.addView(players, ui.matchWrap(8))

        // ---- Permisos ----
        root.addView(ui.section("PERMISOS Y FUNCIONAMIENTO"))
        val permissions = ui.card(14)
        listenerStatus = ui.label("", 14f)
        permissions.addView(listenerStatus, ui.matchWrap(10))
        permissions.addView(ui.button("1 · Habilitar acceso multimedia") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, ui.matchWrap(4))
        permissions.addView(ui.hint("En esa pantalla, activá RewindYou. Es un permiso especial de Android necesario para detectar las sesiones de reproducción."))
        permissions.addView(ui.button("2 · Abrir ajustes de batería") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:$packageName")))
        }, ui.matchWrap(4))
        permissions.addView(ui.hint("Para mejorar la continuidad en Samsung, podés revisar los ajustes de batería. Android todavía puede suspender el registro en algunas situaciones."))
        root.addView(permissions, ui.matchWrap(8))

        // ---- Copia de seguridad ----
        root.addView(ui.section("COPIA DE SEGURIDAD"))
        val backup = ui.card(14)
        backup.addView(ui.hint("Guardá tus estadísticas en un archivo para no perderlas si cambiás de teléfono o hay que reinstalar la app. Conviene copiar el archivo fuera del teléfono (por ejemplo, a Drive). Incluye tus ajustes (apariencia, avisos y opciones de tarjeta), pero no las carátulas ni tu fondo propio."))
        backup.addView(ui.buttonRow(
            ui.button("Exportar") { startExport() },
            ui.button("Importar", filled = false) { startImport() }
        ))
        root.addView(backup, ui.matchWrap(8))

        // ---- Carátulas ----
        root.addView(ui.section("CARÁTULAS"))
        val covers = ui.card(14)
        coverStatus = ui.label("", 14f)
        covers.addView(coverStatus, ui.matchWrap(10))
        covers.addView(ui.button("Buscar carátulas en mis archivos") { startCoverScan() }, ui.matchWrap(4))
        covers.addView(ui.hint("Lee la imagen incluida en tus archivos de música (sin usar internet) para las canciones que no tienen carátula o la tienen pequeña. Pide permiso de acceso a audio. Requiere Android 10 o superior. En el ranking completo, al editar una canción, también podés elegir su carátula a mano."))
        root.addView(covers, ui.matchWrap(8))

        // ---- Registro ----
        root.addView(ui.section("REGISTRO DE REPRODUCCIONES"))
        recordingHolder = ui.card(14)
        root.addView(recordingHolder, ui.matchWrap(8))
        renderRecording()

        // ---- Ignorados ----
        root.addView(ui.section("IGNORADOS"))
        val ignored = ui.card(14)
        ignoredStatus = ui.label("", 14f)
        ignored.addView(ignoredStatus, ui.matchWrap(10))
        ignored.addView(ui.button("Administrar ignorados") { ignoreTools.manageList() }, ui.matchWrap(4))
        ignored.addView(ui.hint("Canciones o audios que no querés registrar, como los audios de WhatsApp o los sonidos de notificación. Para ignorar una canción concreta, abrila en el ranking completo y elegí Eliminar…"))
        root.addView(ignored, ui.matchWrap(8))

        // ---- Avisos de resumen ----
        root.addView(ui.section("AVISOS DE RESUMEN"))
        remindersHolder = ui.card(14)
        root.addView(remindersHolder, ui.matchWrap(8))
        renderReminders()

        // ---- Ayuda ----
        root.addView(ui.section("AYUDA"))
        val help = ui.card(14)
        help.addView(ui.hint("Si algo falla, copia esta información y mándala junto con lo que pasó. No incluye los nombres de tus canciones."))
        help.addView(ui.buttonRow(
            ui.button("Copiar información") { copyDiagnostics() },
            ui.button("Compartir", filled = false) { shareDiagnostics() }
        ), ui.matchWrap(8))
        help.addView(ui.button("Ver la bienvenida", filled = false) { startActivity(Intent(this, WelcomeActivity::class.java)) }, ui.matchWrap(4))
        root.addView(help, ui.matchWrap(8))

        // ---- Acerca de ----
        root.addView(ui.section("ACERCA DE"))
        root.addView(ui.hint("RewindYou ${appVersion()}"))
        root.addView(ui.hint(if (Locale.getDefault().language == "es") "Creado por XaviCastle55" else "Created by XaviCastle55"))

        refreshStatus()
    }

    private fun refreshStatus() {
        listenerStatus.text = if (ui.listenerEnabled()) "Acceso multimedia: habilitado" else "Acceso multimedia: falta habilitarlo"
        listenerStatus.setTextColor(if (ui.listenerEnabled()) ui.okColor else ui.warnColor)
        val selected = prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()) ?: emptySet()
        val names = installedApps().filter { it.packageName in selected }.map { it.label }.sortedBy { it.lowercase() }
        refreshCoverStatus()
        ignoredStatus.text = "Reglas activas: ${db.allIgnored().size}"
        playersSummary.text = if (names.isEmpty()) "No hay reproductores seleccionados." else "Seleccionados (${names.size}): " + names.joinToString(", ")
    }

    private fun refreshCoverStatus() {
        val stats = db.coverStats()
        coverStatus.text = "Con carátula: ${stats.withCover} de ${stats.tracks} canciones\n" +
            "Alta resolución (400 px o más): ${stats.highRes}\n" +
            "Desde tus archivos: ${stats.fromFiles} · Elegidas por vos: ${stats.manual}"
    }

    // ---------------- Carátulas desde los archivos ----------------
    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun startCoverScan() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("Esta función requiere Android 10 o superior.")
            return
        }
        if (checkSelfPermission(audioPermission()) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(audioPermission()), REQ_AUDIO)
            return
        }
        runCoverScan()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_AUDIO -> if (granted) runCoverScan() else toast("Sin ese permiso no se pueden leer las carátulas de tus archivos.")
            REQ_NOTIF -> if (!granted) toast("Sin el permiso de notificaciones no verás los avisos, pero la tarjeta se puede crear igual.")
        }
    }

    private fun runCoverScan() {
        if (scanning) return
        scanning = true
        coverStatus.text = "Buscando carátulas…"
        Thread {
            val pending = db.tracksNeedingCover(400)
            var found = 0
            pending.forEachIndexed { index, track ->
                val art = findLocalArt(track)
                if (art != null && db.saveCoverForTrack(track.id, art, ListeningDatabase.SOURCE_FILES)) found++
                if ((index + 1) % 10 == 0) {
                    runOnUiThread { if (!isFinishing) coverStatus.text = "Buscando carátulas… ${index + 1} de ${pending.size}" }
                }
            }
            runOnUiThread {
                scanning = false
                if (!isFinishing) {
                    refreshCoverStatus()
                    toast("Listo: $found carátulas nuevas o mejoradas, de ${pending.size} canciones revisadas.")
                }
            }
        }.start()
    }

    @TargetApi(Build.VERSION_CODES.Q)
    private fun findLocalArt(track: LibraryTrack): Bitmap? = try {
        val uri = findAudioUri(track)
        if (uri == null) null else contentResolver.loadThumbnail(uri, Size(512, 512), null)
    } catch (e: Exception) {
        null
    }

    /** Looks the song up in the phone's music catalog by title and artist (title alone only if it is unambiguous). */
    private fun findAudioUri(track: LibraryTrack): Uri? {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        fun ids(selection: String, args: Array<String>): List<Long> {
            val found = mutableListOf<Long>()
            contentResolver.query(collection, arrayOf(MediaStore.Audio.Media._ID), selection, args, null)?.use { c ->
                while (c.moveToNext() && found.size < 2) found += c.getLong(0)
            }
            return found
        }
        val exact = ids("${MediaStore.Audio.Media.TITLE} = ? COLLATE NOCASE AND ${MediaStore.Audio.Media.ARTIST} = ? COLLATE NOCASE", arrayOf(track.title, track.artist))
        if (exact.isNotEmpty()) return ContentUris.withAppendedId(collection, exact[0])
        val byTitle = ids("${MediaStore.Audio.Media.TITLE} = ? COLLATE NOCASE", arrayOf(track.title))
        return if (byTitle.size == 1) ContentUris.withAppendedId(collection, byTitle[0]) else null
    }

    // ---------------- Registro de reproducciones ----------------
    private fun renderRecording() {
        val holder = recordingHolder
        holder.removeAllViews()

        holder.addView(ui.label("Segundos para contar una reproducción", 14f, ui.mutedColor, true).apply { setPadding(0, 0, 0, ui.dp(8)) })
        val playSeconds = listOf(10, 20, 30, 45, 60)
        val currentPlay = (prefs.getLong("min_play_ms", ListeningDatabase.MIN_PLAY_MS) / 1000).toInt()
        holder.addView(ui.segmented(playSeconds.map { "$it s" }, playSeconds.indexOf(currentPlay).let { if (it < 0) 2 else it }) { index ->
            prefs.edit().putLong("min_play_ms", playSeconds[index] * 1000L).apply()
            renderRecording()
        }, ui.matchWrap(4))
        holder.addView(ui.hint("Una canción cuenta como reproducida cuando la escuchás al menos este tiempo. Vale desde ahora; no cambia lo ya registrado."))

        holder.addView(ui.label("Ignorar audios más cortos que", 14f, ui.mutedColor, true).apply { setPadding(0, ui.dp(4), 0, ui.dp(8)) })
        val shortSeconds = listOf(0, 10, 30, 60)
        val currentShort = (prefs.getLong("min_track_ms", 0L) / 1000).toInt()
        holder.addView(ui.segmented(shortSeconds.map { if (it == 0) "No" else "$it s" }, shortSeconds.indexOf(currentShort).let { if (it < 0) 0 else it }) { index ->
            prefs.edit().putLong("min_track_ms", shortSeconds[index] * 1000L).apply()
            renderRecording()
        }, ui.matchWrap(4))
        holder.addView(ui.hint("Sirve para no registrar sonidos de notificación o audios cortos. Usa la duración que informa el reproductor; si no la informa, el audio no se ignora. Lo ya registrado se puede borrar desde el ranking completo."))
    }

    // ---------------- Avisos de resumen ----------------
    private fun renderReminders() {
        val holder = remindersHolder
        holder.removeAllViews()
        holder.addView(ui.hint("Te avisan cuando termina el mes o el año para que armes tu tarjeta de resumen."))

        holder.addView(ui.toggle("Aviso de fin de mes", prefs.getBoolean(ReminderScheduler.KEY_MONTH_ON, false)) { on ->
            setReminderFlag(ReminderScheduler.KEY_MONTH_ON, on)
        })
        holder.addView(ui.button("Día: ${monthDayLabel()}", filled = false) { chooseMonthDay() }, ui.matchWrap(8))

        holder.addView(ui.toggle("Aviso de fin de año", prefs.getBoolean(ReminderScheduler.KEY_YEAR_ON, false)) { on ->
            setReminderFlag(ReminderScheduler.KEY_YEAR_ON, on)
        })
        holder.addView(ui.button("Fecha: ${yearDateLabel(prefs.getInt(ReminderScheduler.KEY_YEAR_DATE, 1201))}", filled = false) { chooseYearDate() }, ui.matchWrap(8))

        holder.addView(ui.button("Hora: ${timeLabel()}", filled = false) { chooseTime() }, ui.matchWrap(8))

        holder.addView(ui.toggle("Crear la tarjeta automáticamente", prefs.getBoolean(ReminderScheduler.KEY_AUTO, true)) { on ->
            prefs.edit().putBoolean(ReminderScheduler.KEY_AUTO, on).apply()
        })
        holder.addView(ui.hint("La tarjeta se guarda en tu galería con tus opciones de tarjeta (proporción, fondo y colores) y el aviso te lleva a editarla. Si lo apagás, solo recibís el recordatorio. Requiere Android 10 o superior."))

        holder.addView(ui.label("Preajustes", 14f, ui.mutedColor, true).apply { setPadding(0, ui.dp(4), 0, ui.dp(8)) })
        holder.addView(ui.buttonRow(
            ui.button("Recomendado", filled = false) { applyReminderPreset(0, 1201) },
            ui.button("Anticipado", filled = false) { applyReminderPreset(28, 1128) }
        ), ui.matchWrap(4))
        holder.addView(ui.hint("Recomendado: último día del mes y 1 de diciembre. Anticipado: día 28 de cada mes y 28 de noviembre. Después podés cambiar cada valor."))
        holder.addView(ui.button("Enviar un aviso de prueba") { sendTestReminder() }, ui.matchWrap(4))
    }

    private fun setReminderFlag(key: String, on: Boolean) {
        prefs.edit().putBoolean(key, on).apply()
        if (on) requestNotificationPermission()
        ReminderScheduler.scheduleAll(this)
    }

    private fun notificationsAllowed(): Boolean =
        Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun requestNotificationPermission() {
        if (!notificationsAllowed()) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
    }

    private fun monthDayLabel(): String {
        val day = prefs.getInt(ReminderScheduler.KEY_MONTH_DAY, 0)
        return if (day <= 0) "último día del mes" else "día $day de cada mes"
    }

    private fun yearDateLabel(code: Int): String = "${code % 100} de ${if (code / 100 == 11) "noviembre" else "diciembre"}"

    private fun timeLabel(): String =
        String.format(Locale.US, "%02d:%02d", prefs.getInt(ReminderScheduler.KEY_HOUR, 20), prefs.getInt(ReminderScheduler.KEY_MINUTE, 0))

    private fun chooseMonthDay() {
        val labels = (listOf("Último día del mes") + (1..31).map { "Día $it" })
        AlertDialog.Builder(this)
            .setTitle("Día del aviso mensual")
            .setSingleChoiceItems(labels.toTypedArray(), prefs.getInt(ReminderScheduler.KEY_MONTH_DAY, 0).coerceIn(0, 31)) { dialog, which ->
                prefs.edit().putInt(ReminderScheduler.KEY_MONTH_DAY, which).apply()
                ReminderScheduler.scheduleAll(this)
                renderReminders()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun chooseYearDate() {
        val codes = (20..30).map { 1100 + it } + (1..10).map { 1200 + it }
        val labels = codes.map { yearDateLabel(it) }
        AlertDialog.Builder(this)
            .setTitle("Fecha del aviso anual")
            .setSingleChoiceItems(labels.toTypedArray(), codes.indexOf(prefs.getInt(ReminderScheduler.KEY_YEAR_DATE, 1201))) { dialog, which ->
                prefs.edit().putInt(ReminderScheduler.KEY_YEAR_DATE, codes[which]).apply()
                ReminderScheduler.scheduleAll(this)
                renderReminders()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun chooseTime() {
        TimePickerDialog(this, { _, hour, minute ->
            prefs.edit().putInt(ReminderScheduler.KEY_HOUR, hour).putInt(ReminderScheduler.KEY_MINUTE, minute).apply()
            ReminderScheduler.scheduleAll(this)
            renderReminders()
        }, prefs.getInt(ReminderScheduler.KEY_HOUR, 20), prefs.getInt(ReminderScheduler.KEY_MINUTE, 0), true).show()
    }

    private fun applyReminderPreset(monthDay: Int, yearDate: Int) {
        prefs.edit().putInt(ReminderScheduler.KEY_MONTH_DAY, monthDay).putInt(ReminderScheduler.KEY_YEAR_DATE, yearDate).apply()
        ReminderScheduler.scheduleAll(this)
        renderReminders()
    }

    private fun sendTestReminder() {
        if (!notificationsAllowed()) {
            requestNotificationPermission()
            toast("Concedé el permiso de notificaciones y volvé a probar.")
            return
        }
        toast("Enviando el aviso de prueba…")
        val app = applicationContext
        Thread {
            try { ReminderScheduler.fire(app, ReminderScheduler.TYPE_MONTH) } catch (e: Exception) { android.util.Log.e("RewindYou", "Test reminder failed", e) }
        }.start()
    }

    // ---------------- Ayuda ----------------
    private fun diagnosticsText(): String {
        val selected = prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()) ?: emptySet()
        val names = installedApps().filter { it.packageName in selected }.map { it.label }.sortedBy { it.lowercase() }
        val totals = db.totals()
        val last = prefs.getLong("last_recorded_ms", 0L)
        return buildString {
            append("RewindYou ${appVersion()}\n")
            append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            append("Teléfono: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("Acceso a notificaciones: ${if (ui.listenerEnabled()) "activado" else "desactivado"}\n")
            append("Avisos permitidos: ${if (notificationsAllowed()) "sí" else "no"}\n")
            append("Reproductores seleccionados: ${if (names.isEmpty()) "ninguno" else names.joinToString(", ")}\n")
            append("Canciones: ${totals.uniqueTracks} · Reproducciones: ${totals.plays}\n")
            append("Última escucha registrada: ${if (last > 0L) ui.formatAgo(last) else "nunca"}\n")
            append("Umbral de reproducción: ${prefs.getLong("min_play_ms", ListeningDatabase.MIN_PLAY_MS) / 1000} s · Ignorar audios cortos: ${prefs.getLong("min_track_ms", 0L) / 1000} s\n")
        }
    }

    private fun copyDiagnostics() {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("RewindYou", diagnosticsText()))
        toast("Información copiada. Pégala en tu mensaje.")
    }

    private fun shareDiagnostics() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, diagnosticsText()), "Compartir información"))
    }

    private fun appVersion(): String {
        @Suppress("DEPRECATION")
        val name = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { null }
        return name ?: ""
    }

    // ---------------- Reproductores ----------------
    private fun installedApps(): List<InstalledApp> =
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName) null else InstalledApp(pkg, info.loadLabel(packageManager).toString())
            }
            .distinctBy { it.packageName }

    private fun choosePlayers() {
        val apps = installedApps().sortedBy { it.label.lowercase() }
        val selected = (prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()) ?: MainActivity.defaultPackages()).toMutableSet()
        val labels = apps.map { "${it.label}\n${it.packageName}" }.toTypedArray()
        val checked = apps.map { it.packageName in selected }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Elegir reproductores")
            // Se omite setMessage para que la lista de aplicaciones se muestre correctamente.
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) selected.add(apps[which].packageName) else selected.remove(apps[which].packageName)
            }
            .setNeutralButton("Restablecer sugeridos") { _, _ ->
                prefs.edit().putStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()).apply()
                refreshStatus()
            }
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putStringSet(MainActivity.KEY_SELECTED_PACKAGES, selected.toSet()).apply()
                refreshStatus()
            }
            .show()
    }

    // ---------------- Copia de seguridad ----------------
    @Suppress("DEPRECATION")
    private fun startExport() {
        val name = "RewindYou-copia-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json"
        startActivityForResult(
            Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, name),
            REQ_EXPORT
        )
    }

    @Suppress("DEPRECATION")
    private fun startImport() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_EXPORT -> exportTo(uri)
            REQ_IMPORT -> confirmImport(uri)
        }
    }

    private fun exportTo(uri: Uri) {
        try {
            val json = db.exportJson(SettingsBackup.collect(prefs))
            val stream = contentResolver.openOutputStream(uri, "wt") ?: error("No se pudo abrir el archivo")
            stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            toast("Copia guardada (${json.length / 1024 + 1} KB).")
        } catch (e: Exception) {
            toast("No se pudo guardar la copia: ${e.message}")
        }
    }

    private fun confirmImport(uri: Uri) {
        val text = try {
            contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
        } catch (e: Exception) { null }
        if (text.isNullOrBlank()) { toast("No se pudo leer el archivo."); return }
        val current = db.totals()
        AlertDialog.Builder(this)
            .setTitle("Importar copia de seguridad")
            .setMessage("Esto reemplaza las estadísticas actuales de este teléfono (${current.plays} reproducciones) por las de la copia, y tus ajustes si la copia los incluye. Pausá la música antes de continuar.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Reemplazar") { _, _ ->
                try {
                    val (songs, _) = db.importJson(text)
                    val restored = try {
                        val saved = org.json.JSONObject(text).optJSONObject("settings")
                        if (saved != null) { SettingsBackup.restore(prefs, saved); true } else false
                    } catch (e: Exception) {
                        false
                    }
                    ReminderScheduler.scheduleAll(this)
                    buildUi()
                    toast("Copia importada: $songs canciones" + (if (restored) " y tus ajustes." else "."))
                } catch (e: Exception) {
                    toast("El archivo no es una copia válida de RewindYou. No se cambió nada.")
                }
            }
            .show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        const val EXTRA_OPEN_PLAYERS = "open_players"
        private const val REQ_EXPORT = 4101
        private const val REQ_IMPORT = 4102
        private const val REQ_AUDIO = 4201
        private const val REQ_NOTIF = 4202
    }
}
