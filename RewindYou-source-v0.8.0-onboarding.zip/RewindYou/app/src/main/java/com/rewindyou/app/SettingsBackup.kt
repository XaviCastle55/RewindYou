package com.rewindyou.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Saves and restores the user's settings (appearance, players, thresholds, reminders, card options) inside the backup file. */
object SettingsBackup {
    private val keys = setOf(
        MainActivity.KEY_THEME_MODE,
        MainActivity.KEY_PALETTE,
        MainActivity.KEY_SELECTED_PACKAGES,
        "min_play_ms",
        "min_track_ms"
    )
    private val prefixes = listOf("rem_", "card_")

    private fun included(key: String) = key in keys || prefixes.any { key.startsWith(it) }

    fun collect(prefs: SharedPreferences): JSONObject {
        val out = JSONObject()
        for ((key, value) in prefs.all) {
            if (!included(key)) continue
            val item = JSONObject()
            when (value) {
                is Boolean -> item.put("t", "b").put("v", value)
                is Int -> item.put("t", "i").put("v", value)
                is Long -> item.put("t", "l").put("v", value)
                is String -> item.put("t", "s").put("v", value)
                is Set<*> -> item.put("t", "set").put("v", JSONArray(value.map { it.toString() }))
                else -> continue
            }
            out.put(key, item)
        }
        return out
    }

    fun restore(prefs: SharedPreferences, settings: JSONObject) {
        val editor = prefs.edit()
        val names = settings.keys()
        while (names.hasNext()) {
            val key = names.next()
            if (!included(key)) continue
            val item = settings.optJSONObject(key) ?: continue
            when (item.optString("t")) {
                "b" -> editor.putBoolean(key, item.getBoolean("v"))
                "i" -> editor.putInt(key, item.getInt("v"))
                "l" -> editor.putLong(key, item.getLong("v"))
                "s" -> editor.putString(key, item.getString("v"))
                "set" -> {
                    val array = item.getJSONArray("v")
                    editor.putStringSet(key, (0 until array.length()).map { array.getString(it) }.toSet())
                }
            }
        }
        editor.apply()
    }
}
