package com.rewindyou.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Shown the first time the app opens (and from Ajustes > Ayuda): explains what is needed in three steps. */
class WelcomeActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE) }
    private val ui by lazy { Ui(this) }

    private lateinit var accessStatus: TextView
    private lateinit var playersStatus: TextView
    private var firstRun = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        firstRun = !prefs.getBoolean(MainActivity.PREF_ONBOARDED, false)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi() {
        ui.applySystemBars(window)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.backgroundColor)
            fitsSystemWindows = true
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(ui.backgroundColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(28))
        }
        scroll.addView(root)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher_foreground) }, LinearLayout.LayoutParams(ui.dp(72), ui.dp(72)).apply { marginStart = -ui.dp(8) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(ui.label("Te damos la bienvenida", 24f, ui.textColor, true))
        titles.addView(ui.label("RewindYou", 16f, ui.accentColor, true))
        header.addView(titles)
        root.addView(header, ui.matchWrap(8))
        root.addView(ui.hint("RewindYou registra lo que escuchas en tus reproductores de música y lo convierte en estadísticas, rankings y tarjetas para compartir. Solo necesita dos cosas:", 14f))

        val step1 = ui.card(14)
        step1.addView(ui.label("1 · Permitir el acceso a notificaciones", 16f, ui.textColor, true).apply { setPadding(0, 0, 0, ui.dp(6)) })
        step1.addView(ui.hint("Android lo necesita para saber qué canción está sonando. RewindYou no lee tus mensajes ni el contenido de tus notificaciones."))
        accessStatus = ui.label("", 14f, ui.mutedColor, true).apply { setPadding(ui.dp(4), 0, 0, ui.dp(8)) }
        step1.addView(accessStatus)
        step1.addView(ui.button("Abrir la pantalla de acceso") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, ui.matchWrap(4))
        root.addView(step1, ui.matchWrap(10))

        val step2 = ui.card(14)
        step2.addView(ui.label("2 · Elegir tus reproductores", 16f, ui.textColor, true).apply { setPadding(0, 0, 0, ui.dp(6)) })
        step2.addView(ui.hint("Samsung Music y Musicolet vienen marcados. Elige las apps de música que usas."))
        playersStatus = ui.label("", 14f, ui.mutedColor, true).apply { setPadding(ui.dp(4), 0, 0, ui.dp(8)) }
        step2.addView(playersStatus)
        step2.addView(ui.button("Elegir reproductores") {
            startActivity(Intent(this, SettingsActivity::class.java).putExtra(SettingsActivity.EXTRA_OPEN_PLAYERS, true))
        }, ui.matchWrap(4))
        root.addView(step2, ui.matchWrap(10))

        val privacy = ui.card(14)
        privacy.addView(ui.label("Tu privacidad", 16f, ui.textColor, true).apply { setPadding(0, 0, 0, ui.dp(6)) })
        privacy.addView(ui.hint("Todo se guarda solo en tu teléfono. RewindYou no tiene permiso de internet, así que no puede enviar tus datos a ningún lado. Más adelante puedes activar avisos de resumen y otras opciones en ⚙ Ajustes."))
        root.addView(privacy, ui.matchWrap(14))

        root.addView(ui.button(if (firstRun) "Empezar" else "Cerrar") { finishWelcome() }, ui.matchWrap(8))
    }

    private fun refreshStatus() {
        val enabled = ui.listenerEnabled()
        accessStatus.text = if (enabled) "✓ Acceso activado" else "Falta activarlo"
        accessStatus.setTextColor(if (enabled) ui.okColor else ui.warnColor)
        val count = (prefs.getStringSet(MainActivity.KEY_SELECTED_PACKAGES, MainActivity.defaultPackages()) ?: emptySet()).size
        playersStatus.text = "Seleccionados: $count"
    }

    private fun finishWelcome() {
        prefs.edit().putBoolean(MainActivity.PREF_ONBOARDED, true).apply()
        if (firstRun) startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
